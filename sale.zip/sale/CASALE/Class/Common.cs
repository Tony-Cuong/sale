﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LCKeysSettingsUtilities;
using System.Data;
using System.IO;
using System.Windows.Forms;
using LCMultiUtilities;

namespace CASALE.Class
{
    class Common
    {
        enum ImportExportType
        {
            Import = 1,
            Export = 0
        }
        public const string ApplicationCode = "CAMS";
        public static string app_code_quote_unit_id = "UN";
        public static string capp_product_code = "PR";
        public static string capp_customer_code = "CU";
        public static string vietnames = "VIE";
        public static string english = "ENG";

        public static frmsyssettings frmsettings = null;
        public static frmUserManagement frmusermanagement = null;
        public static frmuserauthentication frmuserauthentication = null;
        public static frmDonvitinh frmdonvitinh = null;
        public static frmSanpham frmsanpham = null;
        public static frmKhachhang frmkhachhang = null;
        public static frmNhaphang frmnhaphang = null;
        public static frmXuathang frmxuathang = null;
        public static frmQuanlynhapxuat frmquanlynhapxuat = null;
        public static frmReportSale frmreportsale = null;
        public static frmNhapXuat frmnhapxuat = null;
        public static frmReport frmreport = null;
        public static frmBaocaobieudodt frmbaocaobieudodt = null;
        public static frmBanhang frmbanhang = null;
        public static frmPrintOrderDetail frmsaleorderprint = null;
        public static frmXulydonhang frmxulydonhang = null;
        public static frmregisters frmreg = null;
        public static frmMain frmMain = null;
        public static frmaboutus frmaboutus = null;
        //
        public static frmbarcode fbarcode = null;
        public static barcodecontrolinsertitems barcodeinsertdialog = null;
        public static frmbarcodeimportexport fimexbarcode = null;


        #region định dạng ngày tháng
        public static string FormatDate_(object date)
        {
            try
            {
                return (Convert.ToDateTime(date).ToString("dd/MM/yyyy"));
            }
            catch (Exception ex)
            {
                StreamWriter stw = new StreamWriter("logs", true);
                stw.WriteLine(DateTime.Now.ToString() + " " + ex.ToString());
                stw.Close();
            }
            return null;

        }
        public static string FormatDate_long(object date)
        {
            return (Convert.ToDateTime(date).ToString("dd/MM/yyyy hh:mm:ss"));
        }
        #endregion
        #region User Information
        private static string _userauthentication = "-1";

        public static string Userauthentication
        {
            get { return Common._userauthentication; }
            set { Common._userauthentication = value; }
        }
        static int _iuser_id = 1;
        static string _strusername = "Admin";
        static string _strfullname = "Administrator";

        public static int UserId
        {
            get
            {
                return _iuser_id;
            }
            set
            {
                _iuser_id = value;
            }
        }
        public static string UserName
        {
            get
            {
                return _strusername;
            }
            set
            {
                _strusername = value;
            }
        }
        public static string UserFullName
        {
            get
            {
                return _strfullname;
            }
            set
            {
                _strfullname = value;
            }
        }
        public static string GenderName(int igender)
        {
            if (igender == 0)
                return "Nữ";
            return "Nam";
        }


        /// <summary>
        /// Dung de bieu dien tren bang du lieu.
        /// </summary>
        /// <param name="istatus"></param>
        /// <returns></returns>
        public static string UserStatus(int istatus)
        {
            switch (istatus)
            {
                case 0:
                    return "Mới tạo";
                    break;
                case 1:
                    return "Đã kích hoạt";
                    break;
                case -2:
                    return "Đã bị xóa";
                    break;
                case 2:
                    return "Đã bị khóa";
                    break;
            }
            return "--";
        }
        #endregion

        #region cau hình thôn tin chung
        public static string CorporationName
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_corporation", "-1", "TÊN TỔNG CÔNG TY ").ToString();
            }
            set
            {
                keysettings.settings_update("_k_corporation", "-1", value, Common.ConnectionString);
            }
        }
        public static string CompanyName
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_compname", "-1", "TÊN CÔNG TY ").ToString();
            }
            set
            {
                keysettings.settings_update("_k_compname", "-1", value, Common.ConnectionString);
            }
        }
        public static string CompanyAddress
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_compaddress", "-1", "ĐỊA CHỈ CÔNG TY ").ToString();
            }
            set
            {
                keysettings.settings_update("_k_compaddress", "-1", value, Common.ConnectionString);
            }
        }
        public static string CompanyPhone
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_compphone", "-1", "ĐIỆN THOẠI CÔNG TY ").ToString();
            }
            set
            {
                keysettings.settings_update("_k_compphone", "-1", value, Common.ConnectionString);
            }
        }
        public static string Taxcode
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_taxcode", "-1", "ACB09124657098A").ToString();
            }
            set
            {
                keysettings.settings_update("_k_taxcode", "-1", value, Common.ConnectionString);
            }
        }
        public static string Rete
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_rete", "-1", "1909 ").ToString();
            }
            set
            {
                keysettings.settings_update("_k_rete", "-1", value, Common.ConnectionString);
            }
        }
        public static string MoneyUnit
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_moneyunit", "-1", "VNĐ").ToString();
            }
            set
            {
                keysettings.settings_update("_k_moneyunit", "-1", value, Common.ConnectionString);
            }
        }
        public static string DefaultOrderStatus
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_defaultorderstatus", "-1", "2").ToString();
            }
            set
            {
                keysettings.settings_update("_k_defaultorderstatus", "-1", value, Common.ConnectionString);
            }
        }
        static DataTable _dtorderstatusnotincludeall = new DataTable();
        public static DataTable OrderStatusNotIncludeAll // dùng cho các combobox detail: không có trạng thái tất cả (-1)
        {
            get
            {
                if (_dtorderstatusnotincludeall.Columns.Count < 1)
                {
                    _dtorderstatusnotincludeall.Columns.Add("ID", typeof(Int32));
                    _dtorderstatusnotincludeall.Columns.Add("Status", typeof(String));
                }
                if (_dtorderstatusnotincludeall.Rows.Count < 1)
                {
                    DataRow dr = _dtorderstatusnotincludeall.NewRow();
                    dr["ID"] = 0;
                    dr["Status"] = "Mới đặt hàng";
                    _dtorderstatusnotincludeall.Rows.Add(dr);

                    DataRow dr1 = _dtorderstatusnotincludeall.NewRow();
                    dr1["ID"] = 1;
                    dr1["Status"] = "Đang giao hàng";
                    _dtorderstatusnotincludeall.Rows.Add(dr1);

                    DataRow dr2 = _dtorderstatusnotincludeall.NewRow();
                    dr2["ID"] = 2;
                    dr2["Status"] = "Đã giao hàng";
                    _dtorderstatusnotincludeall.Rows.Add(dr2);

                    DataRow dr3 = _dtorderstatusnotincludeall.NewRow();
                    dr3["ID"] = -3;
                    dr3["Status"] = "Đã hủy đơn hàng";
                    _dtorderstatusnotincludeall.Rows.Add(dr3);
                }
                return _dtorderstatusnotincludeall;
            }
        }
        public static string OrderPrefix
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_orderprefix", "-1", "OD").ToString();
            }
            set
            {
                keysettings.settings_update("_k_orderprefix", "-1", value, Common.ConnectionString);
            }
        }
        public static string ImportPrefix
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_importprefix", "-1", "IM").ToString();
            }
            set
            {
                keysettings.settings_update("_k_importprefix", "-1", value, Common.ConnectionString);
            }
        }
        /// <summary>
        /// 0: siêu thị; 1: A4
        /// </summary>
        public static string PrintOrderType
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_printordertype", "-1", "0").ToString();
            }
            set
            {
                keysettings.settings_update("_k_printordertype", "-1", value, Common.ConnectionString);
            }
        }
        public static string PrintTitle
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_printtitle", "-1", "HÓA ĐƠN BÁN HÀNG ").ToString();
            }
            set
            {
                keysettings.settings_update("_k_printtitle", "-1", value, Common.ConnectionString);
            }
        }
        public static string PrintThanks
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_printthanks", "-1", "Chúng tôi xin cảm ơn Quý khách đã mua hàng").ToString();
            }
            set
            {
                keysettings.settings_update("_k_printthanks", "-1", value, Common.ConnectionString);
            }
        }
        public static string PrintTax
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_printtax", "-1", "Thuế GTGT (VAT=10%)").ToString();
            }
            set
            {
                keysettings.settings_update("_k_printtax", "-1", value, Common.ConnectionString);
            }
        }
        public static string ImExPrintImTitle
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_printimtitle", "-1", "HÓA ĐƠN NHẬP HÀNG").ToString();
            }
            set
            {
                keysettings.settings_update("_k_printimtitle", "-1", value, Common.ConnectionString);
            }
        }
        public static string ImExPrintExTitle
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_printextitle", "-1", "HÓA ĐƠN XUẤT HÀNG").ToString();
            }
            set
            {
                keysettings.settings_update("_k_printextitle", "-1", value, Common.ConnectionString);
            }
        }

        #endregion

        #region "Application Settings"
        public static bool EnableSynOnlineData
        {
            get
            {
                if (Convert.ToInt32(keysettings.settings_getdetailbyid_("_k_enablesynonlinedata", "-1", "0")) == 1)
                    return true;
                return false;
            }
            set
            {
                int ivalue = 0;
                if (value == true)
                    ivalue = 1;
               keysettings.settings_update("_k_enablesynonlinedata", "-1", ivalue.ToString(), Common.ConnectionString);
            }
        }

        public static bool EnableSaleOnline
        {
            get
            {
                if (Convert.ToInt32(keysettings.settings_getdetailbyid_("_k_enableonline", "-1", "0")) == 1)
                    return true;
                return false;
            }
            set
            {
                int ivalue = 0;
                if (value == true)
                    ivalue = 1;
               keysettings.settings_update("_k_enableonline", "-1", ivalue.ToString(), Common.ConnectionString);
            }
        }

        static string _saleonlinewsusername = "";
        public static string SaleOnlineWSUserName
        {
            get
            {
                if (_saleonlinewsusername.Equals(""))
                    _saleonlinewsusername =keysettings.settings_getdetailbyid_("_k_wsusername", "-1", "").ToString();
                return _saleonlinewsusername;
            }
            set
            {
                _saleonlinewsusername = value;
               keysettings.settings_update("_k_wsusername", "-1", value, Common.ConnectionString);
            }
        }
        static string _saleonlinewspassword = "";
        public static string SaleOnlineWSPassword
        {
            get
            {
                if (_saleonlinewspassword.Equals(""))
                    _saleonlinewspassword =keysettings.settings_getdetailbyid_("_k_wspasswd", "-1", "").ToString();
                return _saleonlinewspassword;
            }
            set
            {
                _saleonlinewspassword = value;
               keysettings.settings_update("_k_wspasswd", "-1", value, Common.ConnectionString);
            }
        }
        #endregion

        #region cấu hình mã số
       
        public static string OrderhqPrefix
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_orderhqprefix", "-1", "DH/").ToString();
            }
            set
            {
                keysettings.settings_update("_k_orderhqprefix", "-1", value, Common.ConnectionString);
            }
        }

        
        public static string ExportPrefix
        {
            get
            {
                return keysettings.settings_getdetailbyid_("_k_exportprefix", "-1", "EX").ToString();
            }
            set
            {
                keysettings.settings_update("_k_exportprefix", "-1", value, Common.ConnectionString);
            }
        }
        
        public static string OrderCodeCustomesDepartment
        {
            get
            {
                int tempcode = Convert.ToInt32(keysettings.settings_getdetailbyid_("_k_ordercartidcd", "-1", 1));
                tempcode++;
                keysettings.settings_update("_k_ordercartidcd", "-1", tempcode.ToString(), Common.ConnectionString);

                string strtemp = tempcode.ToString();
                for (int i = tempcode.ToString().Length; i < 7; i++)
                {
                    strtemp = "0" + strtemp;
                }
                return OrderhqPrefix + strtemp;
            }
        }
        public static string OrderCode
        {
            get
            {
                int tempcode = Convert.ToInt32(keysettings.settings_getdetailbyid_("_k_ordercartid", "-1", 1));
                tempcode++;
                keysettings.settings_update("_k_ordercartid", "-1", tempcode.ToString(), Common.ConnectionString);

                string strtemp = tempcode.ToString();
                for (int i = tempcode.ToString().Length; i < 7; i++)
                {
                    strtemp = "0" + strtemp;
                }
                return OrderPrefix + strtemp;
            }
        }
        public static string ImportCode
        {
            get
            {
                int tempcode = Convert.ToInt32(keysettings.settings_getdetailbyid_("_k_importcodeid", "-1", 1));
                tempcode++;
                keysettings.settings_update("_k_importcodeid", "-1", tempcode.ToString(), Common.ConnectionString);

                string strtemp = tempcode.ToString();
                for (int i = tempcode.ToString().Length; i < 7; i++)
                {
                    strtemp = "0" + strtemp;
                }
                return ImportPrefix + strtemp;
            }
        }
        public static string ExportCode
        {
            get
            {
                int tempcode = Convert.ToInt32(keysettings.settings_getdetailbyid_("_k_exportcodeid", "-1", 1));
                tempcode++;
                keysettings.settings_update("_k_exportcodeid", "-1", tempcode.ToString(), Common.ConnectionString);

                string strtemp = tempcode.ToString();
                for (int i = tempcode.ToString().Length; i < 7; i++)
                {
                    strtemp = "0" + strtemp;
                }
                return ExportPrefix + strtemp;
            }
        }
        public static string CustomerCode
        {
            get
            {
                int tempcode = Convert.ToInt32(keysettings.settings_getdetailbyid_("_k_custmrcodeid", "-1", 1));
                tempcode++;
                keysettings.settings_update("_k_custmrcodeid", "-1", tempcode.ToString(), Common.ConnectionString);

                string strtemp = tempcode.ToString();
                for (int i = tempcode.ToString().Length; i < 7; i++)
                {
                    strtemp = "0" + strtemp;
                }
                return "C" + strtemp;
            }
        }
        #endregion
        #region tạo bảng
        static DataTable _dtproductstatus = new DataTable();
        /// <summary>
        /// Danh sách trạng thái đơn hàng nhập
        /// </summary>
        public static DataTable ProductStatus
        {
            get
            {
                if (_dtproductstatus.Columns.Count < 1)
                {
                    _dtproductstatus.Columns.Add("ID", typeof(Int32));
                    _dtproductstatus.Columns.Add("Status", typeof(String));
                }
                if (_dtproductstatus.Rows.Count < 1)
                {
                    DataRow dr0 = _dtproductstatus.NewRow();
                    dr0["ID"] = -1;
                    dr0["Status"] = "Tất cả sản phẩm";
                    _dtproductstatus.Rows.Add(dr0);

                    DataRow dr = _dtproductstatus.NewRow();
                    dr["ID"] = 0;
                    dr["Status"] = "Sản phẩm có giao dịch";
                    _dtproductstatus.Rows.Add(dr);
                }
                return _dtproductstatus;
            }
        }
        static DataTable _dtitemperpage = new DataTable();
        public static DataTable ItemsPerPage
        {
            get
            {
                if (_dtitemperpage.Columns.Count < 1)
                {
                    _dtitemperpage.Columns.Add("Value", typeof(Int32));
                    _dtitemperpage.Columns.Add("Text", typeof(String));
                }
                if (_dtitemperpage.Rows.Count < 1)
                {
                    DataRow dr0 = _dtitemperpage.NewRow();
                    dr0["Value"] = 20;
                    dr0["Text"] = "20";
                    _dtitemperpage.Rows.Add(dr0);

                    DataRow dr = _dtitemperpage.NewRow();
                    dr["Value"] = 30;
                    dr["Text"] = "30";
                    _dtitemperpage.Rows.Add(dr);

                    DataRow dr1 = _dtitemperpage.NewRow();
                    dr1["Value"] = 45;
                    dr1["Text"] = "45";
                    _dtitemperpage.Rows.Add(dr1);

                    DataRow dr2 = _dtitemperpage.NewRow();
                    dr2["Value"] = 60;
                    dr2["Text"] = "60";
                    _dtitemperpage.Rows.Add(dr2);

                    DataRow dr3 = _dtitemperpage.NewRow();
                    dr3["Value"] = 100;
                    dr3["Text"] = "100";
                    _dtitemperpage.Rows.Add(dr3);
                }
                return _dtitemperpage;
            }
        }
        static DataTable _dtimextypes = new DataTable();
        public static DataTable ImportExportTypes
        {
            get
            {
                if (_dtimextypes.Columns.Count < 1)
                {
                    _dtimextypes.Columns.Add("ID", typeof(Int32));
                    _dtimextypes.Columns.Add("Type", typeof(String));
                }
                if (_dtimextypes.Rows.Count < 1)
                {
                    DataRow dr0 = _dtimextypes.NewRow();
                    dr0["ID"] = -1;
                    dr0["Type"] = "Tất cả";
                    _dtimextypes.Rows.Add(dr0);

                    DataRow dr = _dtimextypes.NewRow();
                    dr["ID"] = 0;
                    dr["Type"] = "Xuất";
                    _dtimextypes.Rows.Add(dr);

                    DataRow dr1 = _dtimextypes.NewRow();
                    dr1["ID"] = 1;
                    dr1["Type"] = "Nhập";
                    _dtimextypes.Rows.Add(dr1);
                }
                return _dtimextypes;
            }
        }
        static DataTable _dtallstatus = new DataTable();
        /// <summary>
        /// Danh sách trạng thái đơn hàng nhập
        /// </summary>
        public static DataTable AllStatus
        {
            get
            {
                if (_dtallstatus.Columns.Count < 1)
                {
                    _dtallstatus.Columns.Add("ID", typeof(Int32));
                    _dtallstatus.Columns.Add("Status", typeof(String));
                }
                if (_dtallstatus.Rows.Count < 1)
                {
                    DataRow dr0 = _dtallstatus.NewRow();
                    dr0["ID"] = -1;
                    dr0["Status"] = "Không lọc";
                    _dtallstatus.Rows.Add(dr0);
                }
                return _dtallstatus;
            }
        }

        static DataTable _dtorderstatus = new DataTable();
        /// <summary>
        /// Export Status List
        /// </summary>
        public static DataTable OrderStatus
        {
            get
            {
                if (_dtorderstatus.Columns.Count < 1)
                {
                    _dtorderstatus.Columns.Add("ID", typeof(Int32));
                    _dtorderstatus.Columns.Add("Status", typeof(String));
                }
                if (_dtorderstatus.Rows.Count < 1)
                {
                    DataRow dr0 = _dtorderstatus.NewRow();
                    dr0["ID"] = -1;
                    dr0["Status"] = "Không lọc";
                    _dtorderstatus.Rows.Add(dr0);

                    DataRow dr = _dtorderstatus.NewRow();
                    dr["ID"] = 0;
                    dr["Status"] = "Mới đặt hàng";
                    _dtorderstatus.Rows.Add(dr);

                    DataRow dr1 = _dtorderstatus.NewRow();
                    dr1["ID"] = 1;
                    dr1["Status"] = "Đang giao hàng";
                    _dtorderstatus.Rows.Add(dr1);

                    DataRow dr2 = _dtorderstatus.NewRow();
                    dr2["ID"] = 2;
                    dr2["Status"] = "Đã giao hàng";
                    _dtorderstatus.Rows.Add(dr2);

                    DataRow dr3 = _dtorderstatus.NewRow();
                    dr3["ID"] = -3;
                    dr3["Status"] = "Đã hủy đơn hàng";
                    _dtorderstatus.Rows.Add(dr3);
                }
                return _dtorderstatus;
            }
        }
        

        static DataTable _dtimportstatus = new DataTable();
        /// <summary>
        /// Danh sách trạng thái đơn hàng nhập
        /// </summary>
        public static DataTable ImportStatus
        {
            get
            {
                if (_dtimportstatus.Columns.Count < 1)
                {
                    _dtimportstatus.Columns.Add("ID", typeof(Int32));
                    _dtimportstatus.Columns.Add("Status", typeof(String));
                }
                if (_dtimportstatus.Rows.Count < 1)
                {
                    DataRow dr0 = _dtimportstatus.NewRow();
                    dr0["ID"] = -1;
                    dr0["Status"] = "Không lọc";
                    _dtimportstatus.Rows.Add(dr0);
                }
                return _dtimportstatus;
            }
        }


        public static string OrderStatusInList(int istatus)
        {
            switch (istatus)
            {
                case 0:
                    return "MĐH";
                    break;
                case 1:
                    return "ĐXL";
                    break;
                case 2:
                    return "ĐGH";
                    break;
                case -3:
                    return "Đã hủy";
                    break;
            }
            return "--";
        }
        #endregion

        #region load cate
        public static void LoadCategoriesall(ComboBox cbo, string capp, string cur_cate_id, string lag, string status)
        {
            DataTable tb = new DataTable();


            mssql_modcategories.LoadAllChildrencates(ref tb, cur_cate_id, capp, lag, status);

            for (int i = 0; i < tb.Rows.Count; i++)
            {
                string tm = "";
                int ilevel = Convert.ToInt32(tb.Rows[i]["ilevel"]);
                for (int j = 0; j < ilevel; j++)
                {
                    tm += "»"; ;
                }
                tb.Rows[i]["vname"] = tm + tb.Rows[i]["vname"].ToString();
            }
            try
            {
                DataRow dr = tb.NewRow();
                dr["icid"] = -1;
                dr["vname"] = "Tất cả";
                tb.Rows.Add(dr);

                cbo.DataSource = tb;
                cbo.DisplayMember = "vname";
                cbo.ValueMember = "icid";
            }
            catch (Exception ex)
            {
                ;
            }

        }
        #endregion

        #region CONNECTIONSTRING
        /// <summary>
        /// Bien toan cuc: luu tru chuoi ket noi,
        /// </summary>
        static string _strconnectionstring = "";
        /// <summary>
        /// Thuoc tinh toan cuc tra ve chuoi ket noi.
        /// </summary>
        public static string ConnectionString
        {
            get
            {

                if (_strconnectionstring.Equals(""))
                {
                    _strconnectionstring = System.Configuration.ConfigurationSettings.AppSettings["ConnectionString"];

                }
                return _strconnectionstring;
            }
        }
        #endregion
    }
}
