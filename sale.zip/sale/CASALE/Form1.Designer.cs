﻿using CASALE.Class;
namespace CASALE
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.frmMain = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnumaincontrol = new System.Windows.Forms.ToolStripMenuItem();
            this.mnusyssetting = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.mndanhsachnguoidung = new System.Windows.Forms.ToolStripMenuItem();
            this.mnphanquyen = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.mnucloseprogram = new System.Windows.Forms.ToolStripMenuItem();
            this.mnusaleimportexport = new System.Windows.Forms.ToolStripMenuItem();
            this.mnusaleorder = new System.Windows.Forms.ToolStripMenuItem();
            this.mnsaleorderexecuting = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.cmnhq = new System.Windows.Forms.ToolStripMenuItem();
            this.mndata = new System.Windows.Forms.ToolStripMenuItem();
            this.mnunit = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuproductsmanagement = new System.Windows.Forms.ToolStripMenuItem();
            this.mnumanageproviders = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnumanagecustomer = new System.Windows.Forms.ToolStripMenuItem();
            this.inMãĐơnHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnumanageimex = new System.Windows.Forms.ToolStripMenuItem();
            this.mnsaleimportproducts = new System.Windows.Forms.ToolStripMenuItem();
            this.mnsaleexportproducts = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.mnumanageimportexportorders = new System.Windows.Forms.ToolStripMenuItem();
            this.mnureport = new System.Windows.Forms.ToolStripMenuItem();
            this.cmnreportsale = new System.Windows.Forms.ToolStripMenuItem();
            this.mnunhapxuatton = new System.Windows.Forms.ToolStripMenuItem();
            this.mnureportsale = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.mnureportimcom = new System.Windows.Forms.ToolStripMenuItem();
            this.biểuĐồKinhDoanhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mntrogiup = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuintroduction = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuregisterlicense = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuaboutus = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblcompany = new System.Windows.Forms.Label();
            this.lbllicensestatus = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.menuStrip1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnumaincontrol,
            this.mnusaleimportexport,
            this.mndata,
            this.mnumanageimex,
            this.mnureport,
            this.mntrogiup});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(743, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnumaincontrol
            // 
            this.mnumaincontrol.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnusyssetting,
            this.toolStripMenuItem5,
            this.mndanhsachnguoidung,
            this.mnphanquyen,
            this.toolStripMenuItem6,
            this.mnucloseprogram});
            this.mnumaincontrol.ForeColor = System.Drawing.Color.White;
            this.mnumaincontrol.Image = global::CASALE.Properties.Resources.wrench;
            this.mnumaincontrol.Name = "mnumaincontrol";
            this.mnumaincontrol.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D)));
            this.mnumaincontrol.Size = new System.Drawing.Size(73, 20);
            this.mnumaincontrol.Text = "Cài đặt";
            this.mnumaincontrol.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mnusyssetting
            // 
            this.mnusyssetting.Image = global::CASALE.Properties.Resources.gear_connection;
            this.mnusyssetting.Name = "mnusyssetting";
            this.mnusyssetting.Size = new System.Drawing.Size(197, 22);
            this.mnusyssetting.Text = "Cấu hình hệ thống";
            this.mnusyssetting.Click += new System.EventHandler(this.mnusyssetting_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(194, 6);
            // 
            // mndanhsachnguoidung
            // 
            this.mndanhsachnguoidung.Image = global::CASALE.Properties.Resources.books;
            this.mndanhsachnguoidung.Name = "mndanhsachnguoidung";
            this.mndanhsachnguoidung.Size = new System.Drawing.Size(197, 22);
            this.mndanhsachnguoidung.Text = "Danh sách người dùng";
            this.mndanhsachnguoidung.Click += new System.EventHandler(this.mndanhsachnguoidung_Click);
            // 
            // mnphanquyen
            // 
            this.mnphanquyen.Image = global::CASALE.Properties.Resources._75;
            this.mnphanquyen.Name = "mnphanquyen";
            this.mnphanquyen.Size = new System.Drawing.Size(197, 22);
            this.mnphanquyen.Text = "Quản lý phân quyền";
            this.mnphanquyen.Click += new System.EventHandler(this.mnphanquyen_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(194, 6);
            // 
            // mnucloseprogram
            // 
            this.mnucloseprogram.Image = global::CASALE.Properties.Resources.forbidden;
            this.mnucloseprogram.Name = "mnucloseprogram";
            this.mnucloseprogram.Size = new System.Drawing.Size(197, 22);
            this.mnucloseprogram.Text = "Thoát chương trinh";
            this.mnucloseprogram.Click += new System.EventHandler(this.mnucloseprogram_Click);
            // 
            // mnusaleimportexport
            // 
            this.mnusaleimportexport.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnusaleorder,
            this.mnsaleorderexecuting,
            this.toolStripMenuItem1,
            this.toolStripMenuItem4,
            this.cmnhq});
            this.mnusaleimportexport.ForeColor = System.Drawing.Color.White;
            this.mnusaleimportexport.Image = global::CASALE.Properties.Resources.angel;
            this.mnusaleimportexport.Name = "mnusaleimportexport";
            this.mnusaleimportexport.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.N)));
            this.mnusaleimportexport.Size = new System.Drawing.Size(87, 20);
            this.mnusaleimportexport.Text = "Bán hàng";
            this.mnusaleimportexport.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mnusaleorder
            // 
            this.mnusaleorder.Image = global::CASALE.Properties.Resources.text_binary;
            this.mnusaleorder.Name = "mnusaleorder";
            this.mnusaleorder.Size = new System.Drawing.Size(217, 22);
            this.mnusaleorder.Text = "Bán hàng";
            this.mnusaleorder.Click += new System.EventHandler(this.mnusaleorder_Click);
            // 
            // mnsaleorderexecuting
            // 
            this.mnsaleorderexecuting.Image = global::CASALE.Properties.Resources.books_preferences;
            this.mnsaleorderexecuting.Name = "mnsaleorderexecuting";
            this.mnsaleorderexecuting.Size = new System.Drawing.Size(217, 22);
            this.mnsaleorderexecuting.Text = "Xử lý hàng hóa (đơn hàng)";
            this.mnsaleorderexecuting.Click += new System.EventHandler(this.mnsaleorderexecuting_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Image = global::CASALE.Properties.Resources.book_blue_view;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(217, 22);
            this.toolStripMenuItem1.Text = "Tra cứu đơn hàng";
            this.toolStripMenuItem1.Visible = false;
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(214, 6);
            // 
            // cmnhq
            // 
            this.cmnhq.Enabled = false;
            this.cmnhq.Name = "cmnhq";
            this.cmnhq.Size = new System.Drawing.Size(217, 22);
            this.cmnhq.Text = "Báo cáo hải quan";
            this.cmnhq.Visible = false;
            // 
            // mndata
            // 
            this.mndata.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnunit,
            this.toolStripMenuItem3,
            this.mnuproductsmanagement,
            this.mnumanageproviders,
            this.toolStripSeparator1,
            this.mnumanagecustomer,
            this.inMãĐơnHàngToolStripMenuItem});
            this.mndata.ForeColor = System.Drawing.Color.White;
            this.mndata.Image = global::CASALE.Properties.Resources.books1;
            this.mndata.Name = "mndata";
            this.mndata.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.L)));
            this.mndata.Size = new System.Drawing.Size(109, 20);
            this.mndata.Text = "QL.Thông tin";
            this.mndata.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mnunit
            // 
            this.mnunit.Image = global::CASALE.Properties.Resources.books2;
            this.mnunit.Name = "mnunit";
            this.mnunit.Size = new System.Drawing.Size(215, 22);
            this.mnunit.Text = "Quản lý đơn vị sản phẩm";
            this.mnunit.Click += new System.EventHandler(this.mnunit_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(212, 6);
            // 
            // mnuproductsmanagement
            // 
            this.mnuproductsmanagement.Image = global::CASALE.Properties.Resources.books;
            this.mnuproductsmanagement.Name = "mnuproductsmanagement";
            this.mnuproductsmanagement.Size = new System.Drawing.Size(215, 22);
            this.mnuproductsmanagement.Text = "Quản lý danh bạ sản phẩm";
            this.mnuproductsmanagement.Click += new System.EventHandler(this.mnuproductsmanagement_Click);
            // 
            // mnumanageproviders
            // 
            this.mnumanageproviders.Image = global::CASALE.Properties.Resources.books;
            this.mnumanageproviders.Name = "mnumanageproviders";
            this.mnumanageproviders.Size = new System.Drawing.Size(215, 22);
            this.mnumanageproviders.Text = "Quản lý nhà cung cấp";
            this.mnumanageproviders.Visible = false;
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(212, 6);
            // 
            // mnumanagecustomer
            // 
            this.mnumanagecustomer.Image = global::CASALE.Properties.Resources.books;
            this.mnumanagecustomer.Name = "mnumanagecustomer";
            this.mnumanagecustomer.Size = new System.Drawing.Size(215, 22);
            this.mnumanagecustomer.Text = "Quản lý khách hàng";
            this.mnumanagecustomer.Click += new System.EventHandler(this.mnumanagecustomer_Click);
            // 
            // inMãĐơnHàngToolStripMenuItem
            // 
            this.inMãĐơnHàngToolStripMenuItem.Image = global::CASALE.Properties.Resources.images;
            this.inMãĐơnHàngToolStripMenuItem.Name = "inMãĐơnHàngToolStripMenuItem";
            this.inMãĐơnHàngToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.inMãĐơnHàngToolStripMenuItem.Text = "In mã đơn hàng";
            this.inMãĐơnHàngToolStripMenuItem.Visible = false;
            // 
            // mnumanageimex
            // 
            this.mnumanageimex.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnsaleimportproducts,
            this.mnsaleexportproducts,
            this.toolStripSeparator4,
            this.mnumanageimportexportorders});
            this.mnumanageimex.ForeColor = System.Drawing.Color.White;
            this.mnumanageimex.Image = global::CASALE.Properties.Resources.book_red;
            this.mnumanageimex.Name = "mnumanageimex";
            this.mnumanageimex.Size = new System.Drawing.Size(113, 20);
            this.mnumanageimex.Text = "QL.Nhập Xuất";
            // 
            // mnsaleimportproducts
            // 
            this.mnsaleimportproducts.Image = global::CASALE.Properties.Resources.books;
            this.mnsaleimportproducts.Name = "mnsaleimportproducts";
            this.mnsaleimportproducts.Size = new System.Drawing.Size(217, 22);
            this.mnsaleimportproducts.Text = "Nhập hàng";
            this.mnsaleimportproducts.Click += new System.EventHandler(this.mnsaleimportproducts_Click);
            // 
            // mnsaleexportproducts
            // 
            this.mnsaleexportproducts.Image = global::CASALE.Properties.Resources.books;
            this.mnsaleexportproducts.Name = "mnsaleexportproducts";
            this.mnsaleexportproducts.Size = new System.Drawing.Size(217, 22);
            this.mnsaleexportproducts.Text = "Xuất hàng";
            this.mnsaleexportproducts.Click += new System.EventHandler(this.mnsaleexportproducts_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(214, 6);
            // 
            // mnumanageimportexportorders
            // 
            this.mnumanageimportexportorders.Image = global::CASALE.Properties.Resources.books;
            this.mnumanageimportexportorders.Name = "mnumanageimportexportorders";
            this.mnumanageimportexportorders.Size = new System.Drawing.Size(217, 22);
            this.mnumanageimportexportorders.Text = "Quản lý hóa đơn nhập xuất";
            this.mnumanageimportexportorders.Click += new System.EventHandler(this.mnumanageimportexportorders_Click);
            // 
            // mnureport
            // 
            this.mnureport.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmnreportsale,
            this.mnunhapxuatton,
            this.mnureportsale,
            this.toolStripMenuItem2,
            this.mnureportimcom,
            this.biểuĐồKinhDoanhToolStripMenuItem});
            this.mnureport.ForeColor = System.Drawing.Color.White;
            this.mnureport.Image = global::CASALE.Properties.Resources.calculator;
            this.mnureport.Name = "mnureport";
            this.mnureport.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.K)));
            this.mnureport.Size = new System.Drawing.Size(139, 20);
            this.mnureport.Text = "Báo cáo - Thống kê";
            this.mnureport.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmnreportsale
            // 
            this.cmnreportsale.Image = global::CASALE.Properties.Resources.books1;
            this.cmnreportsale.Name = "cmnreportsale";
            this.cmnreportsale.Size = new System.Drawing.Size(203, 22);
            this.cmnreportsale.Text = "Báo cáo bán hàng";
            this.cmnreportsale.Click += new System.EventHandler(this.cmnreportsale_Click);
            // 
            // mnunhapxuatton
            // 
            this.mnunhapxuatton.Image = global::CASALE.Properties.Resources.books1;
            this.mnunhapxuatton.Name = "mnunhapxuatton";
            this.mnunhapxuatton.Size = new System.Drawing.Size(203, 22);
            this.mnunhapxuatton.Text = "Thống kê nhập-xuất-tồn";
            this.mnunhapxuatton.Click += new System.EventHandler(this.mnunhapxuatton_Click);
            // 
            // mnureportsale
            // 
            this.mnureportsale.Image = global::CASALE.Properties.Resources.books1;
            this.mnureportsale.Name = "mnureportsale";
            this.mnureportsale.Size = new System.Drawing.Size(203, 22);
            this.mnureportsale.Text = "Báo cáo kinh doanh";
            this.mnureportsale.Click += new System.EventHandler(this.mnureportsale_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(200, 6);
            // 
            // mnureportimcom
            // 
            this.mnureportimcom.Image = global::CASALE.Properties.Resources.bieudo;
            this.mnureportimcom.Name = "mnureportimcom";
            this.mnureportimcom.Size = new System.Drawing.Size(203, 22);
            this.mnureportimcom.Text = "Biểu đồ doanh thu";
            this.mnureportimcom.Click += new System.EventHandler(this.mnureportimcom_Click);
            // 
            // biểuĐồKinhDoanhToolStripMenuItem
            // 
            this.biểuĐồKinhDoanhToolStripMenuItem.Image = global::CASALE.Properties.Resources.bieudo;
            this.biểuĐồKinhDoanhToolStripMenuItem.Name = "biểuĐồKinhDoanhToolStripMenuItem";
            this.biểuĐồKinhDoanhToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.biểuĐồKinhDoanhToolStripMenuItem.Text = "Biểu đồ kinh doanh";
            this.biểuĐồKinhDoanhToolStripMenuItem.Visible = false;
            // 
            // mntrogiup
            // 
            this.mntrogiup.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuintroduction,
            this.mnuregisterlicense,
            this.toolStripSeparator3,
            this.mnuaboutus});
            this.mntrogiup.ForeColor = System.Drawing.Color.White;
            this.mntrogiup.Image = global::CASALE.Properties.Resources.books_preferences1;
            this.mntrogiup.Name = "mntrogiup";
            this.mntrogiup.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.H)));
            this.mntrogiup.Size = new System.Drawing.Size(82, 20);
            this.mntrogiup.Text = "Trợ giúp";
            this.mntrogiup.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mnuintroduction
            // 
            this.mnuintroduction.Image = global::CASALE.Properties.Resources.window_view;
            this.mnuintroduction.Name = "mnuintroduction";
            this.mnuintroduction.Size = new System.Drawing.Size(225, 22);
            this.mnuintroduction.Text = "Hướng dẫn sử dụng";
            this.mnuintroduction.Click += new System.EventHandler(this.mnuintroduction_Click);
            // 
            // mnuregisterlicense
            // 
            this.mnuregisterlicense.Name = "mnuregisterlicense";
            this.mnuregisterlicense.Size = new System.Drawing.Size(225, 22);
            this.mnuregisterlicense.Text = "Đăng ký sử dụng phần mềm";
            this.mnuregisterlicense.ToolTipText = "Đăng ký quyền sử dụng phần mềm của bạn.";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(222, 6);
            // 
            // mnuaboutus
            // 
            this.mnuaboutus.Image = global::CASALE.Properties.Resources.user1_back;
            this.mnuaboutus.Name = "mnuaboutus";
            this.mnuaboutus.Size = new System.Drawing.Size(225, 22);
            this.mnuaboutus.Text = "Về chúng tôi";
            this.mnuaboutus.Click += new System.EventHandler(this.mnuaboutus_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblcompany);
            this.panel1.Controls.Add(this.lbllicensestatus);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 367);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(743, 18);
            this.panel1.TabIndex = 8;
            // 
            // lblcompany
            // 
            this.lblcompany.AutoSize = true;
            this.lblcompany.ForeColor = System.Drawing.Color.Black;
            this.lblcompany.Location = new System.Drawing.Point(5, 3);
            this.lblcompany.Name = "lblcompany";
            this.lblcompany.Size = new System.Drawing.Size(38, 15);
            this.lblcompany.TabIndex = 4;
            this.lblcompany.Text = "label2";
            // 
            // lbllicensestatus
            // 
            this.lbllicensestatus.AutoSize = true;
            this.lbllicensestatus.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbllicensestatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.lbllicensestatus.Location = new System.Drawing.Point(2, 3);
            this.lbllicensestatus.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbllicensestatus.Name = "lbllicensestatus";
            this.lbllicensestatus.Size = new System.Drawing.Size(15, 13);
            this.lbllicensestatus.TabIndex = 3;
            this.lbllicensestatus.Text = "  ";
            this.lbllicensestatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Right;
            this.label3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.label3.Location = new System.Drawing.Point(423, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(276, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Copyright © 2013 Tạo bởi Tony_Cường.";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Right;
            this.label1.Image = global::CASALE.Properties.Resources.icon1;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.Location = new System.Drawing.Point(699, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 18);
            this.label1.TabIndex = 1;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CASALE.Properties.Resources.logo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(743, 407);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.Window;
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "frmMain";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Controls.SetChildIndex(this.menuStrip1, 0);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnumaincontrol;
        private System.Windows.Forms.ToolStripMenuItem mnusyssetting;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem mnucloseprogram;
        private System.Windows.Forms.ToolStripMenuItem mnusaleimportexport;
        private System.Windows.Forms.ToolStripMenuItem mnusaleorder;
        private System.Windows.Forms.ToolStripMenuItem mnsaleorderexecuting;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem cmnhq;
        private System.Windows.Forms.ToolStripMenuItem mndata;
        private System.Windows.Forms.ToolStripMenuItem mnunit;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem mnuproductsmanagement;
        private System.Windows.Forms.ToolStripMenuItem mnumanageproviders;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem mnumanagecustomer;
        private System.Windows.Forms.ToolStripMenuItem inMãĐơnHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnumanageimex;
        private System.Windows.Forms.ToolStripMenuItem mnsaleimportproducts;
        private System.Windows.Forms.ToolStripMenuItem mnsaleexportproducts;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem mnumanageimportexportorders;
        private System.Windows.Forms.ToolStripMenuItem mnureport;
        private System.Windows.Forms.ToolStripMenuItem cmnreportsale;
        private System.Windows.Forms.ToolStripMenuItem mnunhapxuatton;
        private System.Windows.Forms.ToolStripMenuItem mnureportsale;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem mnureportimcom;
        private System.Windows.Forms.ToolStripMenuItem biểuĐồKinhDoanhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mntrogiup;
        private System.Windows.Forms.ToolStripMenuItem mnuintroduction;
        private System.Windows.Forms.ToolStripMenuItem mnuregisterlicense;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem mnuaboutus;
        private System.Windows.Forms.ToolStripMenuItem mndanhsachnguoidung;
        private System.Windows.Forms.ToolStripMenuItem mnphanquyen;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbllicensestatus;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblcompany;
    }
}

