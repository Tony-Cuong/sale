﻿namespace CASALE
{
    partial class barcodecontrol
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmnprintnotprint = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.cmnudelete = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmnprintnotprint,
            this.toolStripMenuItem1,
            this.cmnudelete});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(178, 54);
            // 
            // cmnprintnotprint
            // 
            this.cmnprintnotprint.Image = global::CASALE.Properties.Resources.action_delete;
            this.cmnprintnotprint.Name = "cmnprintnotprint";
            this.cmnprintnotprint.Size = new System.Drawing.Size(177, 22);
            this.cmnprintnotprint.Text = "Không in phiếu này";
            this.cmnprintnotprint.Click += new System.EventHandler(this.cmnprintnotprint_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(174, 6);
            // 
            // cmnudelete
            // 
            this.cmnudelete.Image = global::CASALE.Properties.Resources.trash_can;
            this.cmnudelete.Name = "cmnudelete";
            this.cmnudelete.Size = new System.Drawing.Size(177, 22);
            this.cmnudelete.Text = "Xóa mã vạch này";
            this.cmnudelete.Click += new System.EventHandler(this.cmnudelete_Click);
            // 
            // barcodecontrol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Name = "barcodecontrol";
            this.Size = new System.Drawing.Size(200, 80);
            this.Load += new System.EventHandler(this.barcodecontrol_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.barcodecontrol_Paint);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cmnprintnotprint;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cmnudelete;
    }
}
