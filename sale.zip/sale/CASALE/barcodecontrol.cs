﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using CASALE.Class;

namespace CASALE
{
    public partial class barcodecontrol : UserControl
    {
        int _index = 0;

        public int Index
        {
            get { return _index; }
            set { _index = value; }
        }

        string _title = "Sample product";

        public string PrintTitle
        {
            get { return _title; }
            set { _title = value; }
        }

        string _code = "123456789";

        Font _ftitle = new Font("Tahoma", 7, System.Drawing.GraphicsUnit.Point);

        public Font FontTitle
        {
            get { return _ftitle; }
            set { _ftitle = value; }
        }
        Font _fcode = new Font("Tahoma", 7, System.Drawing.GraphicsUnit.Point);

        public Font FontCode
        {
            get { return _fcode; }
            set { _fcode = value; }
        }


        public string PrintCode
        {
            get { return _code; }
            set { _code = value; }
        }

        string _price = "16500.50";

        public string PrintPrice
        {
            get { return _price; }
            set { _price = value; }
        }
        Font _fprice = new Font("Tahoma", 7, System.Drawing.GraphicsUnit.Point);

        public Font FontPrice
        {
            get { return _fprice; }
            set { _fprice = value; }
        }


        int _ibarheight = 22;

        public int BarHeight
        {
            get { return _ibarheight; }
            set { _ibarheight = value; }
        }
        int _ibarwidth = 142;

        public int BarWidth
        {
            get { return _ibarwidth; }
            set
            {
                if (Width < 120) Width = 120;
                if (_ibarwidth < 120) _ibarwidth = 120;
                if (_ibarwidth > this.Width) _ibarwidth = Width;

                _ibarwidth = value;
            }
        }

        bool _Enable = true;

        public bool PrintEnable
        {
            get { return _Enable; }
            set
            {
                _Enable = value;
                if (PrintEnable == false)
                {
                    cmnprintnotprint.Text = "In phiếu này";
                    if (PrintBarCodeList.NotPrintItems.IndexOf(Index) < 0)
                    {
                        PrintBarCodeList.NotPrintItems.Add(Index);
                    }
                }
                else
                {
                    cmnprintnotprint.Text = "Không in phiếu này";
                    PrintBarCodeList.NotPrintItems.Remove(Index);
                }
            }
        }
        public barcodecontrol()
        {
            InitializeComponent();
        }

        private void barcodecontrol_Load(object sender, EventArgs e)
        {

        }

        private void barcodecontrol_Paint(object sender, PaintEventArgs e)
        {
            if (_Enable == true)
            {
                float x = 0, y = 8;
                //x = Width / 2 + 3;
                x = 10;
                StringFormat f = new StringFormat();
                f.Alignment = StringAlignment.Near;

                e.Graphics.DrawString(_title, _ftitle, Brushes.Black, x, y, f);

                y += _ftitle.Height + 2;


                BarcodeLib.AlignmentPositions Align = BarcodeLib.AlignmentPositions.CENTER;
                Align = BarcodeLib.AlignmentPositions.CENTER;
                BarcodeLib.TYPE type = BarcodeLib.TYPE.CODE128;

                BarcodeLib.Barcode b = new BarcodeLib.Barcode();
                b.IncludeLabel = false;
                b.Alignment = Align;
                b.LabelPosition = BarcodeLib.LabelPositions.BOTTOMLEFT;
                b.LabelFont = _fcode;
                x = 0;
                e.Graphics.DrawImage(b.Encode(type, _code, Color.Black, this.BackColor, BarWidth, _ibarheight), x, y);

                x = 10;
                y += _ibarheight;
                f = new StringFormat();
                f.Alignment = StringAlignment.Far;

                e.Graphics.DrawString(_code, _fcode, Brushes.Black, x, y);
                e.Graphics.DrawString(_price + " " + Common.MoneyUnit, _fprice, Brushes.Black, new RectangleF(x, y, BarWidth - 25, 20), f);
            }
        }

        private void cmnprintnotprint_Click(object sender, EventArgs e)
        {
            if (PrintEnable == true)
            {
                PrintEnable = false;
                cmnprintnotprint.Text = "In phiếu này";
                if (PrintBarCodeList.NotPrintItems.IndexOf(Index) < 0)
                {
                    PrintBarCodeList.NotPrintItems.Add(Index);
                }
            }
            else
            {
                PrintEnable = true;
                cmnprintnotprint.Text = "Không in phiếu này";
                PrintBarCodeList.NotPrintItems.Remove(Index);
            } 
        }

        private void cmnudelete_Click(object sender, EventArgs e)
        {
            if (Index > -1 && Index < frmbarcode.PrintBCodeList.Count)
            {
                frmbarcode.PrintBCodeList.RemoveAt(Index);
                frmbarcode.PrintBCodeList.ReOrder();
            }
        }
    }

    public class PrintBarCodeList : List<barcodecontrol>
    {
        public PrintBarCodeList()
        {
            NotPrintItems = new ArrayList();
        }
        public void ReOrder()
        {
            for (int i = 0; i < Count; i++)
            {
                this[i].Index = i;
            }
        }

        public static int iexecuteindex = -1;
        public static ArrayList NotPrintItems = new ArrayList();

        public void FormatList()
        {
            for (int i = 0; i < Count; i++)
            {
                if (NotPrintItems.IndexOf(i) > -1)
                {
                    this[i].PrintEnable = false;
                }
                else
                {
                    this[i].PrintEnable = true;
                }
            }
        }
        public void FormatList(int ifrom, int ito)
        {
            if (ito > Count) ito = Count;
            for (int i = ifrom; i < ito; i++)
            {
                if (NotPrintItems.IndexOf(i) > -1)
                {
                    this[i].PrintEnable = false;
                }
                else
                {
                    this[i].PrintEnable = true;
                }
            }
        }
    }
}
