﻿namespace CASALE
{
    partial class barcodecontrolinsertitems
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.rdafter = new System.Windows.Forms.RadioButton();
            this.rdbefore = new System.Windows.Forms.RadioButton();
            this.nitems = new System.Windows.Forms.NumericUpDown();
            this.btnadd = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nitems)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(16, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 15);
            this.label1.TabIndex = 15;
            this.label1.Text = "Vị trí";
            // 
            // rdafter
            // 
            this.rdafter.AutoSize = true;
            this.rdafter.Location = new System.Drawing.Point(148, 21);
            this.rdafter.Name = "rdafter";
            this.rdafter.Size = new System.Drawing.Size(45, 19);
            this.rdafter.TabIndex = 14;
            this.rdafter.Text = "Sau";
            this.rdafter.UseVisualStyleBackColor = true;
            // 
            // rdbefore
            // 
            this.rdbefore.AutoSize = true;
            this.rdbefore.Checked = true;
            this.rdbefore.Location = new System.Drawing.Point(91, 21);
            this.rdbefore.Name = "rdbefore";
            this.rdbefore.Size = new System.Drawing.Size(57, 19);
            this.rdbefore.TabIndex = 13;
            this.rdbefore.TabStop = true;
            this.rdbefore.Text = "Trước";
            this.rdbefore.UseVisualStyleBackColor = true;
            // 
            // nitems
            // 
            this.nitems.Location = new System.Drawing.Point(91, 44);
            this.nitems.Maximum = new decimal(new int[] {
            39,
            0,
            0,
            0});
            this.nitems.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nitems.Name = "nitems";
            this.nitems.Size = new System.Drawing.Size(36, 22);
            this.nitems.TabIndex = 12;
            this.nitems.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnadd
            // 
            this.btnadd.Location = new System.Drawing.Point(91, 73);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(85, 23);
            this.btnadd.TabIndex = 11;
            this.btnadd.Text = "Thêm vào";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.DimGray;
            this.label9.Location = new System.Drawing.Point(16, 46);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 15);
            this.label9.TabIndex = 10;
            this.label9.Text = "Số mã vạch";
            // 
            // barcodecontrolinsertitems
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(265, 121);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rdafter);
            this.Controls.Add(this.rdbefore);
            this.Controls.Add(this.nitems);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.label9);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "barcodecontrolinsertitems";
            this.Text = "Thêm mã vạch";
            this.Load += new System.EventHandler(this.barcodecontrolinsertitems_Load);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.btnadd, 0);
            this.Controls.SetChildIndex(this.nitems, 0);
            this.Controls.SetChildIndex(this.rdbefore, 0);
            this.Controls.SetChildIndex(this.rdafter, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.nitems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdafter;
        private System.Windows.Forms.RadioButton rdbefore;
        private System.Windows.Forms.NumericUpDown nitems;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Label label9;
    }
}