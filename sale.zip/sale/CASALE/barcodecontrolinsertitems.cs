﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CASALE
{
    public partial class barcodecontrolinsertitems : templates
    {
        public static int Index = 0;
        public barcodecontrolinsertitems()
        {
            InitializeComponent();
        }

        private void barcodecontrolinsertitems_Load(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (frmbarcode.PrintBCodeList.Count < 41)
            {
                if (nitems.Value < 41 - frmbarcode.PrintBCodeList.Count)
                {
                    for (int i = 0; i < nitems.Value; i++)
                    {
                        if (rdbefore.Checked == true)
                        {
                            barcodecontrol bcc = new barcodecontrol();
                            bcc.Index = i;
                            bcc.Width = 142;
                            bcc.Height = 70;
                            bcc.BarWidth = 140;
                            bcc.BarHeight = 22;
                            bcc.PrintCode = "000000";
                            bcc.PrintTitle = "";
                            bcc.PrintEnable = false;
                            bcc.PrintPrice = "";
                            frmbarcode.PrintBCodeList.Insert(Index, bcc);
                        }
                        else
                        {
                            barcodecontrol bcc = new barcodecontrol();
                            bcc.Index = i;
                            bcc.Width = 142;
                            bcc.Height = 70;
                            bcc.BarWidth = 140;
                            bcc.BarHeight = 22;
                            bcc.PrintCode = "000000";
                            bcc.PrintTitle = "";
                            bcc.PrintEnable = false;
                            bcc.PrintPrice = "";

                            frmbarcode.PrintBCodeList.Add(bcc);
                        }
                        frmbarcode.PrintBCodeList.ReOrder();
                        frmbarcode.PrintBCodeList.FormatList();
                    }
                }
            }
            this.Close();
        }
    }
}
