﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LCMultiUtilities;
using CASALE.Class;
using System.Data.OleDb;
using LCProductCartUtiliti;

namespace CASALE
{
    public partial class frmBanhang : templates
    {
        int icartdetailproductid = -1;
        int icustomerid = -1;
        protected float _strsummoney = 0;
        
        public frmBanhang()
        {
            InitializeComponent();
        }

        private void frmBanhang_Load(object sender, EventArgs e)
        {
            
            txtId.Text = Common.OrderCode;
            txtcustomername.Text = "Khách hàng lẻ";
            DataTable orderdetailstatus = Common.OrderStatusNotIncludeAll;
            cmbordersliststatus.DataSource = orderdetailstatus;
            cmbordersliststatus.DisplayMember = "Status";
            cmbordersliststatus.ValueMember = "ID";
            cmbordersliststatus.SelectedValue = Common.DefaultOrderStatus;
            txtproductid.Focus();
        }

        private void btncusgetinformation_Click(object sender, EventArgs e)
        {
            if (txtcusid.Text.Length > 0)
            {
                DataTable dt = new DataTable();
                string[] searchfield = { "vkey" };
                dt = mssql_multicates_multidb_items.dicts_cate_items_incate_v3(-1,
                    Common.capp_customer_code, Common.vietnames, -1,
                    false, false, false, "", 1, txtcusid.Text.Trim(), searchfield,
                    false, "", "", Common.ConnectionString);
                if (dt.Rows.Count > 0)
                {
                    icustomerid = Convert.ToInt32(dt.Rows[0]["iid"]);
                    dt = mssql_multicates_multidb_items.dicts_items_GetDetailByID(icustomerid.ToString(), Common.capp_customer_code, Common.ConnectionString);
                    if (dt.Rows.Count > 0)
                    {
                        txtcusid.Text = dt.Rows[0]["vkey"].ToString();
                        txtcustomername.Text = dt.Rows[0]["vtitle"].ToString();
                        txtcustomeraddress.Text = dt.Rows[0]["vdesc"].ToString();
                        txtcustomerphone.Text = dt.Rows[0]["vauthor"].ToString();
                        txtcustomeremail.Text = dt.Rows[0]["vurl"].ToString();
                        txtcustomerinformation.Text = dt.Rows[0]["vcontent"].ToString();
                    }
                }
            }
        }

        private void txtcusid_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Enter)
            {
                btncusgetinformation_Click(sender, e);
            }
        }

        private void txtproductid_KeyUp(object sender, KeyEventArgs e)
        {
            if (!txtproductid.Text.Trim().Equals(""))
            {
                if (e.KeyCode == Keys.Enter)
                {
                    string[] arrsearchfields = { "vkey" };

                    DataTable dt = mssql_multicates_multidb_items.
                        dicts_cate_items_incate_v3(
                        -1, Common.capp_product_code,
                        Common.vietnames, -1, true, false, false, "",
                        1, txtproductid.Text,
                        arrsearchfields, false, "", "", Common.ConnectionString);
                    if (dt.Rows.Count > 0)
                    {
                        txtproductid.Text = dt.Rows[0]["vkey"].ToString();
                        txtPrice.Text = dt.Rows[0]["vauthor"].ToString();
                        txttax.Text = dt.Rows[0]["vurl"].ToString();
                        txtnamesale.Text = dt.Rows[0]["vtitle"].ToString();
                        txtunit.Text = dt.Rows[0]["vunit"].ToString();
                        icartdetailproductid = Convert.ToInt32(dt.Rows[0]["iid"].ToString());
                        txtQuantity.Focus();
                        lvicd.Visible = false;
                    }
                }
            }
        }

        private void txtproductid_Leave(object sender, EventArgs e)
        {
            //if (txtproductid.Text.Trim().Length > 0)
            //{
            //    if (txtnamesale.Text.Length < 1)
            //    {
            //        string[] arrsearchfields = { "vkey" };
            //        DataTable dt = mssql_multicates_multidb_items.
            //                dicts_cate_items_incate_v3(
            //                -1, Common.capp_product_code,
            //                Common.vietnames, -1, true, false, false, "",
            //                1, txtproductid.Text,
            //                arrsearchfields, false, "", "", Common.ConnectionString);
            //        if (dt.Rows.Count > 0)
            //        {
            //            txtproductid.Text = dt.Rows[0]["vkey"].ToString();
            //            txtPrice.Text = dt.Rows[0]["vauthor"].ToString();
            //            txttax.Text = dt.Rows[0]["vurl"].ToString();
            //            txtnamesale.Text = dt.Rows[0]["vtitle"].ToString();
            //            txtunit.Text = dt.Rows[0]["vunit"].ToString();
            //            icartdetailproductid = Convert.ToInt32(dt.Rows[0]["iid"].ToString());
            //            txtQuantity.Focus();
            //            lvicd.Visible = false;
            //        }
            //        else
            //        {
            //            txtproductid.Focus();
            //        }
            //    }
            //}
        }
        #region "ORDER"
        DataTable dtorderdetails = new DataTable();
        void OrderCreateColumns()
        {
            if (dtorderdetails.Columns.Count < 1)
            {
                dtorderdetails.Columns.Add("ID", typeof(Int32));
                dtorderdetails.Columns.Add("Code", typeof(String));
                dtorderdetails.Columns.Add("Name", typeof(String));
                dtorderdetails.Columns.Add("Unit", typeof(String));
                dtorderdetails.Columns.Add("Price", typeof(Double));
                dtorderdetails.Columns.Add("Quantity", typeof(Double));
                dtorderdetails.Columns.Add("Tax", typeof(float));
            }
        }
        void OrderAddProduct(int iproductid, string sproductcode, string productname, string productunit, float fprice, double iquantity, float ftax)
        {
            if (iproductid > -1 && sproductcode.Length > 0)
            {
                OrderCreateColumns();
                if (dtorderdetails.Select("ID=" + iproductid.ToString()).Length > 0)
                {
                    // tôn tại sản phẩm trong cart rồi
                    // cập nhật số lượng
                    for (int i = 0; i < dtorderdetails.Rows.Count; i++)
                    {
                        if (Convert.ToInt32(dtorderdetails.Rows[i]["ID"]) == iproductid)
                        {
                            dtorderdetails.Rows[i]["Quantity"] = Convert.ToDouble(dtorderdetails.Rows[i]["Quantity"]) + iquantity;
                            break;
                        }
                    }
                }
                else
                {
                    // thêm mới vào dtorderdetails
                    DataRow dr = dtorderdetails.NewRow();
                    dr["ID"] = iproductid;
                    dr["Code"] = sproductcode;
                    dr["Name"] = productname;
                    dr["Unit"] = productunit;
                    dr["Price"] = fprice;
                    dr["Quantity"] = iquantity;
                    dr["Tax"] = ftax;

                    dtorderdetails.Rows.Add(dr);
                }
                OrderLoadCartDetails();
            }
        }

        void OrderLoadCartDetails()
        {
            lvitems.Items.Clear();
            // load tu dtorderdetails vào listview.
            //DataTable tb = new DataTable();
            double ftotal = 0;
            for (int i = 0; i < dtorderdetails.Rows.Count; i++)
            {
                ListViewItem lvi = new ListViewItem(dtorderdetails.Rows[i]["ID"].ToString());
                lvi.SubItems.Add((i + 1).ToString());
                lvi.SubItems.Add(dtorderdetails.Rows[i]["Code"].ToString());
                lvi.SubItems.Add(dtorderdetails.Rows[i]["Name"].ToString());
                lvi.SubItems.Add(dtorderdetails.Rows[i]["Unit"].ToString());
                lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dtorderdetails.Rows[i]["Price"].ToString()));
                lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dtorderdetails.Rows[i]["Quantity"].ToString()));
                lvi.SubItems.Add(dtorderdetails.Rows[i]["Tax"].ToString());
                double itemtotal =
                    (Convert.ToDouble(dtorderdetails.Rows[i]["Price"].ToString()) * Convert.ToDouble(dtorderdetails.Rows[i]["Quantity"].ToString())) +
                    (Convert.ToDouble(dtorderdetails.Rows[i]["Price"].ToString()) * Convert.ToDouble(dtorderdetails.Rows[i]["Quantity"].ToString()))
                    * Convert.ToDouble(dtorderdetails.Rows[i]["Tax"]) / 100;

                lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(itemtotal.ToString()));
                ftotal += itemtotal;
                lvitems.Items.Add(lvi);
            }
            lblcarttotal.Text = ftotal.ToString();
            txtdoc.Text = "Tổng tiền thanh toán: "+ LCUtiliti.ConvertNumber.ConvertNumberToString(long.Parse(ftotal.ToString()));
            txttongtien.Text = LCUtiliti.ConvertNumber.FomatPrice(ftotal.ToString());
            label12.Text = LCUtiliti.ConvertNumber.FomatPrice(ftotal.ToString());
            txttienkhach.Text = ftotal.ToString();
        }
        /// <summary>
        /// Xóa sản phẩm khỏi cart.
        /// </summary>
        /// <param name="iproductid"></param>
        void OrderDeleteProductFromCart(int iproductid)
        {
            for (int i = dtorderdetails.Rows.Count - 1; i > -1; i--)
            {
                if (Convert.ToInt32(dtorderdetails.Rows[i]["ID"]) == iproductid)
                {
                    dtorderdetails.Rows.RemoveAt(i);
                    break;
                }
            }
            OrderLoadCartDetails();
        }
        #endregion
        public static int ReturnQuantity(string vkey, string constr)
        {
            string sql = "select iquantity from dicts_items where vkey = '" + vkey + "'";
            OleDbCommand cmd = new OleDbCommand(sql);
            cmd.CommandType = CommandType.Text;
            return Convert.ToInt32(SQL_Db.DB_Data.GetData(cmd, constr).Rows[0]["iquantity"]);
        }
        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
            _strsummoney = 0;
            if (txtproductid.Text.Trim().Equals("") || txtPrice.Text.Trim().Equals("") || txtQuantity.Text.Trim().Equals("") || txtnamesale.Text.Trim().Equals(""))
            {
                txtproductid.Text = txtproductid.Text;
                txtQuantity.Text = "1";

                return;
            }
            int quantity = ReturnQuantity(txtproductid.Text.Trim(), Common.ConnectionString);
            if (Convert.ToDouble(txtQuantity.Text) > quantity)
            {
                MessageBox.Show("Số lượng trong kho hàng không đủ.\n\r Còn : " + quantity + " sản phẩm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            OrderAddProduct(icartdetailproductid, txtproductid.Text, txtnamesale.Text, txtunit.Text,
                Convert.ToSingle(txtPrice.Text),
                Convert.ToDouble(txtQuantity.Text), Convert.ToSingle(txttax.Text));

            #region  đếm cột
            //if (lvItems.Items.Count > 0)
            //{
            //    for (int i = 0; i < lvItems.Items.Count; i++)
            //    {
            //        _strsummoney +=Convert.ToSingle(lvItems.Items[i].SubItems[7].Text.ToString());
            //    }
            //}
            //lblcarttotal.Text =_strsummoney.ToString();
            #endregion

            }
            catch (Exception ex)
            {
                ;
            }
            txtnamesale.Text = "";
            txtQuantity.Text = "1";
            txtproductid.Text = "";
            txtunit.Text = "";
            txtPrice.Text = "";
            txtproductid.Focus();
            icartdetailproductid = -1;
        }

        private void txttienkhach_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
            if (e.KeyCode == Keys.Enter)
            {
                txtreturn.Text = LCUtiliti.ConvertNumber.FomatPrice((Convert.ToDouble(txttienkhach.Text) - Convert.ToDouble(lblcarttotal.Text)).ToString());
            }
            }
            catch (Exception ex)
            {
                ;
            }
        }

        private void txttienkhach_TextChanged(object sender, EventArgs e)
        {
            try
            {
                txtreturn.Text = LCUtiliti.ConvertNumber.FomatPrice((Convert.ToDouble(txttienkhach.Text) - Convert.ToDouble(lblcarttotal.Text)).ToString());
                //txttienkhach.Text = LCUtiliti.ConvertNumber.FomatPrice(txttienkhach.Text);
            }
            catch (Exception ex)
            {
                ;
            }
        }

        private void txtQuantity_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Enter)
            {
                btnOk_Click(sender, e);
            }
           
        }

        private void cmndelete_Click(object sender, EventArgs e)
        {
            if (lvitems.Items.Count > 0)
            {
                OrderDeleteProductFromCart(icartdetailproductid);
            }
            else
            {
                return;
            }
        }

        private void lvitems_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvitems.Items.Count > 0)
            {
                if (lvitems.SelectedItems.Count > 0)
                {
                    this.icartdetailproductid = Convert.ToInt32(lvitems.SelectedItems[0].SubItems[0].Text.ToString());
                }
            }
        }

        private void lvitems_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Delete)
            {
                if (lvitems.Items.Count > 0)
                {
                    OrderDeleteProductFromCart(icartdetailproductid);
                }
                else
                {
                    return;
                }
            }
        }

        private void btncalculatenprintcart_Click(object sender, EventArgs e)
        {
            double proquantity = 0;
            // 1. insert vao bảng cart
            int idcart = Cart.p_carts_insert(0,
                txtId.Text, -1, 0, -1, DateTime.Now, Convert.ToSingle(lblcarttotal.Text), Convert.ToInt32(cmbordersliststatus.SelectedValue),
                icustomerid, txtcustomername.Text, txtcustomeraddress.Text, txtcustomerphone.Text,
                txtcustomeremail.Text, "", "", "", "", DateTime.Now, Common.UserId, Common.UserName, Common.ConnectionString);

            // 2. insert vào bảng cart detail
            if (dtorderdetails.Rows.Count > 0)
            {
                for (int i = 0; i < dtorderdetails.Rows.Count; i++)
                {
                    int _irpostid = Convert.ToInt32(dtorderdetails.Rows[i]["ID"]);
                    string _vprice = dtorderdetails.Rows[i]["Price"].ToString();
                    double _inumber = Convert.ToDouble(dtorderdetails.Rows[i]["Quantity"]);
                    double _ftax = Convert.ToDouble(dtorderdetails.Rows[i]["Tax"]);
                    double itemtotal =
                    (Convert.ToDouble(dtorderdetails.Rows[i]["Price"].ToString()) * Convert.ToDouble(dtorderdetails.Rows[i]["Quantity"].ToString())) +
                    (Convert.ToDouble(dtorderdetails.Rows[i]["Price"].ToString()) * Convert.ToDouble(dtorderdetails.Rows[i]["Quantity"].ToString()))
                    * Convert.ToDouble(dtorderdetails.Rows[i]["Tax"]) / 100;
                    string _vmoney = itemtotal.ToString();
                    //MessageBox.Show(_vprice + " " + _inumber + " " + _ftax + " " + _vmoney);
                    Cart.p_cartdetails_quote_insert(idcart, _irpostid, Convert.ToSingle(_vprice),
                        _inumber, Convert.ToSingle(_vmoney), _ftax, dtorderdetails.Rows[i]["Code"].ToString(),
                        dtorderdetails.Rows[i]["Name"].ToString(),
                        dtorderdetails.Rows[i]["Unit"].ToString(), -1, "",
                        Common.ConnectionString);

                    proquantity += _inumber;
                }
            }

            // 3. insert vào bảng importexport
            int imexid = ImportExport.sale_objects_importexport_insert(
                txtId.Text,
                "",
                0,
                -1,
                -1,
                Convert.ToSingle(lblcarttotal.Text),
                proquantity,
                DateTime.Now,
                Common.UserId.ToString() + "|" + Common.UserName,
                "",
                2,
                Common.ConnectionString);


            // 4. insert vao bảng importexportdetails
            if (dtorderdetails.Rows.Count > 0)
            {
                for (int i = 0; i < dtorderdetails.Rows.Count; i++)
                {
                    int _irpostid = Convert.ToInt32(dtorderdetails.Rows[i]["ID"]);
                    string _vprice = dtorderdetails.Rows[i]["Price"].ToString();
                    double _inumber = Convert.ToDouble(dtorderdetails.Rows[i]["Quantity"]);
                    double _ftax = Convert.ToDouble(dtorderdetails.Rows[i]["Tax"]);
                    double itemtotal =
                    (Convert.ToDouble(dtorderdetails.Rows[i]["Price"].ToString()) * Convert.ToDouble(dtorderdetails.Rows[i]["Quantity"].ToString())) +
                    (Convert.ToDouble(dtorderdetails.Rows[i]["Price"].ToString()) * Convert.ToDouble(dtorderdetails.Rows[i]["Quantity"].ToString()))
                    * Convert.ToDouble(dtorderdetails.Rows[i]["Tax"]) / 100;
                    string _vmoney = itemtotal.ToString();

                    string _vunit = dtorderdetails.Rows[i]["Unit"].ToString();
                    string masp = dtorderdetails.Rows[i]["Code"].ToString();
                    string tensp = dtorderdetails.Rows[i]["Name"].ToString();
                    //MessageBox.Show(_vprice + " " + _inumber + " " + _ftax + " " + _vmoney);
                    //loi
                    ImportExportDetail.sale_objects_imexdetails_insert(
                        imexid,
                        _irpostid,
                         Convert.ToSingle(_vprice),
                         _inumber,
                         _ftax,
                         masp,
                        tensp, _vunit, 0, "",
                         Common.ConnectionString);

                    // cập nhật số lượng vào bảng sản phẩm để tính số lượng trong kho hàng.
                    this.dicts_items_update_custom_update(
                        _irpostid.ToString(),
                        " iquantity=iquantity - " + _inumber.ToString(),
                        Common.ConnectionString);
                }
            }


            if (Common.frmsaleorderprint == null)
                Common.frmsaleorderprint = new frmPrintOrderDetail();
            Common.frmsaleorderprint.iOrderDetailId = idcart;
            Common.frmsaleorderprint.TopMost = true;
            Common.frmsaleorderprint.ShowDialog();
            btncancelncreatenew_Click(sender, e);   
        }
        public void dicts_items_update_custom_update(string iid, string sql, string constr)
        {
            OleDbCommand cmd = new OleDbCommand("update dicts_items set dupdate=getdate()," + sql + " where iid=?");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@id", iid);
            SQL_Db.DB_Data.ExecuteNonQuery(cmd, constr);
        }
        private void btncancelncreatenew_Click(object sender, EventArgs e)
        {
            icustomerid = -1;// reset customer id.
            dtorderdetails.Rows.Clear();
            lvitems.Items.Clear();
            txtcusid.Text = "";
            txtcustomeraddress.Text = "";
            txtcustomeremail.Text = "";
            txtcustomerphone.Text = "";
            txtnamesale.Text = "";
            txtQuantity.Text = "1";
            txtproductid.Text = "";
            lblcarttotal.Text = "0";
            txtPrice.Text = "";
            txttienkhach.Text = "";
            txttongtien.Text = "";
            txtreturn.Text = "";
            txtdoc.Text = "";
            txtId.Text = Common.OrderCode;

            txtproductid.Focus();
            
        }
        private void loaddata(string str)
        {
            lvicd.Items.Clear();

            string[] arrsearchfields = { "vkey" };

            DataTable dt = mssql_multicates_multidb_items.
                dicts_cate_items_incate_v3(
                -1, Common.capp_product_code,
                Common.vietnames, -1, true, false, false, " di.vkey LIKE N'%" + str + "%'",
                1, txtproductid.Text,
                arrsearchfields, false, "", "", Common.ConnectionString);
             if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ListViewItem lvi = new ListViewItem(dt.Rows[i]["iid"].ToString());
                    lvi.SubItems.Add(dt.Rows[i]["vkey"].ToString());
                    lvi.SubItems.Add(dt.Rows[i]["vtitle"].ToString());
                    lvi.SubItems.Add(dt.Rows[i]["vunit"].ToString());
                    lvi.SubItems.Add(dt.Rows[i]["vfimg"].ToString());
                    lvi.SubItems.Add(dt.Rows[i]["vauthor"].ToString());
                    lvicd.Items.Add(lvi);
                }
            }
            else
            {
                lvicd.Visible = false;
            }

        }
        private int lastItm = 0;
        private void txtproductid_TextChanged(object sender, EventArgs e)
        {
            if (txtproductid.Text.Trim().Equals(""))
            {
                lvicd.Visible = false;
                return;
            }
            else
            {
                lvicd.Visible = true;
                loaddata(txtproductid.Text.Trim());

                //if (lvicd.Items.Count>0)
                //{
                bool find = false;
                for (int i = 0; i < lvicd.Items.Count; i++)
                {
                    for (int lst12 = lastItm; lst12 < lvicd.Items.Count; lst12++)
                    {
                        if (lvicd.Items[lst12].SubItems[1].Text.IndexOf(txtproductid.Text) > -1 | lvicd.Items[lst12].SubItems[1].Text.ToUpper().IndexOf(txtproductid.Text.ToUpper()) > -1)
                        {
                            lvicd.TopItem = lvicd.Items[lst12];
                            if (lastItm > 0) lvicd.Items[lastItm - 1].BackColor = Color.CadetBlue;
                            lvicd.Items[lst12].BackColor = Color.CadetBlue;
                            lvicd.Items[lst12].Selected = true;
                            lastItm = lst12 + 1;
                            find = true;
                            break;
                        }
                    }
                    if (find)
                        break;
                    lvicd.Visible = false;
                    //txtQuantity.Focus();
                }
                if (lastItm > 0) lvicd.Items[lastItm - 1].BackColor = Color.CadetBlue;
                lastItm = 0;
            }
        }

        private void lvicd_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                if (lvicd.Items.Count > 0)
                {
                    for (int i = 0; i < lvicd.Items.Count; i++)
                    {
                        if (lvicd.Items[i].Selected)
                        {
                            txtproductid.Text = lvicd.Items[i].SubItems[1].Text;

                            string[] arrsearchfields = { "vkey" };
                            DataTable dt = mssql_multicates_multidb_items.
                                dicts_cate_items_incate_v3(
                                -1, Common.capp_product_code,
                                Common.vietnames, -1, true, false, false, "",
                                1, txtproductid.Text,
                                arrsearchfields, false, "", "", Common.ConnectionString);
                            if (dt.Rows.Count > 0)
                            {
                                txtproductid.Text = dt.Rows[0]["vkey"].ToString();
                                txtPrice.Text = dt.Rows[0]["vauthor"].ToString();
                                txttax.Text = dt.Rows[0]["vurl"].ToString();
                                txtnamesale.Text = dt.Rows[0]["vtitle"].ToString();
                                txtunit.Text = dt.Rows[0]["vunit"].ToString();
                                icartdetailproductid = Convert.ToInt32(dt.Rows[0]["iid"].ToString());
                                txtQuantity.Focus();
                            }
                            lvicd.Visible = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ;
            }
        }

        private void lvicd_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (lvicd.Items.Count > 0)
                {
                    for (int i = 0; i < lvicd.Items.Count; i++)
                    {
                        if (lvicd.Items[i].Selected)
                        {
                            txtproductid.Text = lvicd.Items[i].SubItems[1].Text;
                            txtproductid.Focus();
                            lvicd.Visible = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ;
            }
        }

    }
}
