﻿using CASALE.Class;
namespace CASALE
{
    partial class frmBaocaobieudodt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.frmbaocaobieudodt = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rdbyyear = new System.Windows.Forms.RadioButton();
            this.cmbsalereporttypes = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnprintdiagram = new System.Windows.Forms.Button();
            this.dtpimexdatetime = new System.Windows.Forms.DateTimePicker();
            this.rdbymonth = new System.Windows.Forms.RadioButton();
            this.btndisplay = new System.Windows.Forms.Button();
            this.rdbyperiod = new System.Windows.Forms.RadioButton();
            this.dtpietodate = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.chrtsale = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chrtsale)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.rdbyyear);
            this.panel2.Controls.Add(this.cmbsalereporttypes);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.btnprintdiagram);
            this.panel2.Controls.Add(this.dtpimexdatetime);
            this.panel2.Controls.Add(this.rdbymonth);
            this.panel2.Controls.Add(this.btndisplay);
            this.panel2.Controls.Add(this.rdbyperiod);
            this.panel2.Controls.Add(this.dtpietodate);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(0, 32);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(766, 47);
            this.panel2.TabIndex = 20;
            // 
            // rdbyyear
            // 
            this.rdbyyear.AutoSize = true;
            this.rdbyyear.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdbyyear.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.rdbyyear.Location = new System.Drawing.Point(219, 2);
            this.rdbyyear.Name = "rdbyyear";
            this.rdbyyear.Size = new System.Drawing.Size(51, 17);
            this.rdbyyear.TabIndex = 21;
            this.rdbyyear.Text = "Năm";
            this.rdbyyear.UseVisualStyleBackColor = true;
            this.rdbyyear.CheckedChanged += new System.EventHandler(this.rdbymonth_CheckedChanged);
            // 
            // cmbsalereporttypes
            // 
            this.cmbsalereporttypes.FormattingEnabled = true;
            this.cmbsalereporttypes.Location = new System.Drawing.Point(6, 22);
            this.cmbsalereporttypes.Name = "cmbsalereporttypes";
            this.cmbsalereporttypes.Size = new System.Drawing.Size(140, 23);
            this.cmbsalereporttypes.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.label1.Location = new System.Drawing.Point(3, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "Loại báo cáo";
            // 
            // btnprintdiagram
            // 
            this.btnprintdiagram.Enabled = false;
            this.btnprintdiagram.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.btnprintdiagram.Location = new System.Drawing.Point(489, 20);
            this.btnprintdiagram.Name = "btnprintdiagram";
            this.btnprintdiagram.Size = new System.Drawing.Size(108, 25);
            this.btnprintdiagram.TabIndex = 18;
            this.btnprintdiagram.Text = "In biểu đồ";
            this.btnprintdiagram.UseVisualStyleBackColor = true;
            // 
            // dtpimexdatetime
            // 
            this.dtpimexdatetime.CustomFormat = "dd/MM/yyyy";
            this.dtpimexdatetime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpimexdatetime.Location = new System.Drawing.Point(156, 22);
            this.dtpimexdatetime.Name = "dtpimexdatetime";
            this.dtpimexdatetime.Size = new System.Drawing.Size(100, 22);
            this.dtpimexdatetime.TabIndex = 15;
            // 
            // rdbymonth
            // 
            this.rdbymonth.AutoSize = true;
            this.rdbymonth.Checked = true;
            this.rdbymonth.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdbymonth.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.rdbymonth.Location = new System.Drawing.Point(157, 2);
            this.rdbymonth.Name = "rdbymonth";
            this.rdbymonth.Size = new System.Drawing.Size(60, 17);
            this.rdbymonth.TabIndex = 13;
            this.rdbymonth.TabStop = true;
            this.rdbymonth.Text = "Tháng";
            this.rdbymonth.UseVisualStyleBackColor = true;
            this.rdbymonth.CheckedChanged += new System.EventHandler(this.rdbymonth_CheckedChanged);
            // 
            // btndisplay
            // 
            this.btndisplay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.btndisplay.Location = new System.Drawing.Point(382, 20);
            this.btndisplay.Name = "btndisplay";
            this.btndisplay.Size = new System.Drawing.Size(101, 25);
            this.btndisplay.TabIndex = 17;
            this.btndisplay.Text = "Hiển thị";
            this.btndisplay.UseVisualStyleBackColor = true;
            this.btndisplay.Click += new System.EventHandler(this.btndisplay_Click);
            // 
            // rdbyperiod
            // 
            this.rdbyperiod.AutoSize = true;
            this.rdbyperiod.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdbyperiod.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.rdbyperiod.Location = new System.Drawing.Point(272, 2);
            this.rdbyperiod.Name = "rdbyperiod";
            this.rdbyperiod.Size = new System.Drawing.Size(121, 17);
            this.rdbyperiod.TabIndex = 14;
            this.rdbyperiod.Text = "Khoảng thời gian";
            this.rdbyperiod.UseVisualStyleBackColor = true;
            this.rdbyperiod.CheckedChanged += new System.EventHandler(this.rdbymonth_CheckedChanged);
            // 
            // dtpietodate
            // 
            this.dtpietodate.CustomFormat = "dd/MM/yyyy";
            this.dtpietodate.Enabled = false;
            this.dtpietodate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpietodate.Location = new System.Drawing.Point(271, 22);
            this.dtpietodate.Name = "dtpietodate";
            this.dtpietodate.Size = new System.Drawing.Size(105, 22);
            this.dtpietodate.TabIndex = 16;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(766, 32);
            this.panel1.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(7, 9);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "BIỂU ĐỒ";
            // 
            // chrtsale
            // 
            chartArea4.AlignmentOrientation = ((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations)((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Vertical | System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Horizontal)));
            chartArea4.BackImageAlignment = System.Windows.Forms.DataVisualization.Charting.ChartImageAlignmentStyle.Left;
            chartArea4.Name = "Bieudo";
            this.chrtsale.ChartAreas.Add(chartArea4);
            this.chrtsale.Dock = System.Windows.Forms.DockStyle.Top;
            legend4.Alignment = System.Drawing.StringAlignment.Center;
            legend4.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Bottom;
            legend4.Name = "Legend1";
            legend4.TitleFont = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chrtsale.Legends.Add(legend4);
            this.chrtsale.Location = new System.Drawing.Point(0, 79);
            this.chrtsale.Name = "chrtsale";
            series4.ChartArea = "Bieudo";
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            this.chrtsale.Series.Add(series4);
            this.chrtsale.Size = new System.Drawing.Size(766, 373);
            this.chrtsale.TabIndex = 21;
            this.chrtsale.Text = "chart1";
            // 
            // frmBaocaobieudodt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 477);
            this.Controls.Add(this.chrtsale);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "frmBaocaobieudodt";
            this.Text = "Báo cáo biểu đồ";
            this.Load += new System.EventHandler(this.frmBaocaobieudodt_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.chrtsale, 0);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chrtsale)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rdbyyear;
        private System.Windows.Forms.ComboBox cmbsalereporttypes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnprintdiagram;
        private System.Windows.Forms.DateTimePicker dtpimexdatetime;
        private System.Windows.Forms.RadioButton rdbymonth;
        private System.Windows.Forms.Button btndisplay;
        private System.Windows.Forms.RadioButton rdbyperiod;
        private System.Windows.Forms.DateTimePicker dtpietodate;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chrtsale;
    }
}