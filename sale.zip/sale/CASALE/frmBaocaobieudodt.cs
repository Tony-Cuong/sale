﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LCProductCartUtiliti;
using CASALE.Class;

namespace CASALE
{
    public partial class frmBaocaobieudodt : templates
    {
        int idaytype = 0;// theo ngày/
        public frmBaocaobieudodt()
        {
            InitializeComponent();
        }
        DataTable dtreportsaletypes = new DataTable();
        DataTable LoadReportTypes()
        {
            if (dtreportsaletypes.Columns.Count < 1)
            {
                dtreportsaletypes.Columns.Add("ID", typeof(Int32));
                dtreportsaletypes.Columns.Add("Name", typeof(String));
            }
            if (dtreportsaletypes.Rows.Count < 1)
            {
                DataRow dr1 = dtreportsaletypes.NewRow();
                dr1["ID"] = 0;
                dr1["Name"] = "Bán hàng";
                dtreportsaletypes.Rows.Add(dr1);

                DataRow dr3 = dtreportsaletypes.NewRow();
                dr3["ID"] = 2;
                dr3["Name"] = "Nhập - Xuất";
                dtreportsaletypes.Rows.Add(dr3);
            }
            return dtreportsaletypes;
        }
        private void frmBaocaobieudodt_Load(object sender, EventArgs e)
        {
            cmbsalereporttypes.DataSource = LoadReportTypes();
            cmbsalereporttypes.DisplayMember = "Name";
            cmbsalereporttypes.ValueMember = "ID";
            ExecuteChooseByTime();
        }
        void ExecuteChooseByTime()
        {
            dtpimexdatetime.Format = DateTimePickerFormat.Custom;
            dtpietodate.Enabled = false;
            if (rdbymonth.Checked == true)
            {
                idaytype = 1;// theo tháng                
                dtpimexdatetime.CustomFormat = "MM/yyyy";
            }
            else if (rdbyyear.Checked == true)
            {
                idaytype = 0;
                dtpimexdatetime.CustomFormat = "yyyy";
            }
            else if (rdbyperiod.Checked == true)
            {
                idaytype = 3;// theo khoản thời gian
                dtpietodate.Enabled = true;
                dtpimexdatetime.CustomFormat = "dd/MM/yyyy";

            }
        }

        private void rdbymonth_CheckedChanged(object sender, EventArgs e)
        {
            ExecuteChooseByTime();
        }

        private void btndisplay_Click(object sender, EventArgs e)
        {
            chrtsale.Series.Clear();
            DataTable dt = new DataTable();
            if (Convert.ToInt32(cmbsalereporttypes.SelectedValue) == 0 || Convert.ToInt32(cmbsalereporttypes.SelectedValue) == 2)// báo cáo doanh thu, nhập xuất
            {
                chrtsale.Series.Add("Bán hàng");
                // xuất
                dt = ImportExport.sale_objects_importexport_report_diagram(
                                0,
                                idaytype,
                                dtpimexdatetime.Value,
                                dtpietodate.Value,
                                "",
                                "",
                                Common.ConnectionString);

                string prevx = "Ng.";
                int idayinmont = DateTime.DaysInMonth(dtpimexdatetime.Value.Year, dtpimexdatetime.Value.Month);
                if (idaytype == 0)
                {
                    idayinmont = 12;
                    prevx = "Thg.";
                }
                string[] x = new string[idayinmont];
                double[] yexport = new double[idayinmont];


                for (int i = 0; i < idayinmont; i++)
                {
                    x[i] = prevx + (i + 1).ToString();
                    yexport[i] = GetValuebyType(ref dt, (i + 1));
                }


                // nhập hàng
                double[] yimport = new double[idayinmont];
                if (Convert.ToInt32(cmbsalereporttypes.SelectedValue) == 2)// nhập, xuất
                {
                    dt = ImportExport.sale_objects_importexport_report_diagram(
                                    1,
                                    idaytype,
                                    dtpimexdatetime.Value,
                                    dtpietodate.Value,
                                    "",
                                    "",
                                    Common.ConnectionString);
                    for (int i = 0; i < idayinmont; i++)
                    {
                        yimport[i] = GetValuebyType(ref dt, (i + 1));
                    }

                    if (chrtsale.Series.Count < 2)
                        chrtsale.Series.Add("Nhập");

                    chrtsale.Series[0].Points.DataBindXY(x, yexport);
                    chrtsale.Series[1].Points.DataBindXY(x, yimport);
                }
                else
                {

                    chrtsale.Series[0].Points.DataBindXY(x, yexport);
                }

            }
            else // theo kinh doanh: lấy bán hàng trừ đi vốn + chi phí.
            {

            }
        }
        double GetValuebyType(ref DataTable dt, int itime)
        {
            DataRow[] drs = dt.Select("dtime=" + itime.ToString());
            if (drs.Length > 0)
            {
                return Convert.ToDouble(drs[0]["total"]);
            }
            return 0;
        }
    }
}
