﻿using CASALE.Class;
namespace CASALE
{
    partial class frmDonvitinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.frmdonvitinh = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Tất cả sản phẩm");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Nhóm 1...");
            this.panel3 = new System.Windows.Forms.Panel();
            this.lnkunitcreatenew = new System.Windows.Forms.LinkLabel();
            this.lnkcategorycreatenew = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.trvcategories = new System.Windows.Forms.TreeView();
            this.cmnCategory = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmnCategoryupdate = new System.Windows.Forms.ToolStripMenuItem();
            this.cmnucreatesubcategory = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.cmnDeleteCategory = new System.Windows.Forms.ToolStripMenuItem();
            this.pnAddCategory = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCateOrder = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCateName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnHuyCategory = new System.Windows.Forms.Button();
            this.btnLuuCate = new System.Windows.Forms.Button();
            this.pnAddProduct = new System.Windows.Forms.Panel();
            this.txtitemorder = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbdetailcategories = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblMsg = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnHuyProduct = new System.Windows.Forms.Button();
            this.btnLuuProduct = new System.Windows.Forms.Button();
            this.txtItemName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.cmnCategory.SuspendLayout();
            this.pnAddCategory.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnAddProduct.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel3.Controls.Add(this.lnkunitcreatenew);
            this.panel3.Controls.Add(this.lnkcategorycreatenew);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(468, 35);
            this.panel3.TabIndex = 18;
            // 
            // lnkunitcreatenew
            // 
            this.lnkunitcreatenew.AutoSize = true;
            this.lnkunitcreatenew.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lnkunitcreatenew.ForeColor = System.Drawing.Color.White;
            this.lnkunitcreatenew.LinkColor = System.Drawing.Color.White;
            this.lnkunitcreatenew.Location = new System.Drawing.Point(349, 13);
            this.lnkunitcreatenew.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lnkunitcreatenew.Name = "lnkunitcreatenew";
            this.lnkunitcreatenew.Size = new System.Drawing.Size(113, 13);
            this.lnkunitcreatenew.TabIndex = 3;
            this.lnkunitcreatenew.TabStop = true;
            this.lnkunitcreatenew.Text = "[Thêm mới đơn vị]";
            this.lnkunitcreatenew.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkunitcreatenew_LinkClicked);
            // 
            // lnkcategorycreatenew
            // 
            this.lnkcategorycreatenew.AutoSize = true;
            this.lnkcategorycreatenew.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lnkcategorycreatenew.ForeColor = System.Drawing.Color.White;
            this.lnkcategorycreatenew.LinkColor = System.Drawing.Color.White;
            this.lnkcategorycreatenew.Location = new System.Drawing.Point(236, 13);
            this.lnkcategorycreatenew.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lnkcategorycreatenew.Name = "lnkcategorycreatenew";
            this.lnkcategorycreatenew.Size = new System.Drawing.Size(110, 13);
            this.lnkcategorycreatenew.TabIndex = 2;
            this.lnkcategorycreatenew.TabStop = true;
            this.lnkcategorycreatenew.Text = "[Thêm mới nhóm]";
            this.lnkcategorycreatenew.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkcategorycreatenew_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(218, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "QUẢN LÝ NHÓM ĐƠN VỊ";
            // 
            // trvcategories
            // 
            this.trvcategories.ContextMenuStrip = this.cmnCategory;
            this.trvcategories.Location = new System.Drawing.Point(-1, 33);
            this.trvcategories.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.trvcategories.Name = "trvcategories";
            treeNode1.Name = "Node0";
            treeNode1.Tag = "-1";
            treeNode1.Text = "Tất cả sản phẩm";
            treeNode2.Name = "Node0";
            treeNode2.Text = "Nhóm 1...";
            this.trvcategories.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2});
            this.trvcategories.Size = new System.Drawing.Size(466, 339);
            this.trvcategories.TabIndex = 19;
            // 
            // cmnCategory
            // 
            this.cmnCategory.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmnCategoryupdate,
            this.cmnucreatesubcategory,
            this.toolStripSeparator1,
            this.cmnDeleteCategory});
            this.cmnCategory.Name = "cmnCategory";
            this.cmnCategory.Size = new System.Drawing.Size(190, 76);
            // 
            // cmnCategoryupdate
            // 
            this.cmnCategoryupdate.Image = global::CASALE.Properties.Resources.edit1;
            this.cmnCategoryupdate.Name = "cmnCategoryupdate";
            this.cmnCategoryupdate.Size = new System.Drawing.Size(189, 22);
            this.cmnCategoryupdate.Text = "Hiệu chỉnh thông tin";
            this.cmnCategoryupdate.Click += new System.EventHandler(this.cmnCategoryupdate_Click);
            // 
            // cmnucreatesubcategory
            // 
            this.cmnucreatesubcategory.Image = global::CASALE.Properties.Resources.edit1;
            this.cmnucreatesubcategory.Name = "cmnucreatesubcategory";
            this.cmnucreatesubcategory.Size = new System.Drawing.Size(189, 22);
            this.cmnucreatesubcategory.Text = "Tạo đơn vị";
            this.cmnucreatesubcategory.Click += new System.EventHandler(this.cmnucreatesubcategory_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(186, 6);
            // 
            // cmnDeleteCategory
            // 
            this.cmnDeleteCategory.Image = global::CASALE.Properties.Resources.trash_can;
            this.cmnDeleteCategory.Name = "cmnDeleteCategory";
            this.cmnDeleteCategory.Size = new System.Drawing.Size(189, 22);
            this.cmnDeleteCategory.Text = "Xóa nhóm đang chọn";
            this.cmnDeleteCategory.Click += new System.EventHandler(this.cmnDeleteCategory_Click);
            // 
            // pnAddCategory
            // 
            this.pnAddCategory.Controls.Add(this.panel2);
            this.pnAddCategory.Controls.Add(this.txtCateOrder);
            this.pnAddCategory.Controls.Add(this.label7);
            this.pnAddCategory.Controls.Add(this.txtCateName);
            this.pnAddCategory.Controls.Add(this.label2);
            this.pnAddCategory.Controls.Add(this.btnHuyCategory);
            this.pnAddCategory.Controls.Add(this.btnLuuCate);
            this.pnAddCategory.Location = new System.Drawing.Point(65, 121);
            this.pnAddCategory.Margin = new System.Windows.Forms.Padding(2);
            this.pnAddCategory.Name = "pnAddCategory";
            this.pnAddCategory.Size = new System.Drawing.Size(279, 150);
            this.pnAddCategory.TabIndex = 21;
            this.pnAddCategory.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel2.Controls.Add(this.label8);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(279, 24);
            this.panel2.TabIndex = 27;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(2, 5);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(190, 16);
            this.label8.TabIndex = 28;
            this.label8.Text = "THÔNG TIN NHÓM ĐƠN VỊ";
            // 
            // txtCateOrder
            // 
            this.txtCateOrder.Location = new System.Drawing.Point(12, 84);
            this.txtCateOrder.Margin = new System.Windows.Forms.Padding(2);
            this.txtCateOrder.Name = "txtCateOrder";
            this.txtCateOrder.Size = new System.Drawing.Size(58, 22);
            this.txtCateOrder.TabIndex = 2;
            this.txtCateOrder.Text = "1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 70);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 15);
            this.label7.TabIndex = 25;
            this.label7.Text = "Thứ tự";
            // 
            // txtCateName
            // 
            this.txtCateName.Location = new System.Drawing.Point(11, 48);
            this.txtCateName.Margin = new System.Windows.Forms.Padding(2);
            this.txtCateName.Name = "txtCateName";
            this.txtCateName.Size = new System.Drawing.Size(261, 22);
            this.txtCateName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 35);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 15);
            this.label2.TabIndex = 23;
            this.label2.Text = "Tên nhóm";
            // 
            // btnHuyCategory
            // 
            this.btnHuyCategory.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuyCategory.Location = new System.Drawing.Point(70, 108);
            this.btnHuyCategory.Margin = new System.Windows.Forms.Padding(2);
            this.btnHuyCategory.Name = "btnHuyCategory";
            this.btnHuyCategory.Size = new System.Drawing.Size(38, 27);
            this.btnHuyCategory.TabIndex = 4;
            this.btnHuyCategory.Text = "Hủy";
            this.btnHuyCategory.UseVisualStyleBackColor = true;
            this.btnHuyCategory.Click += new System.EventHandler(this.btnHuyCategory_Click);
            // 
            // btnLuuCate
            // 
            this.btnLuuCate.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuuCate.Location = new System.Drawing.Point(12, 108);
            this.btnLuuCate.Margin = new System.Windows.Forms.Padding(2);
            this.btnLuuCate.Name = "btnLuuCate";
            this.btnLuuCate.Size = new System.Drawing.Size(58, 27);
            this.btnLuuCate.TabIndex = 3;
            this.btnLuuCate.Text = "Lưu";
            this.btnLuuCate.UseVisualStyleBackColor = true;
            this.btnLuuCate.Click += new System.EventHandler(this.btnLuuCate_Click);
            // 
            // pnAddProduct
            // 
            this.pnAddProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnAddProduct.Controls.Add(this.txtitemorder);
            this.pnAddProduct.Controls.Add(this.label6);
            this.pnAddProduct.Controls.Add(this.cmbdetailcategories);
            this.pnAddProduct.Controls.Add(this.label5);
            this.pnAddProduct.Controls.Add(this.panel1);
            this.pnAddProduct.Controls.Add(this.label15);
            this.pnAddProduct.Controls.Add(this.lblMsg);
            this.pnAddProduct.Controls.Add(this.label13);
            this.pnAddProduct.Controls.Add(this.btnHuyProduct);
            this.pnAddProduct.Controls.Add(this.btnLuuProduct);
            this.pnAddProduct.Controls.Add(this.txtItemName);
            this.pnAddProduct.Controls.Add(this.label4);
            this.pnAddProduct.Location = new System.Drawing.Point(65, 79);
            this.pnAddProduct.Margin = new System.Windows.Forms.Padding(2);
            this.pnAddProduct.Name = "pnAddProduct";
            this.pnAddProduct.Size = new System.Drawing.Size(280, 177);
            this.pnAddProduct.TabIndex = 22;
            this.pnAddProduct.Visible = false;
            // 
            // txtitemorder
            // 
            this.txtitemorder.Location = new System.Drawing.Point(82, 116);
            this.txtitemorder.Margin = new System.Windows.Forms.Padding(2);
            this.txtitemorder.Name = "txtitemorder";
            this.txtitemorder.Size = new System.Drawing.Size(39, 22);
            this.txtitemorder.TabIndex = 3;
            this.txtitemorder.Text = "1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(2, 118);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 15);
            this.label6.TabIndex = 34;
            this.label6.Text = "Thứ tự";
            // 
            // cmbdetailcategories
            // 
            this.cmbdetailcategories.FormattingEnabled = true;
            this.cmbdetailcategories.Location = new System.Drawing.Point(82, 64);
            this.cmbdetailcategories.Margin = new System.Windows.Forms.Padding(2);
            this.cmbdetailcategories.Name = "cmbdetailcategories";
            this.cmbdetailcategories.Size = new System.Drawing.Size(184, 23);
            this.cmbdetailcategories.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(2, 67);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 15);
            this.label5.TabIndex = 32;
            this.label5.Text = "Nhóm đơn vị";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.label12);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(278, 24);
            this.panel1.TabIndex = 31;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(2, 6);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(142, 16);
            this.label12.TabIndex = 25;
            this.label12.Text = "THÔNG TIN ĐƠN VỊ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label15.ForeColor = System.Drawing.Color.DimGray;
            this.label15.Location = new System.Drawing.Point(2, 37);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(197, 13);
            this.label15.TabIndex = 29;
            this.label15.Text = "Cung cấp thông tin theo mẫu sau";
            // 
            // lblMsg
            // 
            this.lblMsg.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblMsg.ForeColor = System.Drawing.Color.DarkRed;
            this.lblMsg.Location = new System.Drawing.Point(48, 50);
            this.lblMsg.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(170, 10);
            this.lblMsg.TabIndex = 28;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(278, 12);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 15);
            this.label13.TabIndex = 26;
            // 
            // btnHuyProduct
            // 
            this.btnHuyProduct.Location = new System.Drawing.Point(176, 142);
            this.btnHuyProduct.Margin = new System.Windows.Forms.Padding(2);
            this.btnHuyProduct.Name = "btnHuyProduct";
            this.btnHuyProduct.Size = new System.Drawing.Size(58, 24);
            this.btnHuyProduct.TabIndex = 5;
            this.btnHuyProduct.Text = "Hủy bỏ";
            this.btnHuyProduct.UseVisualStyleBackColor = true;
            this.btnHuyProduct.Click += new System.EventHandler(this.btnHuyProduct_Click);
            // 
            // btnLuuProduct
            // 
            this.btnLuuProduct.Location = new System.Drawing.Point(82, 142);
            this.btnLuuProduct.Margin = new System.Windows.Forms.Padding(2);
            this.btnLuuProduct.Name = "btnLuuProduct";
            this.btnLuuProduct.Size = new System.Drawing.Size(89, 24);
            this.btnLuuProduct.TabIndex = 4;
            this.btnLuuProduct.Text = "Lưu thông tin";
            this.btnLuuProduct.UseVisualStyleBackColor = true;
            this.btnLuuProduct.Click += new System.EventHandler(this.btnLuuProduct_Click);
            // 
            // txtItemName
            // 
            this.txtItemName.Location = new System.Drawing.Point(82, 91);
            this.txtItemName.Margin = new System.Windows.Forms.Padding(2);
            this.txtItemName.Name = "txtItemName";
            this.txtItemName.Size = new System.Drawing.Size(184, 22);
            this.txtItemName.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(2, 93);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 15);
            this.label4.TabIndex = 13;
            this.label4.Text = "Tên đơn vị";
            // 
            // frmDonvitinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(468, 397);
            this.Controls.Add(this.pnAddCategory);
            this.Controls.Add(this.pnAddProduct);
            this.Controls.Add(this.trvcategories);
            this.Controls.Add(this.panel3);
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDonvitinh";
            this.Text = "Đơn vị tính";
            this.Load += new System.EventHandler(this.frmDonvitinh_Load);
            this.Controls.SetChildIndex(this.panel3, 0);
            this.Controls.SetChildIndex(this.trvcategories, 0);
            this.Controls.SetChildIndex(this.pnAddProduct, 0);
            this.Controls.SetChildIndex(this.pnAddCategory, 0);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.cmnCategory.ResumeLayout(false);
            this.pnAddCategory.ResumeLayout(false);
            this.pnAddCategory.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnAddProduct.ResumeLayout(false);
            this.pnAddProduct.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.LinkLabel lnkunitcreatenew;
        private System.Windows.Forms.LinkLabel lnkcategorycreatenew;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TreeView trvcategories;
        private System.Windows.Forms.Panel pnAddCategory;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCateOrder;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCateName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnHuyCategory;
        private System.Windows.Forms.Button btnLuuCate;
        private System.Windows.Forms.Panel pnAddProduct;
        private System.Windows.Forms.TextBox txtitemorder;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbdetailcategories;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblMsg;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnHuyProduct;
        private System.Windows.Forms.Button btnLuuProduct;
        private System.Windows.Forms.TextBox txtItemName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ToolStripMenuItem cmnCategoryupdate;
        private System.Windows.Forms.ToolStripMenuItem cmnucreatesubcategory;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem cmnDeleteCategory;
        private System.Windows.Forms.ContextMenuStrip cmnCategory;
    }
}