﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LCMultiUtilities;
using CASALE.Class;

namespace CASALE
{
    public partial class frmDonvitinh : templates
    {
        int ilevel = -1;
        bool binsertupdate = false;
        protected string ino = "-1";
        protected string iid = "-1";
        protected string strselectedcategoryid = "-1";
        protected string strparid = "-1";
        protected int iproductquantity = 0;
        public frmDonvitinh()
        {
            InitializeComponent();
        }

        private void frmDonvitinh_Load(object sender, EventArgs e)
        {
            LoadCategoriesTree();
            
        }
        void LoadCategoriesTree()
        {
            trvcategories.Nodes.Clear();
            DataTable tb = new DataTable();
            tb = mssql_modcategories.LoadChildrencates(Common.app_code_quote_unit_id, Common.vietnames, "-1", "1");
            if (tb.Rows.Count > 0)
            {

                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    TreeNode tn = new TreeNode(tb.Rows[i]["vname"].ToString());
                    tn.Tag = tb.Rows[i]["icid"].ToString();
                    LoadCategories2Tree(ref tn);
                    trvcategories.Nodes.Add(tn);
                }
                trvcategories.ExpandAll();
                // combobox
                DataTable dtcmb = tb;
                for (int i = 0; i < dtcmb.Rows.Count; i++)
                {
                    string tm = "";
                    ilevel = Convert.ToInt32(tb.Rows[i]["ilevel"]);

                    for (int j = 0; j < ilevel; j++)
                    {
                        tm += "--"; ;
                    }
                    dtcmb.Rows[i]["vname"] = tm + dtcmb.Rows[i]["vname"].ToString();
                }
                cmbdetailcategories.DataSource = dtcmb;
                cmbdetailcategories.DisplayMember = "vname";
                cmbdetailcategories.ValueMember = "icid";
            }
            // this.lblTotalCategory.Text = (trvcategories.Nodes.Count - 1).ToString();            
        }
        void LoadCategories2Tree(ref TreeNode trnode)
        {
            int icid = Convert.ToInt32(trnode.Tag);
            DataTable dt = mssql_modcategories.LoadChildrencates(icid.ToString());
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                TreeNode tn = new TreeNode(dt.Rows[i]["vname"].ToString());
                tn.Tag = dt.Rows[i]["icid"].ToString();
                LoadCategories2Tree(ref tn);
                trnode.Nodes.Add(tn);
            }
        }
        void reset()
        {
            txtCateName.Text = "";
            txtCateOrder.Text = "";
            txtItemName.Text = "";
            txtCateOrder.Text = "1";
            txtitemorder.Text = "1";
        }
        private void lnkcategorycreatenew_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            reset();
            this.strselectedcategoryid = "-1";
            pnAddProduct.Visible = false;
            pnAddCategory.Visible = true;
        }

        private void lnkunitcreatenew_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            pnAddCategory.Visible = false;
            pnAddProduct.Visible = true;
            reset();
        }

        private void cmnCategoryupdate_Click(object sender, EventArgs e)
        {
            if (trvcategories.Nodes.Count > 0)
            {
                if (trvcategories.SelectedNode != null)
                {
                    this.strselectedcategoryid = trvcategories.SelectedNode.Tag.ToString();
                    DataTable dt = new DataTable();
                    dt = mssql_modcategories.LoadcateDetail(strselectedcategoryid);
                    if (dt.Rows.Count > 0)
                    {
                        txtCateName.Text = dt.Rows[0]["vname"].ToString();
                        txtCateOrder.Text = dt.Rows[0]["iorders"].ToString();
                        this.strparid = dt.Rows[0]["ic_par_id"].ToString();
                    }
                    pnAddCategory.Visible = true;
                    this.binsertupdate = true;
                }
            }
        }

        private void cmnucreatesubcategory_Click(object sender, EventArgs e)
        {
            reset();
            if (trvcategories.Nodes.Count > 0)
            {
                if (trvcategories.SelectedNode != null)
                {
                    pnAddCategory.Visible = true;
                    txtCateName.Text = "";
                    txtCateOrder.Text = "1";
                    binsertupdate = false;
                }
            }
        }

        private void cmnDeleteCategory_Click(object sender, EventArgs e)
        {
            if (trvcategories.Nodes.Count > 0)
            {
                if (trvcategories.SelectedNode != null)
                {
                    if (MessageBox.Show("Xóa nhóm đang chọn?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        try
                        {
                            this.strselectedcategoryid = trvcategories.SelectedNode.Tag.ToString();

                            mssql_modcategories_data.cate_Delete(this.strselectedcategoryid, Common.ConnectionString);
                            LoadCategoriesTree();
                        }
                        catch
                        {
                            MessageBox.Show("Phải xóa tất cả sản phẩm trong nhóm trước khi xóa nhóm", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }  
        }

        private void btnLuuCate_Click(object sender, EventArgs e)
        {
            string _catename = txtCateName.Text;
            string order = txtCateOrder.Text;

            //if (this.binsertupdate == false) //insert
            //{
            //    mssql_modcategories_data.cate_Insert("-1",
            //        Common.app_code_quote_unit_id,
            //        "-1", strselectedcategoryid, "",
            //        _catename, "", "", "","0", order, "0",
            //        "1", Common.ConnectionString);
            //    LoadCategoriesTree();
            //}
            //else //update
            //{
            //    mssql_modcategories_data.cate_Update(this.strselectedcategoryid, Common.app_code_quote_unit_id, "-1", this.strparid, "", _catename, "", "", "", order, "1", "1", Common.ConnectionString);
            //    this.binsertupdate = false;
            //}
            if (this.binsertupdate == false)
            {
                mssql_modcategories_data.cate_Insert("-1", Common.app_code_quote_unit_id,
                    Common.vietnames, strselectedcategoryid, "-1",
                    _catename, "", "", "", "", "0", order,
                    "0", "1", Common.ConnectionString);
            

            }
            else
                mssql_modcategories_data.cate_Update(strselectedcategoryid, Common.app_code_quote_unit_id, Common.vietnames, "-1", "-1", _catename, "", "", "", "0", order, "0", "1", Common.ConnectionString);

            LoadCategoriesTree();
            pnAddCategory.Visible = false;
        }

        private void btnHuyCategory_Click(object sender, EventArgs e)
        {
            pnAddCategory.Visible = false;
        }

        private void btnLuuProduct_Click(object sender, EventArgs e)
        {
            string itemname = txtItemName.Text;
            string itemorder = txtitemorder.Text;
            string parent_id = cmbdetailcategories.SelectedValue.ToString();
            mssql_modcategories_data.cate_Insert("-1", Common.app_code_quote_unit_id,
                "-1", parent_id, "", itemname, "", "", "",
                "0",itemorder, "2", "1", Common.ConnectionString);

            pnAddProduct.Visible = false;
            LoadCategoriesTree();
        }

        private void btnHuyProduct_Click(object sender, EventArgs e)
        {
            pnAddProduct.Visible = false;
        }
      

    }
}
