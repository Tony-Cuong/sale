﻿using CASALE.Class;
namespace CASALE
{
    partial class frmKhachhang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.frmkhachhang = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Tất cả sản phẩm");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Nhóm 1...");
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.pnAddCategory = new System.Windows.Forms.Panel();
            this.lblsl = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCateOrder = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCateName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnHuyCategory = new System.Windows.Forms.Button();
            this.btnLuuCate = new System.Windows.Forms.Button();
            this.trvcategories = new System.Windows.Forms.TreeView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmnedit = new System.Windows.Forms.ToolStripMenuItem();
            this.cmncreate = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.cmndelete = new System.Windows.Forms.ToolStripMenuItem();
            this.lblTotalCategory = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lnkcategorycreatenew = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.lblTotalProduct = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.pnAddProduct = new System.Windows.Forms.Panel();
            this.txtinformation = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblMsg = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbdetailcategories = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnHuyProduct = new System.Windows.Forms.Button();
            this.btnLuuProduct = new System.Windows.Forms.Button();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtcustomername = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtcode = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lvitems = new System.Windows.Forms.ListView();
            this.ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cmnProduct = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmnUpdateProduct = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.cmnDeleteProduct = new System.Windows.Forms.ToolStripMenuItem();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.pnAddCategory.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pnAddProduct.SuspendLayout();
            this.panel1.SuspendLayout();
            this.cmnProduct.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.pnAddCategory);
            this.splitContainer1.Panel1.Controls.Add(this.trvcategories);
            this.splitContainer1.Panel1.Controls.Add(this.lblTotalCategory);
            this.splitContainer1.Panel1.Controls.Add(this.label10);
            this.splitContainer1.Panel1.Controls.Add(this.panel3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.label24);
            this.splitContainer1.Panel2.Controls.Add(this.lblTotalProduct);
            this.splitContainer1.Panel2.Controls.Add(this.label9);
            this.splitContainer1.Panel2.Controls.Add(this.pnAddProduct);
            this.splitContainer1.Panel2.Controls.Add(this.lvitems);
            this.splitContainer1.Panel2.Controls.Add(this.panel2);
            this.splitContainer1.Size = new System.Drawing.Size(953, 487);
            this.splitContainer1.SplitterDistance = 214;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 2;
            // 
            // pnAddCategory
            // 
            this.pnAddCategory.Controls.Add(this.lblsl);
            this.pnAddCategory.Controls.Add(this.label8);
            this.pnAddCategory.Controls.Add(this.txtCateOrder);
            this.pnAddCategory.Controls.Add(this.label7);
            this.pnAddCategory.Controls.Add(this.txtCateName);
            this.pnAddCategory.Controls.Add(this.label2);
            this.pnAddCategory.Controls.Add(this.btnHuyCategory);
            this.pnAddCategory.Controls.Add(this.btnLuuCate);
            this.pnAddCategory.Location = new System.Drawing.Point(3, 32);
            this.pnAddCategory.Name = "pnAddCategory";
            this.pnAddCategory.Size = new System.Drawing.Size(209, 168);
            this.pnAddCategory.TabIndex = 2;
            this.pnAddCategory.Visible = false;
            // 
            // lblsl
            // 
            this.lblsl.AutoSize = true;
            this.lblsl.Location = new System.Drawing.Point(89, 91);
            this.lblsl.Name = "lblsl";
            this.lblsl.Size = new System.Drawing.Size(13, 15);
            this.lblsl.TabIndex = 29;
            this.lblsl.Text = "0";
            this.lblsl.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.Location = new System.Drawing.Point(3, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(187, 14);
            this.label8.TabIndex = 27;
            this.label8.Text = "Thông tin nhóm khách hàng";
            // 
            // txtCateOrder
            // 
            this.txtCateOrder.Location = new System.Drawing.Point(15, 106);
            this.txtCateOrder.Name = "txtCateOrder";
            this.txtCateOrder.Size = new System.Drawing.Size(74, 22);
            this.txtCateOrder.TabIndex = 26;
            this.txtCateOrder.Text = "1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 15);
            this.label7.TabIndex = 25;
            this.label7.Text = "Thứ tự";
            // 
            // txtCateName
            // 
            this.txtCateName.Location = new System.Drawing.Point(14, 61);
            this.txtCateName.Name = "txtCateName";
            this.txtCateName.Size = new System.Drawing.Size(190, 22);
            this.txtCateName.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 15);
            this.label2.TabIndex = 23;
            this.label2.Text = "Tên nhóm";
            // 
            // btnHuyCategory
            // 
            this.btnHuyCategory.Image = global::CASALE.Properties.Resources.action_delete;
            this.btnHuyCategory.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHuyCategory.Location = new System.Drawing.Point(90, 134);
            this.btnHuyCategory.Name = "btnHuyCategory";
            this.btnHuyCategory.Size = new System.Drawing.Size(53, 23);
            this.btnHuyCategory.TabIndex = 22;
            this.btnHuyCategory.Text = "Hủy";
            this.btnHuyCategory.UseVisualStyleBackColor = true;
            this.btnHuyCategory.Click += new System.EventHandler(this.btnHuyCategory_Click);
            // 
            // btnLuuCate
            // 
            this.btnLuuCate.Image = global::CASALE.Properties.Resources.disk_blue;
            this.btnLuuCate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuuCate.Location = new System.Drawing.Point(15, 134);
            this.btnLuuCate.Name = "btnLuuCate";
            this.btnLuuCate.Size = new System.Drawing.Size(75, 23);
            this.btnLuuCate.TabIndex = 21;
            this.btnLuuCate.Text = "Lưu";
            this.btnLuuCate.UseVisualStyleBackColor = true;
            this.btnLuuCate.Click += new System.EventHandler(this.btnLuuCate_Click);
            // 
            // trvcategories
            // 
            this.trvcategories.ContextMenuStrip = this.contextMenuStrip1;
            this.trvcategories.Dock = System.Windows.Forms.DockStyle.Top;
            this.trvcategories.Location = new System.Drawing.Point(0, 32);
            this.trvcategories.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.trvcategories.Name = "trvcategories";
            treeNode1.Name = "Node0";
            treeNode1.Tag = "-1";
            treeNode1.Text = "Tất cả sản phẩm";
            treeNode2.Name = "Node0";
            treeNode2.Text = "Nhóm 1...";
            this.trvcategories.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2});
            this.trvcategories.Size = new System.Drawing.Size(214, 428);
            this.trvcategories.TabIndex = 0;
            this.trvcategories.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.trvcategories_AfterSelect);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmnedit,
            this.cmncreate,
            this.toolStripMenuItem1,
            this.cmndelete});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(190, 76);
            // 
            // cmnedit
            // 
            this.cmnedit.Image = global::CASALE.Properties.Resources.edit1;
            this.cmnedit.Name = "cmnedit";
            this.cmnedit.Size = new System.Drawing.Size(189, 22);
            this.cmnedit.Text = "Hiệu chỉnh";
            this.cmnedit.Click += new System.EventHandler(this.cmnedit_Click);
            // 
            // cmncreate
            // 
            this.cmncreate.Image = global::CASALE.Properties.Resources.action_add;
            this.cmncreate.Name = "cmncreate";
            this.cmncreate.Size = new System.Drawing.Size(189, 22);
            this.cmncreate.Text = "Tạo nhóm con";
            this.cmncreate.Click += new System.EventHandler(this.cmncreate_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(186, 6);
            // 
            // cmndelete
            // 
            this.cmndelete.Image = global::CASALE.Properties.Resources.trash_can;
            this.cmndelete.Name = "cmndelete";
            this.cmndelete.Size = new System.Drawing.Size(189, 22);
            this.cmndelete.Text = "Xóa nhóm đang chọn";
            this.cmndelete.Click += new System.EventHandler(this.cmndelete_Click);
            // 
            // lblTotalCategory
            // 
            this.lblTotalCategory.AutoSize = true;
            this.lblTotalCategory.Location = new System.Drawing.Point(116, 467);
            this.lblTotalCategory.Name = "lblTotalCategory";
            this.lblTotalCategory.Size = new System.Drawing.Size(13, 15);
            this.lblTotalCategory.TabIndex = 4;
            this.lblTotalCategory.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(4, 467);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(91, 15);
            this.label10.TabIndex = 3;
            this.label10.Text = "Tổng số nhóm: ";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel3.Controls.Add(this.lnkcategorycreatenew);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(214, 32);
            this.panel3.TabIndex = 1;
            // 
            // lnkcategorycreatenew
            // 
            this.lnkcategorycreatenew.AutoSize = true;
            this.lnkcategorycreatenew.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lnkcategorycreatenew.ForeColor = System.Drawing.Color.White;
            this.lnkcategorycreatenew.LinkColor = System.Drawing.Color.White;
            this.lnkcategorycreatenew.Location = new System.Drawing.Point(135, 10);
            this.lnkcategorycreatenew.Name = "lnkcategorycreatenew";
            this.lnkcategorycreatenew.Size = new System.Drawing.Size(74, 13);
            this.lnkcategorycreatenew.TabIndex = 2;
            this.lnkcategorycreatenew.TabStop = true;
            this.lnkcategorycreatenew.Text = "[Thêm mới]";
            this.lnkcategorycreatenew.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkcategorycreatenew_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(4, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nhóm khách hàng";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.Color.DimGray;
            this.label24.Location = new System.Drawing.Point(307, 463);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(262, 15);
            this.label24.TabIndex = 19;
            this.label24.Text = "Bạn có thể  ấn Ctrl hoặc Shift để chọn xóa nhiều";
            // 
            // lblTotalProduct
            // 
            this.lblTotalProduct.AutoSize = true;
            this.lblTotalProduct.Location = new System.Drawing.Point(138, 467);
            this.lblTotalProduct.Name = "lblTotalProduct";
            this.lblTotalProduct.Size = new System.Drawing.Size(13, 15);
            this.lblTotalProduct.TabIndex = 17;
            this.lblTotalProduct.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 467);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(123, 15);
            this.label9.TabIndex = 16;
            this.label9.Text = "Tổng số khách hàng: ";
            // 
            // pnAddProduct
            // 
            this.pnAddProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnAddProduct.Controls.Add(this.txtinformation);
            this.pnAddProduct.Controls.Add(this.txtemail);
            this.pnAddProduct.Controls.Add(this.txtphone);
            this.pnAddProduct.Controls.Add(this.label17);
            this.pnAddProduct.Controls.Add(this.label16);
            this.pnAddProduct.Controls.Add(this.panel1);
            this.pnAddProduct.Controls.Add(this.label15);
            this.pnAddProduct.Controls.Add(this.lblMsg);
            this.pnAddProduct.Controls.Add(this.label13);
            this.pnAddProduct.Controls.Add(this.label11);
            this.pnAddProduct.Controls.Add(this.cmbdetailcategories);
            this.pnAddProduct.Controls.Add(this.label5);
            this.pnAddProduct.Controls.Add(this.btnHuyProduct);
            this.pnAddProduct.Controls.Add(this.btnLuuProduct);
            this.pnAddProduct.Controls.Add(this.txtaddress);
            this.pnAddProduct.Controls.Add(this.label6);
            this.pnAddProduct.Controls.Add(this.txtcustomername);
            this.pnAddProduct.Controls.Add(this.label4);
            this.pnAddProduct.Controls.Add(this.txtcode);
            this.pnAddProduct.Controls.Add(this.label3);
            this.pnAddProduct.Location = new System.Drawing.Point(87, 68);
            this.pnAddProduct.Name = "pnAddProduct";
            this.pnAddProduct.Size = new System.Drawing.Size(501, 343);
            this.pnAddProduct.TabIndex = 11;
            this.pnAddProduct.Visible = false;
            // 
            // txtinformation
            // 
            this.txtinformation.Location = new System.Drawing.Point(123, 246);
            this.txtinformation.Multiline = true;
            this.txtinformation.Name = "txtinformation";
            this.txtinformation.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtinformation.Size = new System.Drawing.Size(361, 47);
            this.txtinformation.TabIndex = 7;
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(123, 217);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(266, 22);
            this.txtemail.TabIndex = 6;
            // 
            // txtphone
            // 
            this.txtphone.Location = new System.Drawing.Point(123, 189);
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(153, 22);
            this.txtphone.TabIndex = 5;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(21, 249);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(60, 15);
            this.label17.TabIndex = 35;
            this.label17.Text = "Thông tin";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(18, 222);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(69, 15);
            this.label16.TabIndex = 33;
            this.label16.Text = "Thư điện tử";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.label12);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(499, 30);
            this.panel1.TabIndex = 31;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(3, 7);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(219, 18);
            this.label12.TabIndex = 25;
            this.label12.Text = "THÔNG TIN KHÁCH HÀNG";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label15.ForeColor = System.Drawing.Color.DimGray;
            this.label15.Location = new System.Drawing.Point(21, 47);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(267, 13);
            this.label15.TabIndex = 29;
            this.label15.Text = "Cung cấp thông tin khách hàng theo mẫu sau";
            // 
            // lblMsg
            // 
            this.lblMsg.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblMsg.ForeColor = System.Drawing.Color.DarkRed;
            this.lblMsg.Location = new System.Drawing.Point(120, 63);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(353, 13);
            this.lblMsg.TabIndex = 28;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(357, 15);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 15);
            this.label13.TabIndex = 26;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(18, 192);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(62, 15);
            this.label11.TabIndex = 23;
            this.label11.Text = "Điện thoại";
            // 
            // cmbdetailcategories
            // 
            this.cmbdetailcategories.FormattingEnabled = true;
            this.cmbdetailcategories.Location = new System.Drawing.Point(123, 108);
            this.cmbdetailcategories.Name = "cmbdetailcategories";
            this.cmbdetailcategories.Size = new System.Drawing.Size(234, 23);
            this.cmbdetailcategories.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 15);
            this.label5.TabIndex = 21;
            this.label5.Text = "Nhóm KH";
            // 
            // btnHuyProduct
            // 
            this.btnHuyProduct.Image = global::CASALE.Properties.Resources.action_delete;
            this.btnHuyProduct.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHuyProduct.Location = new System.Drawing.Point(282, 305);
            this.btnHuyProduct.Name = "btnHuyProduct";
            this.btnHuyProduct.Size = new System.Drawing.Size(75, 23);
            this.btnHuyProduct.TabIndex = 9;
            this.btnHuyProduct.Text = "Hủy bỏ";
            this.btnHuyProduct.UseVisualStyleBackColor = true;
            this.btnHuyProduct.Click += new System.EventHandler(this.btnHuyProduct_Click);
            // 
            // btnLuuProduct
            // 
            this.btnLuuProduct.Image = global::CASALE.Properties.Resources.disk_blue;
            this.btnLuuProduct.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnLuuProduct.Location = new System.Drawing.Point(139, 305);
            this.btnLuuProduct.Name = "btnLuuProduct";
            this.btnLuuProduct.Size = new System.Drawing.Size(137, 23);
            this.btnLuuProduct.TabIndex = 8;
            this.btnLuuProduct.Text = "Lưu thông tin";
            this.btnLuuProduct.UseVisualStyleBackColor = true;
            this.btnLuuProduct.Click += new System.EventHandler(this.btnLuuProduct_Click);
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(123, 161);
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(361, 22);
            this.txtaddress.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 164);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 15);
            this.label6.TabIndex = 17;
            this.label6.Text = "Địa chỉ";
            // 
            // txtcustomername
            // 
            this.txtcustomername.Location = new System.Drawing.Point(123, 135);
            this.txtcustomername.Name = "txtcustomername";
            this.txtcustomername.Size = new System.Drawing.Size(266, 22);
            this.txtcustomername.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 15);
            this.label4.TabIndex = 13;
            this.label4.Text = "Họ và tên ";
            // 
            // txtcode
            // 
            this.txtcode.Location = new System.Drawing.Point(123, 81);
            this.txtcode.Name = "txtcode";
            this.txtcode.Size = new System.Drawing.Size(234, 22);
            this.txtcode.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 15);
            this.label3.TabIndex = 11;
            this.label3.Text = "Mã khách hàng";
            // 
            // lvitems
            // 
            this.lvitems.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ID,
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader7,
            this.columnHeader5,
            this.columnHeader4,
            this.columnHeader6});
            this.lvitems.ContextMenuStrip = this.cmnProduct;
            this.lvitems.Dock = System.Windows.Forms.DockStyle.Top;
            this.lvitems.FullRowSelect = true;
            this.lvitems.GridLines = true;
            this.lvitems.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvitems.HideSelection = false;
            this.lvitems.Location = new System.Drawing.Point(0, 32);
            this.lvitems.Name = "lvitems";
            this.lvitems.Size = new System.Drawing.Size(734, 428);
            this.lvitems.TabIndex = 10;
            this.lvitems.UseCompatibleStateImageBehavior = false;
            this.lvitems.View = System.Windows.Forms.View.Details;
            // 
            // ID
            // 
            this.ID.Width = 0;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "#";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Mã khách hàng";
            this.columnHeader2.Width = 108;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Họ và tên";
            this.columnHeader3.Width = 163;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Địa chỉ";
            this.columnHeader7.Width = 125;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Điện thoại";
            this.columnHeader5.Width = 123;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Thư điện tử";
            this.columnHeader4.Width = 136;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "#";
            this.columnHeader6.Width = 0;
            // 
            // cmnProduct
            // 
            this.cmnProduct.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmnUpdateProduct,
            this.toolStripSeparator2,
            this.cmnDeleteProduct});
            this.cmnProduct.Name = "contextMenuStrip2";
            this.cmnProduct.Size = new System.Drawing.Size(223, 54);
            // 
            // cmnUpdateProduct
            // 
            this.cmnUpdateProduct.Image = global::CASALE.Properties.Resources.edit1;
            this.cmnUpdateProduct.Name = "cmnUpdateProduct";
            this.cmnUpdateProduct.Size = new System.Drawing.Size(222, 22);
            this.cmnUpdateProduct.Text = "Hiệu chỉnh thông tin ";
            this.cmnUpdateProduct.Click += new System.EventHandler(this.cmnUpdateProduct_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(219, 6);
            // 
            // cmnDeleteProduct
            // 
            this.cmnDeleteProduct.Image = global::CASALE.Properties.Resources.trash_can;
            this.cmnDeleteProduct.Name = "cmnDeleteProduct";
            this.cmnDeleteProduct.Size = new System.Drawing.Size(222, 22);
            this.cmnDeleteProduct.Text = " Xóa khách hàng đang chọn";
            this.cmnDeleteProduct.Click += new System.EventHandler(this.cmnDeleteProduct_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel2.Controls.Add(this.btnExportExcel);
            this.panel2.Controls.Add(this.btnAddProduct);
            this.panel2.Controls.Add(this.txtSearch);
            this.panel2.Controls.Add(this.btnSearch);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(734, 32);
            this.panel2.TabIndex = 15;
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.Image = global::CASALE.Properties.Resources.page_white_excel;
            this.btnExportExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportExcel.Location = new System.Drawing.Point(309, 5);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(111, 23);
            this.btnExportExcel.TabIndex = 17;
            this.btnExportExcel.Text = "Xuất ra Excel";
            this.btnExportExcel.UseVisualStyleBackColor = true;
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.Image = global::CASALE.Properties.Resources.action_add;
            this.btnAddProduct.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnAddProduct.Location = new System.Drawing.Point(561, 5);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(161, 23);
            this.btnAddProduct.TabIndex = 15;
            this.btnAddProduct.Text = "Thêm mới khách hàng";
            this.btnAddProduct.UseVisualStyleBackColor = true;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(3, 6);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(218, 22);
            this.txtSearch.TabIndex = 13;
            // 
            // btnSearch
            // 
            this.btnSearch.Image = global::CASALE.Properties.Resources.book_blue_view;
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSearch.Location = new System.Drawing.Point(227, 5);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(78, 23);
            this.btnSearch.TabIndex = 14;
            this.btnSearch.Text = "Tìm kiếm";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // frmKhachhang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(953, 509);
            this.Controls.Add(this.splitContainer1);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.MaximizeBox = false;
            this.Name = "frmKhachhang";
            this.Text = "Khách hàng";
            this.Load += new System.EventHandler(this.frmKhachhang_Load);
            this.Controls.SetChildIndex(this.splitContainer1, 0);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.pnAddCategory.ResumeLayout(false);
            this.pnAddCategory.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.pnAddProduct.ResumeLayout(false);
            this.pnAddProduct.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.cmnProduct.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel pnAddCategory;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCateOrder;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCateName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnHuyCategory;
        private System.Windows.Forms.Button btnLuuCate;
        private System.Windows.Forms.TreeView trvcategories;
        private System.Windows.Forms.Label lblTotalCategory;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.LinkLabel lnkcategorycreatenew;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTotalProduct;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel pnAddProduct;
        private System.Windows.Forms.TextBox txtinformation;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblMsg;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmbdetailcategories;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnHuyProduct;
        private System.Windows.Forms.Button btnLuuProduct;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtcustomername;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtcode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListView lvitems;
        private System.Windows.Forms.ColumnHeader ID;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnExportExcel;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cmnedit;
        private System.Windows.Forms.ToolStripMenuItem cmncreate;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cmndelete;
        private System.Windows.Forms.ContextMenuStrip cmnProduct;
        private System.Windows.Forms.ToolStripMenuItem cmnUpdateProduct;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem cmnDeleteProduct;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Label lblsl;
        private System.Windows.Forms.Label label24;
    }
}