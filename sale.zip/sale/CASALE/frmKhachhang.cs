﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CASALE.Class;
using LCMultiUtilities;
using OfficeUtilities;

namespace CASALE
{
    public partial class frmKhachhang : templates
    {
        int ilevel = -1;
        bool binsertupdate = false;
        protected string ino = "-1";
        protected string iid = "-1";
        protected string strselectedcategoryid = "-1";
        protected int iparentid = -1;
        protected int iproductquantity = 0;
        public frmKhachhang()
        {
            InitializeComponent();
        }

        private void frmKhachhang_Load(object sender, EventArgs e)
        {
            LoadCategoriesTree();
            LoadItems();
            
        }
        void LoadCategoriesTree()
        {
            trvcategories.Nodes.Clear();
            trvcategories.Nodes.Add("Tất cả nhóm");
            trvcategories.Nodes[0].Tag = "-1";
            DataTable tb = new DataTable();
            tb = mssql_modcategories.LoadChildrencates(Common.capp_customer_code, Common.vietnames, "-1", "1");
            if (tb.Rows.Count > 0)
            {

                for (int i = 0; i < tb.Rows.Count; i++)
                {
                   // TreeNode tn = new TreeNode(tb.Rows[i]["vname"].ToString());
                    TreeNode tn = new TreeNode(tb.Rows[i]["vname"].ToString() + "  (" + tb.Rows[i]["iitems"].ToString() + ")");
                    tn.Tag = tb.Rows[i]["icid"].ToString();
                    LoadCategories2Tree(ref tn);
                    trvcategories.Nodes.Add(tn);
                }

                // combobox
                DataTable dtcmb = tb;
                for (int i = 0; i < dtcmb.Rows.Count; i++)
                {
                    string tm = "";
                    ilevel = Convert.ToInt32(tb.Rows[i]["ilevel"]);

                    for (int j = 0; j < ilevel; j++)
                    {
                        tm += "--"; ;
                    }
                    dtcmb.Rows[i]["vname"] = tm + dtcmb.Rows[i]["vname"].ToString();
                }
                cmbdetailcategories.DataSource = dtcmb;
                cmbdetailcategories.DisplayMember = "vname";
                cmbdetailcategories.ValueMember = "icid";

            }
            trvcategories.ExpandAll();
            this.lblTotalCategory.Text = (trvcategories.Nodes.Count - 1).ToString();
        }
        void LoadCategories2Tree(ref TreeNode trnode)
        {
            int icid = Convert.ToInt32(trnode.Tag);
            DataTable dt = mssql_modcategories.LoadChildrencates(icid.ToString());
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //TreeNode tn = new TreeNode(dt.Rows[i]["vname"].ToString());
                TreeNode tn = new TreeNode(dt.Rows[i]["vname"].ToString() + "  (" + dt.Rows[i]["iitems"].ToString() + ")");
                tn.Tag = dt.Rows[i]["icid"].ToString();
                LoadCategories2Tree(ref tn);
                trnode.Nodes.Add(tn);
            }
        }

        private void cmnedit_Click(object sender, EventArgs e)
        {
            if (trvcategories.Nodes.Count > 0)
            {
                if (trvcategories.SelectedNode != null)
                {
                    this.strselectedcategoryid = trvcategories.SelectedNode.Tag.ToString();
                    DataTable dt = new DataTable();
                    dt = mssql_modcategories.LoadcateDetail(strselectedcategoryid);
                    if (dt.Rows.Count > 0)
                    {

                        iparentid = Convert.ToInt32(dt.Rows[0]["ic_par_id"]);
                        txtCateName.Text = dt.Rows[0]["vname"].ToString();
                        txtCateOrder.Text = dt.Rows[0]["iorders"].ToString();
                        lblsl.Text = dt.Rows[0]["iitems"].ToString();
                    }
                    pnAddCategory.Visible = true;
                    this.binsertupdate = true;
                }
            }
        }

        private void trvcategories_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (trvcategories.Nodes.Count > 0)
            {
                if (trvcategories.SelectedNode != null)
                {
                    this.strselectedcategoryid = trvcategories.SelectedNode.Tag.ToString();
                    LoadItems();
                }
            }
        }

        private void cmncreate_Click(object sender, EventArgs e)
        {
            if (trvcategories.Nodes.Count > 0)
            {
                if (trvcategories.SelectedNode != null)
                {
                    pnAddCategory.Visible = true;
                    txtCateName.Text = "";
                    txtCateOrder.Text = "1";
                    binsertupdate = false;
                }
            }
        }

        private void cmndelete_Click(object sender, EventArgs e)
        {
            if (trvcategories.Nodes.Count > 0)
            {
                if (trvcategories.SelectedNode != null)
                {
                    if (MessageBox.Show("Xóa nhóm đang chọn?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        try
                        {
                            this.strselectedcategoryid = trvcategories.SelectedNode.Tag.ToString();
                            this.txtSearch.Text = "";
                            mssql_modcategories_data.cate_Delete(this.strselectedcategoryid, Common.ConnectionString);
                            LoadCategoriesTree();
                        }
                        catch
                        {
                            MessageBox.Show("Phải xóa tất cả sản phẩm trong nhóm trước khi xóa nhóm", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            } 
        }

        private void lnkcategorycreatenew_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            pnAddCategory.Visible = true;
            binsertupdate = false;
            txtCateName.Text = "";
            txtCateOrder.Text = "1";
        }

        private void btnLuuCate_Click(object sender, EventArgs e)
        {
            string _catename = txtCateName.Text;
            string order = txtCateOrder.Text;
            if (this.binsertupdate == false)
            {
                mssql_modcategories_data.cate_Insert("-1", Common.capp_customer_code,
                    Common.vietnames, strselectedcategoryid, "-1",
                    _catename, "", "", "", "", "0", order,
                    "0", "1", Common.ConnectionString);
            }
            else
                mssql_modcategories_data.cate_Update(strselectedcategoryid,
                    Common.capp_customer_code, Common.vietnames,
                    iparentid.ToString(), "-1", _catename, "", "", lblsl.Text, "0", order, "0", "1", Common.ConnectionString);

            LoadCategoriesTree();
            pnAddCategory.Visible = false;
        }

        private void btnHuyCategory_Click(object sender, EventArgs e)
        {
            pnAddCategory.Visible = false;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            LoadItems();
        }
        void LoadItems()
        {

            this.lvitems.Items.Clear();
            string[] searchfield = { "vkey", "vtitle" };
            DataTable tb = mssql_multicates_multidb_items.dicts_cate_items_incate_v3(-1,
                Common.capp_customer_code, Common.vietnames, Convert.ToInt32(strselectedcategoryid),
                false, false, false, "", 1, txtSearch.Text, searchfield,
                false, "", "", Common.ConnectionString);
            if (tb.Rows.Count > 0)
            {
                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    ListViewItem lvi = new ListViewItem(tb.Rows[i]["iid"].ToString() + "|" + tb.Rows[i]["ino"].ToString());

                    lvi.SubItems.Add((i + 1).ToString());
                    lvi.SubItems.Add(tb.Rows[i]["vkey"].ToString());
                    lvi.SubItems.Add(tb.Rows[i]["vtitle"].ToString());
                    lvi.SubItems.Add(tb.Rows[i]["vdesc"].ToString());
                    lvi.SubItems.Add(tb.Rows[i]["vauthor"].ToString());
                    lvi.SubItems.Add(tb.Rows[i]["vurl"].ToString());
                    lvi.SubItems.Add(tb.Rows[i]["icid"].ToString());
                    lvitems.Items.Add(lvi);
                }
            }
            this.lblTotalProduct.Text = lvitems.Items.Count.ToString();
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            txtcode.Text = Common.CustomerCode;
            txtcustomername.Text = "";
            txtaddress.Text = "";
            txtinformation.Text = "";
            txtphone.Text = "";
            txtemail.Text = "";
            pnAddProduct.Visible = true;
            binsertupdate = false;
        }

        private void btnLuuProduct_Click(object sender, EventArgs e)
        {
            this.lvitems.Items.Clear();
            string _codeproduct = txtcode.Text;
            int _category = Convert.ToInt32(cmbdetailcategories.SelectedValue);
            int[] cate = { _category };
            string _productname = txtcustomername.Text;
            string _dongia = txtaddress.Text;

            if (this.binsertupdate == false) //insert
            {
                mssql_multicates_multidb_items.dicts_items_insert_v3(
                    cate, txtcode.Text,
                    txtcustomername.Text, txtaddress.Text,
                    txtinformation.Text, txtphone.Text,
                    txtemail.Text, "", "",
                    0, DateTime.Now, DateTime.Now, DateTime.Now,
                    "",0, 1, "0", "1", 1, DateTime.Now, DateTime.Now,
                    DateTime.Now, 1, false, Common.ConnectionString);
                mssql_modcategories_data.cate_Update(cmbdetailcategories.SelectedValue.ToString(), " iitems=iitems+1", Common.ConnectionString);
                LoadCategoriesTree();
            }
            else //update
            {
                mssql_multicates_multidb_items.dicts_items_update_v3(Convert.ToInt32(this.ino),
                    Convert.ToInt32(this.iid),
                    Common.capp_customer_code,
                    Convert.ToInt32(this.strselectedcategoryid),
                    Convert.ToInt32(cmbdetailcategories.SelectedValue),
                    txtcode.Text,
                    txtcustomername.Text, txtaddress.Text, 
                    txtinformation.Text, txtphone.Text, txtemail.Text,
                    "", "", iproductquantity, 1, 1, 0, DateTime.Now, 
                    DateTime.Now, true, false, Common.ConnectionString);
                this.binsertupdate = false;
            }

            pnAddProduct.Visible = false;
            LoadItems();
        }

        private void cmnUpdateProduct_Click(object sender, EventArgs e)
        {
            if (lvitems.Items.Count > 0)
            {
                if (lvitems.SelectedItems.Count > 0)
                {
                    pnAddProduct.Visible = true;
                    //try
                    //{
                    string[] prms = lvitems.SelectedItems[0].Text.ToString().Split('|');
                    if (prms.Length == 2)
                    {
                        this.iid = prms[0];
                        this.ino = prms[1];
                    }
                    DataTable dt = mssql_multicates_multidb_items.dicts_items_GetDetailByID(this.iid, Common.capp_customer_code, Common.ConnectionString);

                    if (dt.Rows.Count > 0)
                    {
                        txtcode.Text = dt.Rows[0]["vkey"].ToString();
                        txtcustomername.Text = dt.Rows[0]["vtitle"].ToString();
                        txtaddress.Text = dt.Rows[0]["vdesc"].ToString();
                        txtphone.Text = dt.Rows[0]["vauthor"].ToString();
                        txtemail.Text = dt.Rows[0]["vurl"].ToString();
                        txtinformation.Text = dt.Rows[0]["vcontent"].ToString();
                        //nudThue.Value = Decimal.Parse(dt.Rows[0]["vurl"].ToString());
                        cmbdetailcategories.SelectedValue = this.strselectedcategoryid = dt.Rows[0]["icid"].ToString();
                        iproductquantity = Convert.ToInt32(dt.Rows[0]["iquantity"]);

                        this.binsertupdate = true;
                    }
                    //}
                    //catch (Exception ex)
                    //{
                    //    MessageBox.Show("LOI1");
                    //    this.binsertupdate = false;
                    //}
                }
            }
        }

        private void cmnDeleteProduct_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Xóa Khách hàng đang chọn?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                for (int i = 0; i < lvitems.Items.Count; i++)
                {
                    if (lvitems.Items[i].Selected)
                    {
                        string[] prms = lvitems.Items[i].Text.ToString().Split('|');
                        if (prms.Length == 2)
                        {
                            this.iid = prms[0];
                            this.ino = prms[1];
                        }
                        mssql_multicates_multidb_items.dicts_cate_items_Delete_ino(this.ino, Common.ConnectionString);
                        mssql_multicates_multidb_items.dicts_cate_items_Delete(this.iid, Common.ConnectionString);
                        mssql_modcategories_data.cate_Update(lvitems.Items[i].Text.ToString(), " iitems = iitems-1 ", Common.ConnectionString);

                        try
                        {
                            mssql_multicates_multidb_items.dicts_onlyitems_delete(this.iid, Common.ConnectionString);
                        }
                        catch
                        { }
                    }
                }
                LoadCategoriesTree();
                LoadItems();
            }
        }

        private void btnHuyProduct_Click(object sender, EventArgs e)
        {
            this.binsertupdate = false;
            pnAddProduct.Visible = false;
        }

        private void btnExportExcel_Click(object sender, EventArgs e)
        {
            ExcelUtilities.ExportListViewToExcel(ref lvitems);
        }
    }
}
