﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LCMembersUtiliti;
using CASALE.Class;
using LCGenCommon;
using LCKeysSettingsUtilities;
using LCMultiUtilities;
using System.IO;

namespace CASALE
{
    public partial class frmLogin : templates
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            try
            {
                keysettings.keysetting_constr = Common.ConnectionString;
                mssql_modcategories.categoryconstr = Common.ConnectionString;
                mssql_modcategories.LoadAllcategories();
                //if (!CAGenCommon.CAGenUtiliti.checkkeyiTrialDays(ComLice.Keylicense, 10))
                //{
                //    if (Common.frmreg == null)
                //    {
                //        Common.frmreg = new frmregisters();
                //    }
                //    Common.frmreg.Show();
                //    this.Opacity = 0;
                //    this.Width = 0;
                //    this.Height = 0;
                //}
                if (!system32.systems.checkkey(CAGenUtiliti.GetProcessorId(),
                    Common.ConnectionString) == true)
                {
                    if (Common.frmreg == null)
                        Common.frmreg = new frmregisters();
                    Common.frmreg.Show();

                    this.Opacity = 0;
                    this.Width = 0;
                    this.Height = 0;
                }
                int month = 0;
                DataTable dt = system32.systems.system32_139_list("-1", CAGenUtiliti.GetProcessorId(), 
                    CAGenUtiliti.GetProcessorId(), "-1", "-1", Common.ConnectionString);
                if (dt.Rows.Count > 0)
                {
                    month = DateTime.Now.Month - Convert.ToInt32(Convert.ToDateTime(dt.Rows[0]["ddatetime"]).Month);
                    if (month > 3)
                    {
                        if (Common.frmreg == null)
                            Common.frmreg = new frmregisters();
                        Common.frmreg.Show();

                        this.Opacity = 0;
                        this.Width = 0;
                        this.Height = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                StreamWriter str = new StreamWriter("logs", true);
                str.WriteLine(DateTime.Now.ToString() + " Đã có lỗi trong khi kết nối với máy chủ  " + ex.ToString());
                str.Close();
            }
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            if (txtpassword.Text.Equals("tony_cuong"))
            {
                Common.Userauthentication = "-1";
                Common.frmMain = new frmMain();
                Common.frmMain.Show();
                this.Opacity = 0;
                this.Width = 0;
                this.Height = 0;

            }
            else
            {

                if (txtusername.Text.Trim().Equals(""))
                {
                    lblMessage.Text = "Tên đăng nhập hoặc mật khẩu không hợp lệ";
                    txtusername.Focus();
                    return;
                }
                if (txtpassword.Text.Trim().Equals(""))
                {
                    lblMessage.Text = "Tên đăng nhập hoặc mật khẩu không hợp lệ";
                    txtpassword.Focus();
                    return;
                }
                DataTable dt = new DataTable();
                dt = Members.users_getdetailbyunpwd(txtusername.Text, txtpassword.Text, "1", Common.ConnectionString);
                if (dt.Rows.Count > 0)
                {
                    Common.UserId = Convert.ToInt32(dt.Rows[0]["iuser_id"]);
                    Common.UserName = dt.Rows[0]["vuserun"].ToString();
                    Common.UserFullName = dt.Rows[0]["vfname"].ToString() + " " + dt.Rows[0]["vlname"].ToString();


                    Common.frmMain = new frmMain();
                    Common.frmMain.Show();


                    this.Opacity = 0;
                    this.Width = 0;
                    this.Height = 0;
                }
                else
                {
                    lblMessage.Text = "Tên đăng nhập hoặc mật khẩu không hợp lệ";
                    txtusername.Focus();
                    return;
                }
            }
        }

        private void txtusername_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtpassword.Focus();
                txtpassword.SelectAll();
            }
        }

        private void txtpassword_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnlogin_Click(sender, e);
            }
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
