﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CASALE.Class;
using LCKeysSettingsUtilities;
using LCMultiUtilities;
using System.Collections;
using LCMembersUtiliti;

namespace CASALE
{
    public partial class frmMain : templates
    {
        public frmMain()
        {
            InitializeComponent();
            keysettings.keysetting_constr = Common.ConnectionString;
            mssql_modcategories.categoryconstr = Common.ConnectionString;
            mssql_modcategories.LoadAllcategories();
            this.Text = "Phần mềm bán hàng CA, Copyright © 2013 - " + Common.CompanyName;
            
        }

        void visible()
        {
            //01
            mnumaincontrol.Visible = true;
            mnusyssetting.Visible = true;
            mndanhsachnguoidung.Visible = true;
            mnphanquyen.Visible = true;
            //02
            mnusaleimportexport.Visible = true;
            mnusaleorder.Visible = true;
            mnsaleorderexecuting.Visible = true;
            //03
            mndata.Visible = true;
            mnunit.Visible = true;
            mnuproductsmanagement.Visible = true;
            mnumanagecustomer.Visible = true;
            //04
            mnumanageimex.Visible = true;
            mnsaleimportproducts.Visible = true;
            mnsaleexportproducts.Visible = true;
            mnumanageimportexportorders.Visible = true;
            //05
            mnureport.Visible = true;
            cmnreportsale.Visible = true;
            mnunhapxuatton.Visible = true;
            mnureportsale.Visible = true;
            mnureportimcom.Visible = true;
        }
        void LoadUserMenu()
        {
            //01
            mnumaincontrol.Visible = true;
            mnusyssetting.Visible = false;
            mndanhsachnguoidung.Visible = false;
            mnphanquyen.Visible = false;
            //02
            mnusaleimportexport.Visible = false;
            mnusaleorder.Visible = false;
            mnsaleorderexecuting.Visible = false;
            //03
            mndata.Visible = false;
            mnunit.Visible = false;
            mnuproductsmanagement.Visible = false;
            mnumanagecustomer.Visible = false;
            //04
            mnumanageimex.Visible = false;
            mnsaleimportproducts.Visible = false;
            mnsaleexportproducts.Visible = false;
            mnumanageimportexportorders.Visible = false;
            //05
            mnureport.Visible = false;
            cmnreportsale.Visible = false;
            mnunhapxuatton.Visible = false;
            mnureportsale.Visible = false;
            mnureportimcom.Visible = false;

            DataTable dt = new DataTable();
            dt = WindowsAuthentication.winapp_userpermissions_getdetail_byid(Common.UserId.ToString(), Common.ConnectionString);
            if (dt.Rows.Count > 0)
            {
                ArrayList arroptions = new ArrayList();
                arroptions.AddRange(dt.Rows[0]["vroles"].ToString().Split(';'));
                for (int i = 0; i < arroptions.Count; i++)
                {
                    switch (arroptions[i].ToString())
                    {

                        case "01":
                            mnumaincontrol.Visible = true;
                            break;
                        case "010":
                            mnusyssetting.Visible = true;
                            break;
                        case "011":
                            mndanhsachnguoidung.Visible = true;
                            break;
                        case "012":
                            mnphanquyen.Visible = true;
                            break;

                        case "02":
                            mnusaleimportexport.Visible = true;
                            break;
                        case "020":
                            mnusaleorder.Visible = true;
                            break;
                        case "021":
                            mnsaleorderexecuting.Visible = true;
                            break;
                        case "03":
                            mndata.Visible = true;
                            break;
                        case "030":
                            mnunit.Visible = true;
                            break;
                        case "031":
                            mnuproductsmanagement.Visible = true;
                            break;
                        case "032":
                            mnumanagecustomer.Visible = true;
                            break;
                        case "04":
                            mnumanageimex.Visible = true;
                            break;
                        case "040":
                            mnsaleimportproducts.Visible = true;
                            break;
                        case "041":
                            mnsaleexportproducts.Visible = true;
                            break;
                        case "042":
                            mnumanageimportexportorders.Visible = true;
                            break;
                        case "05":
                            mnureport.Visible = true;
                            break;
                        case "050":
                            cmnreportsale.Visible = true;
                            break;
                        case "051":
                            mnunhapxuatton.Visible = true;
                            break;
                        case "052":
                            mnureportsale.Visible = true;
                            break;
                        case "053":
                            mnureportimcom.Visible = true;
                            break;
                    }
                }
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
           
            lblcompany.Text = Common.CompanyName;
            if (Common.Userauthentication.Equals("-1"))
            {
                visible();
            }
            else
            {
                LoadUserMenu();
            }


        }

        private void mnucloseprogram_Click(object sender, EventArgs e)
        {
            //fg = true;
            //Application.Exit();
            if (MessageBox.Show("Thoát khỏi chương trình?", "Thông báo", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Close();
                Application.Exit();
            }
        }

        private void mnusyssetting_Click(object sender, EventArgs e)
        {
            if (Common.frmsettings == null)
                Common.frmsettings = new frmsyssettings();
            Common.frmsettings.MdiParent = this;
            Common.frmsettings.Show();
            Common.frmsettings.Focus();
        }

        private void mndanhsachnguoidung_Click(object sender, EventArgs e)
        {
            if (Common.frmusermanagement == null)
                Common.frmusermanagement = new frmUserManagement();
            Common.frmusermanagement.MdiParent = this;
            Common.frmusermanagement.Show();
            Common.frmusermanagement.Focus();
        }

        private void mnphanquyen_Click(object sender, EventArgs e)
        {
            if (Common.frmuserauthentication == null)
                Common.frmuserauthentication = new frmuserauthentication();
            Common.frmuserauthentication.MdiParent = this;
            Common.frmuserauthentication.Show();
            Common.frmuserauthentication.Focus();
        }

        private void mnunit_Click(object sender, EventArgs e)
        {
            if (Common.frmdonvitinh == null)
            {
                Common.frmdonvitinh = new frmDonvitinh();
            }
            Common.frmdonvitinh.MdiParent = this;
            Common.frmdonvitinh.Show();
            Common.frmdonvitinh.Focus();
        }

        private void mnuproductsmanagement_Click(object sender, EventArgs e)
        {
            if (Common.frmsanpham == null)
            {
                Common.frmsanpham = new frmSanpham();
            }
            Common.frmsanpham.MdiParent = this;
            Common.frmsanpham.Show();
            Common.frmsanpham.Focus();
        }

        private void mnumanagecustomer_Click(object sender, EventArgs e)
        {
            if (Common.frmkhachhang == null)
            {
                Common.frmkhachhang = new frmKhachhang();
            }
            Common.frmkhachhang.MdiParent = this;
            Common.frmkhachhang.Show();
            Common.frmkhachhang.Focus();
        }

        private void mnsaleimportproducts_Click(object sender, EventArgs e)
        {
            if (Common.frmnhaphang == null)
            {
                Common.frmnhaphang = new frmNhaphang();
            }
            Common.frmnhaphang.MdiParent = this;
            Common.frmnhaphang.Show();
            Common.frmnhaphang.Focus();
        }

        private void mnsaleexportproducts_Click(object sender, EventArgs e)
        {
            if (Common.frmxuathang == null)
            {
                Common.frmxuathang = new frmXuathang();
            }
            Common.frmxuathang.MdiParent = this;
            Common.frmxuathang.Show();
            Common.frmxuathang.Focus();
        }

        private void mnumanageimportexportorders_Click(object sender, EventArgs e)
        {
            if (Common.frmquanlynhapxuat == null)
            {
                Common.frmquanlynhapxuat = new frmQuanlynhapxuat();
            }
            Common.frmquanlynhapxuat.MdiParent = this;
            Common.frmquanlynhapxuat.Show();
            Common.frmquanlynhapxuat.Focus();
        }

        private void cmnreportsale_Click(object sender, EventArgs e)
        {
            if (Common.frmreportsale == null)
            {
                Common.frmreportsale = new frmReportSale();
            }
            Common.frmreportsale.MdiParent = this;
            Common.frmreportsale.Show();
            Common.frmreportsale.Focus();
        }

        private void mnunhapxuatton_Click(object sender, EventArgs e)
        {
            if (Common.frmnhapxuat == null)
            {
                Common.frmnhapxuat = new frmNhapXuat();
            }
            Common.frmnhapxuat.MdiParent = this;
            Common.frmnhapxuat.Show();
            Common.frmnhapxuat.Focus();
        }

        private void mnureportsale_Click(object sender, EventArgs e)
        {
            if (Common.frmreport == null)
            {
                Common.frmreport = new frmReport();
            }
            Common.frmreport.MdiParent = this;
            Common.frmreport.Show();
            Common.frmreport.Focus();
        }

        private void mnureportimcom_Click(object sender, EventArgs e)
        {
            if (Common.frmbaocaobieudodt == null)
            {
                Common.frmbaocaobieudodt = new frmBaocaobieudodt();
            }
            Common.frmbaocaobieudodt.MdiParent = this;
            Common.frmbaocaobieudodt.Show();
            Common.frmbaocaobieudodt.Focus();
        }

        private void mnusaleorder_Click(object sender, EventArgs e)
        {
            if (Common.frmbanhang == null)
            {
                Common.frmbanhang = new frmBanhang();
            }
            Common.frmbanhang.MdiParent = this;
            Common.frmbanhang.Show();
            Common.frmbanhang.Focus();
        }

        private void mnsaleorderexecuting_Click(object sender, EventArgs e)
        {
            if (Common.frmxulydonhang == null)
            {
                Common.frmxulydonhang = new frmXulydonhang();
            }
            Common.frmxulydonhang.MdiParent = this;
            Common.frmxulydonhang.Show();
            Common.frmxulydonhang.Focus();
        }

        private void mnuaboutus_Click(object sender, EventArgs e)
        {
            if (Common.frmaboutus == null)
            {
                Common.frmaboutus = new frmaboutus();
            }
            Common.frmaboutus.MdiParent = this;
            Common.frmaboutus.Show();
            Common.frmaboutus.Focus();
        }

        private void mnuintroduction_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start(Application.StartupPath + "\\help\\huongdan.pdf");
            }
            catch (Exception ex)
            {
                ;
            }
            
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            //this.Close();
            Application.Exit();
        }
    }
}
