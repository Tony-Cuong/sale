﻿using CASALE.Class;
namespace CASALE
{
    partial class frmNhapXuat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.frmnhapxuat = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbltitle = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lvitems = new System.Windows.Forms.ListView();
            this.id = new System.Windows.Forms.ColumnHeader();
            this.stt = new System.Windows.Forms.ColumnHeader();
            this.msp = new System.Windows.Forms.ColumnHeader();
            this.name = new System.Windows.Forms.ColumnHeader();
            this.sln = new System.Windows.Forms.ColumnHeader();
            this.gtn = new System.Windows.Forms.ColumnHeader();
            this.export = new System.Windows.Forms.ColumnHeader();
            this.gtx = new System.Windows.Forms.ColumnHeader();
            this.ton1 = new System.Windows.Forms.ColumnHeader();
            this.gtton1 = new System.Windows.Forms.ColumnHeader();
            this.rdoAll = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.cbotypeproduct = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbproductcategories = new System.Windows.Forms.ComboBox();
            this.txtgtton = new System.Windows.Forms.Label();
            this.txtgtxuat = new System.Windows.Forms.Label();
            this.txtgtrinhap = new System.Windows.Forms.Label();
            this.lblnumofitems = new System.Windows.Forms.Label();
            this.rdtimebydate = new System.Windows.Forms.RadioButton();
            this.lblsumimporttotal = new System.Windows.Forms.Label();
            this.lblsumexporttotal = new System.Windows.Forms.Label();
            this.rdimexbyyear = new System.Windows.Forms.RadioButton();
            this.lblsumtotal = new System.Windows.Forms.Label();
            this.btnprintlist = new System.Windows.Forms.Button();
            this.btndisplay = new System.Windows.Forms.Button();
            this.dtpietodate = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpimexdatetime = new System.Windows.Forms.DateTimePicker();
            this.rdimexbyperiod = new System.Windows.Forms.RadioButton();
            this.rdimexbymonth = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.txtimexkeyword = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.lbltitle);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(959, 30);
            this.panel1.TabIndex = 2;
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbltitle.Location = new System.Drawing.Point(4, 7);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(302, 18);
            this.lbltitle.TabIndex = 0;
            this.lbltitle.Text = "THỐNG KÊ SẢN PHẨM NHẬP - XUẤT";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lvitems);
            this.panel2.Controls.Add(this.rdoAll);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.cbotypeproduct);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.cmbproductcategories);
            this.panel2.Controls.Add(this.txtgtton);
            this.panel2.Controls.Add(this.txtgtxuat);
            this.panel2.Controls.Add(this.txtgtrinhap);
            this.panel2.Controls.Add(this.lblnumofitems);
            this.panel2.Controls.Add(this.rdtimebydate);
            this.panel2.Controls.Add(this.lblsumimporttotal);
            this.panel2.Controls.Add(this.lblsumexporttotal);
            this.panel2.Controls.Add(this.rdimexbyyear);
            this.panel2.Controls.Add(this.lblsumtotal);
            this.panel2.Controls.Add(this.btnprintlist);
            this.panel2.Controls.Add(this.btndisplay);
            this.panel2.Controls.Add(this.dtpietodate);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.dtpimexdatetime);
            this.panel2.Controls.Add(this.rdimexbyperiod);
            this.panel2.Controls.Add(this.rdimexbymonth);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtimexkeyword);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 30);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(959, 507);
            this.panel2.TabIndex = 3;
            // 
            // lvitems
            // 
            this.lvitems.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.id,
            this.stt,
            this.msp,
            this.name,
            this.sln,
            this.gtn,
            this.export,
            this.gtx,
            this.ton1,
            this.gtton1});
            this.lvitems.FullRowSelect = true;
            this.lvitems.GridLines = true;
            this.lvitems.Location = new System.Drawing.Point(3, 43);
            this.lvitems.Name = "lvitems";
            this.lvitems.Size = new System.Drawing.Size(953, 445);
            this.lvitems.TabIndex = 34;
            this.lvitems.UseCompatibleStateImageBehavior = false;
            this.lvitems.View = System.Windows.Forms.View.Details;
            // 
            // id
            // 
            this.id.Text = "id";
            this.id.Width = 0;
            // 
            // stt
            // 
            this.stt.Text = "STT";
            this.stt.Width = 40;
            // 
            // msp
            // 
            this.msp.Text = "Mã ";
            this.msp.Width = 80;
            // 
            // name
            // 
            this.name.Text = "Tên";
            this.name.Width = 260;
            // 
            // sln
            // 
            this.sln.Text = "Nhập";
            this.sln.Width = 70;
            // 
            // gtn
            // 
            this.gtn.Text = "GT Nhập";
            this.gtn.Width = 100;
            // 
            // export
            // 
            this.export.Text = "Xuất";
            // 
            // gtx
            // 
            this.gtx.Text = "GT Xuất";
            this.gtx.Width = 95;
            // 
            // ton1
            // 
            this.ton1.Text = "Tồn";
            // 
            // gtton1
            // 
            this.gtton1.Text = "GT Tồn";
            this.gtton1.Width = 120;
            // 
            // rdoAll
            // 
            this.rdoAll.AutoSize = true;
            this.rdoAll.Checked = true;
            this.rdoAll.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdoAll.Location = new System.Drawing.Point(292, 2);
            this.rdoAll.Name = "rdoAll";
            this.rdoAll.Size = new System.Drawing.Size(60, 17);
            this.rdoAll.TabIndex = 33;
            this.rdoAll.TabStop = true;
            this.rdoAll.Text = "Tất cả";
            this.rdoAll.UseVisualStyleBackColor = true;
            this.rdoAll.CheckedChanged += new System.EventHandler(this.rdoAll_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(180, 4);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 32;
            this.label1.Text = "Chọn";
            // 
            // cbotypeproduct
            // 
            this.cbotypeproduct.FormattingEnabled = true;
            this.cbotypeproduct.Location = new System.Drawing.Point(183, 20);
            this.cbotypeproduct.Name = "cbotypeproduct";
            this.cbotypeproduct.Size = new System.Drawing.Size(161, 23);
            this.cbotypeproduct.TabIndex = 31;
            this.cbotypeproduct.SelectedIndexChanged += new System.EventHandler(this.cbotypeproduct_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.Location = new System.Drawing.Point(1, 4);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 13);
            this.label6.TabIndex = 30;
            this.label6.Text = "Nhóm sản phẩm";
            // 
            // cmbproductcategories
            // 
            this.cmbproductcategories.FormattingEnabled = true;
            this.cmbproductcategories.Location = new System.Drawing.Point(4, 20);
            this.cmbproductcategories.Name = "cmbproductcategories";
            this.cmbproductcategories.Size = new System.Drawing.Size(173, 23);
            this.cmbproductcategories.TabIndex = 29;
            // 
            // txtgtton
            // 
            this.txtgtton.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtgtton.Location = new System.Drawing.Point(810, 486);
            this.txtgtton.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtgtton.Name = "txtgtton";
            this.txtgtton.Size = new System.Drawing.Size(88, 18);
            this.txtgtton.TabIndex = 28;
            this.txtgtton.Text = "0";
            this.txtgtton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtgtxuat
            // 
            this.txtgtxuat.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtgtxuat.Location = new System.Drawing.Point(624, 486);
            this.txtgtxuat.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtgtxuat.Name = "txtgtxuat";
            this.txtgtxuat.Size = new System.Drawing.Size(89, 18);
            this.txtgtxuat.TabIndex = 27;
            this.txtgtxuat.Text = "0";
            this.txtgtxuat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtgtrinhap
            // 
            this.txtgtrinhap.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtgtrinhap.Location = new System.Drawing.Point(463, 486);
            this.txtgtrinhap.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtgtrinhap.Name = "txtgtrinhap";
            this.txtgtrinhap.Size = new System.Drawing.Size(89, 18);
            this.txtgtrinhap.TabIndex = 26;
            this.txtgtrinhap.Text = "0";
            this.txtgtrinhap.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblnumofitems
            // 
            this.lblnumofitems.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblnumofitems.Location = new System.Drawing.Point(13, 486);
            this.lblnumofitems.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblnumofitems.Name = "lblnumofitems";
            this.lblnumofitems.Size = new System.Drawing.Size(306, 18);
            this.lblnumofitems.TabIndex = 25;
            this.lblnumofitems.Text = "0";
            this.lblnumofitems.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rdtimebydate
            // 
            this.rdtimebydate.AutoSize = true;
            this.rdtimebydate.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdtimebydate.Location = new System.Drawing.Point(358, 2);
            this.rdtimebydate.Name = "rdtimebydate";
            this.rdtimebydate.Size = new System.Drawing.Size(54, 17);
            this.rdtimebydate.TabIndex = 24;
            this.rdtimebydate.Text = "Ngày";
            this.rdtimebydate.UseVisualStyleBackColor = true;
            this.rdtimebydate.CheckedChanged += new System.EventHandler(this.rdtimebydate_CheckedChanged);
            // 
            // lblsumimporttotal
            // 
            this.lblsumimporttotal.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblsumimporttotal.Location = new System.Drawing.Point(392, 486);
            this.lblsumimporttotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsumimporttotal.Name = "lblsumimporttotal";
            this.lblsumimporttotal.Size = new System.Drawing.Size(58, 18);
            this.lblsumimporttotal.TabIndex = 22;
            this.lblsumimporttotal.Text = "0";
            this.lblsumimporttotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblsumexporttotal
            // 
            this.lblsumexporttotal.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblsumexporttotal.Location = new System.Drawing.Point(560, 486);
            this.lblsumexporttotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsumexporttotal.Name = "lblsumexporttotal";
            this.lblsumexporttotal.Size = new System.Drawing.Size(56, 18);
            this.lblsumexporttotal.TabIndex = 20;
            this.lblsumexporttotal.Text = "0";
            this.lblsumexporttotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // rdimexbyyear
            // 
            this.rdimexbyyear.AutoSize = true;
            this.rdimexbyyear.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdimexbyyear.Location = new System.Drawing.Point(471, 2);
            this.rdimexbyyear.Name = "rdimexbyyear";
            this.rdimexbyyear.Size = new System.Drawing.Size(51, 17);
            this.rdimexbyyear.TabIndex = 19;
            this.rdimexbyyear.Text = "Năm";
            this.rdimexbyyear.UseVisualStyleBackColor = true;
            this.rdimexbyyear.CheckedChanged += new System.EventHandler(this.rdtimebydate_CheckedChanged);
            // 
            // lblsumtotal
            // 
            this.lblsumtotal.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblsumtotal.Location = new System.Drawing.Point(721, 486);
            this.lblsumtotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsumtotal.Name = "lblsumtotal";
            this.lblsumtotal.Size = new System.Drawing.Size(51, 18);
            this.lblsumtotal.TabIndex = 17;
            this.lblsumtotal.Text = "0";
            this.lblsumtotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnprintlist
            // 
            this.btnprintlist.Image = global::CASALE.Properties.Resources.printer;
            this.btnprintlist.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnprintlist.Location = new System.Drawing.Point(846, 19);
            this.btnprintlist.Name = "btnprintlist";
            this.btnprintlist.Size = new System.Drawing.Size(112, 23);
            this.btnprintlist.TabIndex = 13;
            this.btnprintlist.Text = "In danh sách";
            this.btnprintlist.UseVisualStyleBackColor = true;
            this.btnprintlist.Click += new System.EventHandler(this.btnprintlist_Click);
            // 
            // btndisplay
            // 
            this.btndisplay.Image = global::CASALE.Properties.Resources.book_blue_view;
            this.btndisplay.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btndisplay.Location = new System.Drawing.Point(758, 19);
            this.btndisplay.Name = "btndisplay";
            this.btndisplay.Size = new System.Drawing.Size(83, 23);
            this.btndisplay.TabIndex = 12;
            this.btndisplay.Text = "Hiển thị";
            this.btndisplay.UseVisualStyleBackColor = true;
            this.btndisplay.Click += new System.EventHandler(this.btndisplay_Click_1);
            // 
            // dtpietodate
            // 
            this.dtpietodate.CustomFormat = "MM/dd/yyyy";
            this.dtpietodate.Enabled = false;
            this.dtpietodate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpietodate.Location = new System.Drawing.Point(465, 20);
            this.dtpietodate.Name = "dtpietodate";
            this.dtpietodate.Size = new System.Drawing.Size(105, 22);
            this.dtpietodate.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(448, 24);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(12, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "-";
            // 
            // dtpimexdatetime
            // 
            this.dtpimexdatetime.CustomFormat = "dd/MM/yyyy";
            this.dtpimexdatetime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpimexdatetime.Location = new System.Drawing.Point(350, 20);
            this.dtpimexdatetime.Name = "dtpimexdatetime";
            this.dtpimexdatetime.Size = new System.Drawing.Size(93, 22);
            this.dtpimexdatetime.TabIndex = 9;
            // 
            // rdimexbyperiod
            // 
            this.rdimexbyperiod.AutoSize = true;
            this.rdimexbyperiod.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdimexbyperiod.Location = new System.Drawing.Point(524, 2);
            this.rdimexbyperiod.Name = "rdimexbyperiod";
            this.rdimexbyperiod.Size = new System.Drawing.Size(121, 17);
            this.rdimexbyperiod.TabIndex = 8;
            this.rdimexbyperiod.Text = "Khoảng thời gian";
            this.rdimexbyperiod.UseVisualStyleBackColor = true;
            this.rdimexbyperiod.CheckedChanged += new System.EventHandler(this.rdtimebydate_CheckedChanged);
            // 
            // rdimexbymonth
            // 
            this.rdimexbymonth.AutoSize = true;
            this.rdimexbymonth.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdimexbymonth.Location = new System.Drawing.Point(412, 2);
            this.rdimexbymonth.Name = "rdimexbymonth";
            this.rdimexbymonth.Size = new System.Drawing.Size(60, 17);
            this.rdimexbymonth.TabIndex = 7;
            this.rdimexbymonth.Text = "Tháng";
            this.rdimexbymonth.UseVisualStyleBackColor = true;
            this.rdimexbymonth.CheckedChanged += new System.EventHandler(this.rdtimebydate_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(654, 4);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Từ khóa";
            // 
            // txtimexkeyword
            // 
            this.txtimexkeyword.Location = new System.Drawing.Point(652, 20);
            this.txtimexkeyword.Name = "txtimexkeyword";
            this.txtimexkeyword.Size = new System.Drawing.Size(100, 22);
            this.txtimexkeyword.TabIndex = 4;
            // 
            // frmNhapXuat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(959, 559);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.MaximizeBox = false;
            this.Name = "frmNhapXuat";
            this.Text = "Thống kê Nhạp - Xuất";
            this.Load += new System.EventHandler(this.frmNhapXuat_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbltitle;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rdoAll;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbotypeproduct;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbproductcategories;
        private System.Windows.Forms.Label txtgtton;
        private System.Windows.Forms.Label txtgtxuat;
        private System.Windows.Forms.Label txtgtrinhap;
        private System.Windows.Forms.Label lblnumofitems;
        private System.Windows.Forms.RadioButton rdtimebydate;
        private System.Windows.Forms.Label lblsumimporttotal;
        private System.Windows.Forms.Label lblsumexporttotal;
        private System.Windows.Forms.RadioButton rdimexbyyear;
        private System.Windows.Forms.Label lblsumtotal;
        private System.Windows.Forms.Button btnprintlist;
        private System.Windows.Forms.Button btndisplay;
        private System.Windows.Forms.DateTimePicker dtpietodate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpimexdatetime;
        private System.Windows.Forms.RadioButton rdimexbyperiod;
        private System.Windows.Forms.RadioButton rdimexbymonth;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtimexkeyword;
        private System.Windows.Forms.ListView lvitems;
        private System.Windows.Forms.ColumnHeader id;
        private System.Windows.Forms.ColumnHeader stt;
        private System.Windows.Forms.ColumnHeader msp;
        private System.Windows.Forms.ColumnHeader name;
        private System.Windows.Forms.ColumnHeader sln;
        private System.Windows.Forms.ColumnHeader gtn;
        private System.Windows.Forms.ColumnHeader export;
        private System.Windows.Forms.ColumnHeader gtx;
        private System.Windows.Forms.ColumnHeader ton1;
        private System.Windows.Forms.ColumnHeader gtton1;
    }
}