﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CASALE.Class;
using LCProductCartUtiliti;
using LCMultiUtilities;
using System.Drawing.Printing;

namespace CASALE
{
    public partial class frmNhapXuat : templates
    {
        int idaytype = 1; // nhóm theo ngày (thống kê tháng)
        string datetypetype = "";// dung trong in ấn
        string datetypevalue = ""; // dùng trong in ấn
        public frmNhapXuat()
        {
            InitializeComponent();
        }

        private void frmNhapXuat_Load(object sender, EventArgs e)
        {
            dtpimexdatetime.Value = DateTime.Now;
            dtpietodate.Value = DateTime.Now;
            DataTable tb = Common.ProductStatus;
            cbotypeproduct.DataSource = tb;
            cbotypeproduct.DisplayMember = "Status";
            cbotypeproduct.ValueMember = "ID";
            cbotypeproduct.SelectedValue = "-1";
            LoadProductCategories();
            this.rdoAll_CheckedChanged(sender, e);
            Common.LoadCategoriesall(cmbproductcategories, Common.capp_product_code, "-1", Common.vietnames, "1");
        }
        void LoadProductCategories()
        {
            DataTable tb = new DataTable();
            mssql_modcategories.LoadAllChildrencates(ref tb, "-1", Common.capp_customer_code, "VIE", "1");
            string level = "";
            for (int i = 0; i < tb.Rows.Count; i++)
            {
                level = "";
                for (int j = 0; j < Convert.ToInt32(tb.Rows[i]["ilevel"]); j++)
                {
                    level += "»";
                }
                tb.Rows[i]["vname"] = level + tb.Rows[i]["vname"].ToString();
            }
            DataRow dr = tb.NewRow();
            dr["icid"] = -1;
            dr["vname"] = "Tất cả";
            tb.Rows.Add(dr);

            cmbproductcategories.DataSource = tb;
            cmbproductcategories.DisplayMember = "vname";
            cmbproductcategories.ValueMember = "icid";
        }

        void LoadRadioDayTypeCheck()
        {
            dtpietodate.Enabled = false;
            if (rdtimebydate.Checked == true)
            {
                dtpimexdatetime.Format = DateTimePickerFormat.Custom;
                dtpimexdatetime.CustomFormat = "dd/MM/yyyy";
                idaytype = 2;
                datetypetype = " NGÀY ";
                cmbproductcategories.Enabled = true;
                cbotypeproduct.Enabled = true;
                dtpimexdatetime.Enabled = true;
                txtimexkeyword.Enabled = true;
            }
            else if (rdimexbymonth.Checked == true)
            {
                dtpimexdatetime.Format = DateTimePickerFormat.Custom;
                dtpimexdatetime.CustomFormat = "MM/yyyy";
                idaytype = 1;
                datetypetype = " THÁNG ";
                cmbproductcategories.Enabled = true;
                cbotypeproduct.Enabled = true;
                dtpimexdatetime.Enabled = true;
                txtimexkeyword.Enabled = true;
            }
            else if (rdimexbyyear.Checked == true)
            {
                dtpimexdatetime.Format = DateTimePickerFormat.Custom;
                dtpimexdatetime.CustomFormat = "yyyy";
                idaytype = 0;
                datetypetype = " NĂM ";
                cmbproductcategories.Enabled = true;
                cbotypeproduct.Enabled = true;
                dtpimexdatetime.Enabled = true;
                txtimexkeyword.Enabled = true;
            }
            else if (rdimexbyperiod.Checked == true)
            {
                dtpimexdatetime.Format = DateTimePickerFormat.Custom;
                dtpimexdatetime.CustomFormat = "dd/MM/yyyy";
                dtpietodate.CustomFormat = "dd/MM/yyyy";
                dtpietodate.Enabled = true;
                idaytype = 3;
                datetypetype = " TRONG THỜI GIAN ";
                cmbproductcategories.Enabled = true;
                cbotypeproduct.Enabled = true;
                dtpimexdatetime.Enabled = true;
                txtimexkeyword.Enabled = true;
            }
        }

        private void rdtimebydate_CheckedChanged(object sender, EventArgs e)
        {
            LoadRadioDayTypeCheck();
        }
        void LoadSaleReportList()
        {
            DataTable dtreport = new DataTable();

            if (rdoAll.Checked == true)
            {
                dtreport = ImportExport.sale_objects_products_importexport_report_typro(
                    Common.ConnectionString);
            }
            else
            {
                int icid = Convert.ToInt32(cmbproductcategories.SelectedValue.ToString());
                //string sql = "";
                /// lấy báo cáo nhập
                if (cbotypeproduct.SelectedValue.ToString().Equals("-1"))
                {
                    dtreport = ImportExport.sale_objects_products_importexport_report(
                    idaytype, icid, dtpimexdatetime.Value,
                    dtpietodate.Value, txtimexkeyword.Text, Common.ConnectionString);
                }
                if (cbotypeproduct.SelectedValue.ToString().Equals("0"))
                {
                    dtreport = ImportExport.sale_objects_products_importexport_report_typro(
                        idaytype, icid, dtpimexdatetime.Value,
                   dtpietodate.Value, txtimexkeyword.Text, Common.ConnectionString);
                }
            }

            lvitems.Items.Clear();

            double sumtotal = 0;
            double sumimtotal = 0;
            double sumextotal = 0;
            double tongnhap = 0;
            double tongxuat = 0;
            double tongton = 0;
            for (int i = 0; i < dtreport.Rows.Count; i++)
            {
                ListViewItem lvi = new ListViewItem("-1");
                lvi.SubItems.Add((i + 1).ToString());
                lvi.SubItems.Add(dtreport.Rows[i]["procode"].ToString());
                lvi.SubItems.Add(dtreport.Rows[i]["proname"].ToString());
                //lvi.SubItems.Add(dtreport.Rows[i]["provparams"].ToString());
                lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dtreport.Rows[i]["totalimquantity"].ToString()));
                lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dtreport.Rows[i]["totalimvalue"].ToString()));
                tongnhap += Convert.ToDouble(dtreport.Rows[i]["totalimvalue"]);
                lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dtreport.Rows[i]["totalexquantity"].ToString()));
                lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dtreport.Rows[i]["totalexvalue"].ToString()));
                tongxuat += Convert.ToDouble(dtreport.Rows[i]["totalexvalue"]);
                lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dtreport.Rows[i]["proquantity"].ToString()));
                lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice((Convert.ToInt32(dtreport.Rows[i]["proquantity"]) *
                    Convert.ToDouble(dtreport.Rows[i]["proprice"])).ToString()));
                lvitems.Items.Add(lvi);
                sumimtotal += Convert.ToInt32(dtreport.Rows[i]["totalimquantity"]);
                tongton += Convert.ToDouble((Convert.ToInt32(dtreport.Rows[i]["proquantity"]) *
                    Convert.ToDouble(dtreport.Rows[i]["proprice"])).ToString());
                sumextotal += Convert.ToInt32(dtreport.Rows[i]["totalexquantity"]);
                sumtotal += Convert.ToInt32(dtreport.Rows[i]["proquantity"]);
            }

            lblsumexporttotal.Text = LCUtiliti.ConvertNumber.FomatPrice(sumextotal.ToString());
            lblsumimporttotal.Text = LCUtiliti.ConvertNumber.FomatPrice(sumimtotal.ToString());
            lblsumtotal.Text = LCUtiliti.ConvertNumber.FomatPrice(sumtotal.ToString());
            lblnumofitems.Text = dtreport.Rows.Count.ToString() + " mục hiển thị";
            txtgtrinhap.Text = LCUtiliti.ConvertNumber.FomatPrice(tongnhap.ToString());
            txtgtxuat.Text = LCUtiliti.ConvertNumber.FomatPrice(tongxuat.ToString());
            txtgtton.Text = LCUtiliti.ConvertNumber.FomatPrice(tongton.ToString());
        }

        private void btndisplay_Click(object sender, EventArgs e)
        {
            LoadSaleReportList();
        }

        private void btndisplay_Click_1(object sender, EventArgs e)
        {
            LoadSaleReportList();
        }

        private void cbotypeproduct_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void rdoAll_CheckedChanged(object sender, EventArgs e)
        {
            cmbproductcategories.Enabled = false;
            cbotypeproduct.Enabled = false;
            dtpimexdatetime.Enabled = false;
            txtimexkeyword.Enabled = false;
        }
        #region bien
        PrintPreviewDialog printpreviewdialog = new PrintPreviewDialog();
        System.Drawing.Printing.PrintDocument printdocument = new System.Drawing.Printing.PrintDocument();
        float h = 0.0f;
        string PrintTitle = "";// tiêu đề in.
        DateTime PrintImExDateTime = DateTime.Now;
        DataTable PrintDtImExDetail = new DataTable();
        int PrintFromPage = 0;
        int PrintCurrentRow = 0;
        double ftotal = 0;
        double nhap = 0;
        double gtnhap = 0;
        double xuat = 0;
        double gtxuat = 0;
        double ton = 0;
        double gtton = 0;
        #endregion
        private void btnprintlist_Click(object sender, EventArgs e)
        {
            #region dua gia tri ve mac dinh ban dau
            nhap = 0;
            gtnhap = 0;
            xuat = 0;
            gtxuat = 0;
            ton = 0;
            gtton = 0;
            #endregion


            if (cbotypeproduct.SelectedValue.ToString().Equals("-1"))
            {
                PrintDtImExDetail = ImportExport.sale_objects_products_importexport_report(
                idaytype, -1, dtpimexdatetime.Value,
                dtpietodate.Value, txtimexkeyword.Text, Common.ConnectionString);
            }
            if (cbotypeproduct.SelectedValue.ToString().Equals("0"))
            {
                PrintDtImExDetail = ImportExport.sale_objects_products_importexport_report_typro(
               idaytype, -1, dtpimexdatetime.Value,
               dtpietodate.Value, txtimexkeyword.Text, Common.ConnectionString);
            }
            PrintFromPage = 0;
            PrintCurrentRow = 0;
            ftotal = 0;

            printdocument = new PrintDocument();
            printdocument.PrintPage += new PrintPageEventHandler(printorder_PrintPage);
            //PrintDialog pdl = new PrintDialog();
            //if (pdl.ShowDialog() == DialogResult.OK)
            //{
            //    printdocument.PrinterSettings = pdl.PrinterSettings;
            //    printdocument.Print();
            //}
            printdocument.Print();
        }

        private void printorder_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            #region
            if (PrintDtImExDetail.Rows.Count == 0 || PrintCurrentRow >= PrintDtImExDetail.Rows.Count)
            {
                e.HasMorePages = false;
                PrintCurrentRow = 0;
                PrintFromPage = 0;

                return;
            }

            Graphics g = e.Graphics;
            Rectangle rFull = new Rectangle(
                e.PageBounds.Left - 10,
                e.PageBounds.Top,
                e.PageBounds.Right,
                e.PageBounds.Bottom);

            StringFormat sf = new StringFormat();
            float x = 10;
            float y = 10;
            float colxpadding = 3;
            float colypadding = 3;

            Font titleFont = new Font("Tahoma", 8, System.Drawing.GraphicsUnit.Point);
            Font titleFont2 = new Font("Tahoma", 10, System.Drawing.GraphicsUnit.Point);

            if (PrintFromPage == 0)
            {
                #region header

                PrintTitle = lbltitle.Text;

                g.DrawString(Common.CorporationName.ToString().ToUpper(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString(Common.CompanyName.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString(Common.CompanyAddress.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString("Điện thoại: " + Common.CompanyPhone.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);

                sf.Alignment = StringAlignment.Center;
                //float y1 = 32;
                y += titleFont.Height + 5;
                Font titleFont1 = new Font("Tahoma", 16, System.Drawing.GraphicsUnit.Point);
                g.DrawString(PrintTitle, titleFont1, Brushes.Black, new RectangleF(3, y, e.PageBounds.Width - 20, 32), sf);

                y += titleFont1.Height + 2;
                if (PrintDtImExDetail.Rows.Count > 0)
                {
                    //sf.Alignment = StringAlignment.Near;
                    //g.DrawString("Mã đơn hàng:" + PrintDtImExDetail.Rows[0]["procode"].ToString().ToUpper(),
                    //    titleFont2, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 20, 32), sf);
                    //y += titleFont2.Height;
                    //g.DrawString("Thời gian:" + Convert.ToDateTime(PrintDtImEx.Rows[0]["ddatetime"]).ToString("dd-MM-yyyy"),
                    //    titleFont2, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 20, 32), sf);

                    //y += titleFont2.Height + 5;
                    sf.Alignment = StringAlignment.Near;
                    g.DrawString("Danh mục sản phẩm",
                       titleFont2, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 20, 32), sf);
                    y += titleFont2.Height + 1;
                }
                #endregion
            }
            else
            {
                y = 50;
            }
            #endregion

            #region Table Header
            for (int i = 0; i < 1; i++)
            {
                x = 20;
                float h = 25;
                float w = 0;
                for (int j = 0; j < 10; j++)
                {
                    if (j > 0) x += w;

                    switch (j)
                    {
                        case 0:
                            w = 40;
                            break;
                        case 1:
                            w = 80;
                            break;
                        case 2:
                            w = 200;
                            break;
                        case 3:
                            w = 50;
                            break;
                        case 4:
                            w = 40;
                            break;
                        case 5:
                            w = 80;
                            break;
                        case 6:
                            w = 40;
                            break;
                        case 7:
                            w = 80;
                            break;
                        case 8:
                            w = 40;
                            break;
                        case 9:
                            w = 80;
                            break;
                    }
                    Brush brushHeader = new SolidBrush(Color.WhiteSmoke);
                    Rectangle rect = new Rectangle(Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                    g.FillRectangle(brushHeader, Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                    g.DrawRectangle(new Pen(Brushes.Black), rect);
                }
                // drawstrring
                x = 20;
                string content = "";
                for (int j = 0; j < 10; j++)
                {
                    if (j > 0) x += w;
                    StringFormat contentsf = new StringFormat();
                    contentsf.Alignment = StringAlignment.Near;
                    switch (j)
                    {
                        case 0:
                            w = 40;
                            content = "STT";
                            break;
                        case 1:
                            w = 80;
                            content = "MSP";
                            break;
                        case 2:
                            w = 200;
                            content = "Tên sản phẩm";
                            break;
                        case 3:
                            w = 50;
                            content = "Đơn vị";
                            break;
                        case 4:
                            w = 40;
                            content = "Nhập ";
                            contentsf.Alignment = StringAlignment.Far;
                            break;
                        case 5:
                            w = 80;
                            content = "GT.Nhập";
                            break;
                        case 6:
                            w = 40;
                            content = "Xuất";
                            contentsf.Alignment = StringAlignment.Far;
                            break;
                        case 7:
                            w = 80;
                            content = "GT.Xuất";
                            break;
                        case 8:
                            w = 40;
                            content = "Tồn";
                            contentsf.Alignment = StringAlignment.Far;
                            break;
                        case 9:
                            w = 80;
                            content = "GT.Tồn";
                            break;
                    }
                    Font titleFont3 = new Font("Tahoma", 8, FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
                    Rectangle rectC = new Rectangle(Convert.ToInt32(x + colxpadding), Convert.ToInt32(y + colypadding), Convert.ToInt32(w), Convert.ToInt32(h));
                    g.DrawString(content, titleFont3, Brushes.Black, rectC, contentsf);

                }
                y += h;
            }
            #endregion

            #region in noi dung

            for (int i = PrintCurrentRow; i < PrintDtImExDetail.Rows.Count; i++)
            {
                x = 20;
                #region
                if (PrintDtImExDetail.Rows[i]["proname"].ToString().Length > 40)
                {
                    h = 40;
                }
                else
                {
                    h = 32;
                }
                #endregion
                float w = 0;
                #region Print Item
                if (PrintDtImExDetail.Rows.Count > 0)
                {
                    #region ve khung
                    for (int j = 0; j < 10; j++)
                    {
                        if (j > 0) x += w;
                        switch (j)
                        {
                            case 0:
                                w = 40;
                                break;
                            case 1:
                                w = 80;
                                break;
                            case 2:
                                w = 200;
                                break;
                            case 3:
                                w = 50;
                                break;
                            case 4:
                                w = 40;
                                break;
                            case 5:
                                w = 80;
                                break;
                            case 6:
                                w = 40;
                                break;
                            case 7:
                                w = 80;
                                break;
                            case 8:
                                w = 40;
                                break;
                            case 9:
                                w = 80;
                                break;
                        }

                        Rectangle rect = new Rectangle(Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                        g.DrawRectangle(new Pen(Brushes.Black), rect);
                    }
                    // drawstrring
                    #endregion
                    x = 20;
                    string content = "";

                    for (int j = 0; j < 10; j++)
                    {
                        if (j > 0) x += w;
                        StringFormat contentsf = new StringFormat();
                        contentsf.Alignment = StringAlignment.Near;
                        switch (j)
                        {
                            case 0:
                                w = 40;
                                content = (i + 1).ToString();
                                break;
                            case 1:
                                w = 80;
                                content = PrintDtImExDetail.Rows[i]["procode"].ToString().ToUpper();
                                break;
                            case 2:
                                w = 200;
                                content = PrintDtImExDetail.Rows[i]["proname"].ToString();
                                break;
                            case 3:
                                w = 50;
                                content = PrintDtImExDetail.Rows[i]["provparams"].ToString();
                                break;
                            case 4:
                                w = 37;
                                contentsf.Alignment = StringAlignment.Far;
                                content = LCUtiliti.ConvertNumber.FomatPrice( PrintDtImExDetail.Rows[i]["totalimquantity"].ToString());
                                nhap += Convert.ToDouble(PrintDtImExDetail.Rows[i]["totalimquantity"]);
                                break;
                            case 5:
                                w = 80;
                                contentsf.Alignment = StringAlignment.Far;
                                content =  LCUtiliti.ConvertNumber.FomatPrice(PrintDtImExDetail.Rows[i]["totalimvalue"].ToString());
                                gtnhap += Convert.ToDouble(PrintDtImExDetail.Rows[i]["totalimvalue"]);
                                break;
                            case 6:
                                w = 40;
                                contentsf.Alignment = StringAlignment.Far;
                                content =  LCUtiliti.ConvertNumber.FomatPrice(PrintDtImExDetail.Rows[i]["totalexquantity"].ToString());
                                xuat += Convert.ToDouble(PrintDtImExDetail.Rows[i]["totalexquantity"]);
                                break;
                            case 7:
                                w = 80;
                                contentsf.Alignment = StringAlignment.Far;
                                content =  LCUtiliti.ConvertNumber.FomatPrice(PrintDtImExDetail.Rows[i]["totalexvalue"].ToString());
                                gtxuat += Convert.ToDouble(PrintDtImExDetail.Rows[i]["totalexvalue"]);
                                break;
                            case 8:
                                w = 40;
                                contentsf.Alignment = StringAlignment.Far;
                                content =  LCUtiliti.ConvertNumber.FomatPrice(PrintDtImExDetail.Rows[i]["proquantity"].ToString());
                                ton += Convert.ToDouble(PrintDtImExDetail.Rows[i]["proquantity"]);
                                break;
                            case 9:
                                w = 80;
                                contentsf.Alignment = StringAlignment.Far;
                                string name = (Convert.ToInt32(PrintDtImExDetail.Rows[i]["proquantity"]) *
                                 Convert.ToDouble(PrintDtImExDetail.Rows[i]["proprice"])).ToString();
                                gtton += Convert.ToDouble(name);
                                content =  LCUtiliti.ConvertNumber.FomatPrice(name.ToString());
                                break;
                        }


                        Font titleFont3 = new Font("Tahoma", 9, System.Drawing.GraphicsUnit.Point);
                        Rectangle rectC = new Rectangle(Convert.ToInt32(x + colxpadding), Convert.ToInt32(y + colypadding), Convert.ToInt32(w), Convert.ToInt32(h));
                        g.DrawString(content, titleFont2, Brushes.Black, rectC, contentsf);
                    }
                    y += h;

                }
                #endregion

                PrintCurrentRow++;
                if (y > e.PageBounds.Height - 115)
                    break;
            }
            #endregion
            bool last = false;
            // e.HasMorePages = true;
            PrintFromPage++;
            if (PrintCurrentRow >= PrintDtImExDetail.Rows.Count)
            {
                last = true;
            }
            else
            {
                last = false;
            }

            if (last == true)
            {
                sf.Alignment = StringAlignment.Near;
                g.DrawString("Tổng: " +  LCUtiliti.ConvertNumber.FomatPrice(PrintDtImExDetail.Rows.Count.ToString()), titleFont2, Brushes.Black, new RectangleF(20, y += h - 20, e.PageBounds.Width - 40, 32), sf);
                //sf.Alignment = StringAlignment.Far;
                //g.DrawString(nhap.ToString(), titleFont2, Brushes.Black, new RectangleF(0, y += h - 30, e.PageBounds.Width - 470, 32), sf);
                //sf.Alignment = StringAlignment.Far;
                //g.DrawString(gtnhap.ToString(), titleFont2, Brushes.Black, new RectangleF(0, y += h - 33, e.PageBounds.Width - 360, 32), sf);
                //sf.Alignment = StringAlignment.Far;
                //g.DrawString(xuat.ToString(), titleFont2, Brushes.Black, new RectangleF(0, y += h - 33, e.PageBounds.Width - 320, 32), sf);
                //sf.Alignment = StringAlignment.Far;
                //g.DrawString(gtxuat.ToString(), titleFont2, Brushes.Black, new RectangleF(0, y += h - 33, e.PageBounds.Width - 230, 32), sf);
                sf.Alignment = StringAlignment.Far;
                g.DrawString( LCUtiliti.ConvertNumber.FomatPrice(ton.ToString()), titleFont2, Brushes.Black, new RectangleF(0, y += h - 32, e.PageBounds.Width - 190, 32), sf);
                sf.Alignment = StringAlignment.Far;
                g.DrawString( LCUtiliti.ConvertNumber.FomatPrice(gtton.ToString()), titleFont2, Brushes.Black, new RectangleF(0, y += h - 32, e.PageBounds.Width - 100, 32), sf);
                //Pen _pen = new Pen(Color.Black, 1.5F);
                //g.DrawLine(_pen, 600, y + h, 200, y + h);
                sf.Alignment = StringAlignment.Near;
                g.DrawString("Người lập", titleFont2, Brushes.Black, new RectangleF(20, y + h + 30, e.PageBounds.Width - 40, 32), sf);
                sf.Alignment = StringAlignment.Center;
                g.DrawString("Thủ kho", titleFont2, Brushes.Black, new RectangleF(0, y + h + 30, e.PageBounds.Width - 40, 32), sf);
                sf.Alignment = StringAlignment.Far;
                g.DrawString("Giám đốc", titleFont2, Brushes.Black, new RectangleF(0, y + h + 30, e.PageBounds.Width - 120, 32), sf);
            }
            g.DrawString("Trang " + (PrintFromPage).ToString(), titleFont2, Brushes.Black, new RectangleF(e.PageBounds.Width - 120, e.PageBounds.Height - 60, 100, 20));

            if (last == false)
            {
                e.HasMorePages = true;
            }
            else
            {
                e.HasMorePages = false;
                PrintFromPage = 0;
                PrintCurrentRow = 0;
                ftotal = 0;
                nhap = 0;
                gtnhap = 0;
                xuat = 0;
                gtxuat = 0;
                ton = 0;
                gtton = 0;
            }
        }
    }
}
