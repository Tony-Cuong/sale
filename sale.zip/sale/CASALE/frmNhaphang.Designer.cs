﻿using CASALE.Class;
namespace CASALE
{
    partial class frmNhaphang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.frmnhaphang = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cmborderlistpages = new System.Windows.Forms.ComboBox();
            this.cmborderlistitemsperpage = new System.Windows.Forms.ComboBox();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtkeyword = new System.Windows.Forms.TextBox();
            this.btnAddImport = new System.Windows.Forms.Button();
            this.lvListImport = new System.Windows.Forms.ListView();
            this.ID = new System.Windows.Forms.ColumnHeader();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader13 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader12 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.cmnImport = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmnImportDetail = new System.Windows.Forms.ToolStripMenuItem();
            this.cmnDeleteImport = new System.Windows.Forms.ToolStripMenuItem();
            this.lblTotalImport = new System.Windows.Forms.Label();
            this.lblTonggiatri = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pnImportDetail = new System.Windows.Forms.Panel();
            this.lbltongt1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblmoneyunit = new System.Windows.Forms.Label();
            this.lblTongtien = new System.Windows.Forms.Label();
            this.btncloseorderdetail = new System.Windows.Forms.Button();
            this.lblmsg = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lvicd = new System.Windows.Forms.ListView();
            this.columnHeader16 = new System.Windows.Forms.ColumnHeader();
            this.key = new System.Windows.Forms.ColumnHeader();
            this.lvtitle = new System.Windows.Forms.ColumnHeader();
            this.columnHeader17 = new System.Windows.Forms.ColumnHeader();
            this.cuont = new System.Windows.Forms.ColumnHeader();
            this.columnHeader18 = new System.Windows.Forms.ColumnHeader();
            this.label17 = new System.Windows.Forms.Label();
            this.txtunit = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txttax = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtcartdetailproductcode = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDongia = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.nudSoluong = new System.Windows.Forms.NumericUpDown();
            this.txtItemname = new System.Windows.Forms.TextBox();
            this.btnNhap = new System.Windows.Forms.Button();
            this.lvImportDetails = new System.Windows.Forms.ListView();
            this.columnHeader11 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader6 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader10 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader15 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader7 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader8 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader14 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader9 = new System.Windows.Forms.ColumnHeader();
            this.cmnUpdateDelete = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmnUpdate = new System.Windows.Forms.ToolStripMenuItem();
            this.cmnDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.txtNguoilap = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtNgaythang = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtimportorderid = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btncancelncreatenew = new System.Windows.Forms.Button();
            this.btnsaveimportorder = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.cmnImport.SuspendLayout();
            this.pnImportDetail.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSoluong)).BeginInit();
            this.cmnUpdateDelete.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(758, 32);
            this.panel1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(6, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "QUẢN LÝ NHẬP HÀNG";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.cmborderlistpages);
            this.panel2.Controls.Add(this.cmborderlistitemsperpage);
            this.panel2.Controls.Add(this.btnExportExcel);
            this.panel2.Controls.Add(this.btnSearch);
            this.panel2.Controls.Add(this.txtkeyword);
            this.panel2.Controls.Add(this.btnAddImport);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel2.ForeColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(0, 32);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(758, 41);
            this.panel2.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label11.Location = new System.Drawing.Point(176, 1);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 13);
            this.label11.TabIndex = 18;
            this.label11.Text = "Từ khóa";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label10.Location = new System.Drawing.Point(123, 1);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Trang";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label9.Location = new System.Drawing.Point(13, 1);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Số mục / trang";
            // 
            // cmborderlistpages
            // 
            this.cmborderlistpages.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cmborderlistpages.FormattingEnabled = true;
            this.cmborderlistpages.Location = new System.Drawing.Point(124, 17);
            this.cmborderlistpages.Name = "cmborderlistpages";
            this.cmborderlistpages.Size = new System.Drawing.Size(49, 23);
            this.cmborderlistpages.TabIndex = 15;
            // 
            // cmborderlistitemsperpage
            // 
            this.cmborderlistitemsperpage.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cmborderlistitemsperpage.FormattingEnabled = true;
            this.cmborderlistitemsperpage.Location = new System.Drawing.Point(16, 17);
            this.cmborderlistitemsperpage.Name = "cmborderlistitemsperpage";
            this.cmborderlistitemsperpage.Size = new System.Drawing.Size(106, 23);
            this.cmborderlistitemsperpage.TabIndex = 14;
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnExportExcel.Image = global::CASALE.Properties.Resources.page_white_excel;
            this.btnExportExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportExcel.Location = new System.Drawing.Point(402, 17);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(109, 23);
            this.btnExportExcel.TabIndex = 13;
            this.btnExportExcel.Text = "Xuất ra Excel";
            this.btnExportExcel.UseVisualStyleBackColor = true;
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnSearch.Image = global::CASALE.Properties.Resources.book_blue_view;
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnSearch.Location = new System.Drawing.Point(306, 17);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(96, 23);
            this.btnSearch.TabIndex = 12;
            this.btnSearch.Text = "Hiển thị";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtkeyword
            // 
            this.txtkeyword.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtkeyword.Location = new System.Drawing.Point(175, 17);
            this.txtkeyword.Name = "txtkeyword";
            this.txtkeyword.Size = new System.Drawing.Size(130, 22);
            this.txtkeyword.TabIndex = 11;
            // 
            // btnAddImport
            // 
            this.btnAddImport.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnAddImport.Image = global::CASALE.Properties.Resources.action_add;
            this.btnAddImport.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnAddImport.Location = new System.Drawing.Point(517, 15);
            this.btnAddImport.Name = "btnAddImport";
            this.btnAddImport.Size = new System.Drawing.Size(111, 23);
            this.btnAddImport.TabIndex = 10;
            this.btnAddImport.Text = "Tạo HĐ Nhập";
            this.btnAddImport.UseVisualStyleBackColor = true;
            this.btnAddImport.Click += new System.EventHandler(this.btnAddImport_Click);
            // 
            // lvListImport
            // 
            this.lvListImport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvListImport.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ID,
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader13,
            this.columnHeader12,
            this.columnHeader4});
            this.lvListImport.ContextMenuStrip = this.cmnImport;
            this.lvListImport.FullRowSelect = true;
            this.lvListImport.GridLines = true;
            this.lvListImport.Location = new System.Drawing.Point(2, 73);
            this.lvListImport.Name = "lvListImport";
            this.lvListImport.Size = new System.Drawing.Size(753, 392);
            this.lvListImport.TabIndex = 4;
            this.lvListImport.UseCompatibleStateImageBehavior = false;
            this.lvListImport.View = System.Windows.Forms.View.Details;
            // 
            // ID
            // 
            this.ID.Width = 0;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "#";
            this.columnHeader1.Width = 35;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Mã hóa đơn";
            this.columnHeader2.Width = 121;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Ngày lập";
            this.columnHeader3.Width = 118;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Sản phẩm";
            this.columnHeader13.Width = 83;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Người lập";
            this.columnHeader12.Width = 116;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Giá trị";
            this.columnHeader4.Width = 146;
            // 
            // cmnImport
            // 
            this.cmnImport.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmnImportDetail,
            this.cmnDeleteImport});
            this.cmnImport.Name = "cmnImport";
            this.cmnImport.Size = new System.Drawing.Size(192, 48);
            // 
            // cmnImportDetail
            // 
            this.cmnImportDetail.Image = global::CASALE.Properties.Resources.books11;
            this.cmnImportDetail.Name = "cmnImportDetail";
            this.cmnImportDetail.Size = new System.Drawing.Size(191, 22);
            this.cmnImportDetail.Text = "Xem chi tiết đơn hàng";
            this.cmnImportDetail.Click += new System.EventHandler(this.cmnImportDetail_Click);
            // 
            // cmnDeleteImport
            // 
            this.cmnDeleteImport.Image = global::CASALE.Properties.Resources.trash_can;
            this.cmnDeleteImport.Name = "cmnDeleteImport";
            this.cmnDeleteImport.Size = new System.Drawing.Size(191, 22);
            this.cmnDeleteImport.Text = "Xóa";
            this.cmnDeleteImport.Click += new System.EventHandler(this.cmnDeleteImport_Click);
            // 
            // lblTotalImport
            // 
            this.lblTotalImport.AutoSize = true;
            this.lblTotalImport.Location = new System.Drawing.Point(114, 468);
            this.lblTotalImport.Name = "lblTotalImport";
            this.lblTotalImport.Size = new System.Drawing.Size(13, 15);
            this.lblTotalImport.TabIndex = 15;
            this.lblTotalImport.Text = "0";
            // 
            // lblTonggiatri
            // 
            this.lblTonggiatri.Location = new System.Drawing.Point(476, 468);
            this.lblTonggiatri.Name = "lblTonggiatri";
            this.lblTonggiatri.Size = new System.Drawing.Size(228, 14);
            this.lblTonggiatri.TabIndex = 17;
            this.lblTonggiatri.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(390, 468);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 15);
            this.label12.TabIndex = 16;
            this.label12.Text = "Tổng giá trị:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1, 468);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 15);
            this.label8.TabIndex = 14;
            this.label8.Text = "Tổng số hóa đơn:";
            // 
            // pnImportDetail
            // 
            this.pnImportDetail.Controls.Add(this.lbltongt1);
            this.pnImportDetail.Controls.Add(this.panel3);
            this.pnImportDetail.Controls.Add(this.lblmoneyunit);
            this.pnImportDetail.Controls.Add(this.lblTongtien);
            this.pnImportDetail.Controls.Add(this.btncloseorderdetail);
            this.pnImportDetail.Controls.Add(this.lblmsg);
            this.pnImportDetail.Controls.Add(this.groupBox1);
            this.pnImportDetail.Controls.Add(this.txtNguoilap);
            this.pnImportDetail.Controls.Add(this.label16);
            this.pnImportDetail.Controls.Add(this.txtNgaythang);
            this.pnImportDetail.Controls.Add(this.label15);
            this.pnImportDetail.Controls.Add(this.txtimportorderid);
            this.pnImportDetail.Controls.Add(this.label14);
            this.pnImportDetail.Controls.Add(this.label7);
            this.pnImportDetail.Controls.Add(this.btncancelncreatenew);
            this.pnImportDetail.Controls.Add(this.btnsaveimportorder);
            this.pnImportDetail.Location = new System.Drawing.Point(4, 73);
            this.pnImportDetail.Name = "pnImportDetail";
            this.pnImportDetail.Size = new System.Drawing.Size(754, 411);
            this.pnImportDetail.TabIndex = 18;
            this.pnImportDetail.Visible = false;
            // 
            // lbltongt1
            // 
            this.lbltongt1.Location = new System.Drawing.Point(526, 392);
            this.lbltongt1.Name = "lbltongt1";
            this.lbltongt1.Size = new System.Drawing.Size(142, 14);
            this.lbltongt1.TabIndex = 28;
            this.lbltongt1.Text = "0";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel3.Controls.Add(this.label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(754, 25);
            this.panel3.TabIndex = 27;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(4, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(186, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "CHI TIẾT HÓA ĐƠN NHẬP";
            // 
            // lblmoneyunit
            // 
            this.lblmoneyunit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblmoneyunit.Location = new System.Drawing.Point(666, 391);
            this.lblmoneyunit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmoneyunit.Name = "lblmoneyunit";
            this.lblmoneyunit.Size = new System.Drawing.Size(36, 18);
            this.lblmoneyunit.TabIndex = 26;
            this.lblmoneyunit.Text = "VNĐ";
            // 
            // lblTongtien
            // 
            this.lblTongtien.Location = new System.Drawing.Point(525, 391);
            this.lblTongtien.Name = "lblTongtien";
            this.lblTongtien.Size = new System.Drawing.Size(142, 14);
            this.lblTongtien.TabIndex = 14;
            this.lblTongtien.Text = "0";
            this.lblTongtien.Visible = false;
            // 
            // btncloseorderdetail
            // 
            this.btncloseorderdetail.Image = global::CASALE.Properties.Resources.action_delete;
            this.btncloseorderdetail.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btncloseorderdetail.Location = new System.Drawing.Point(285, 387);
            this.btncloseorderdetail.Name = "btncloseorderdetail";
            this.btncloseorderdetail.Size = new System.Drawing.Size(91, 23);
            this.btncloseorderdetail.TabIndex = 25;
            this.btncloseorderdetail.Text = "Đóng lại";
            this.btncloseorderdetail.UseVisualStyleBackColor = true;
            this.btncloseorderdetail.Click += new System.EventHandler(this.btncloseorderdetail_Click);
            // 
            // lblmsg
            // 
            this.lblmsg.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblmsg.ForeColor = System.Drawing.Color.Crimson;
            this.lblmsg.Location = new System.Drawing.Point(10, 34);
            this.lblmsg.Name = "lblmsg";
            this.lblmsg.Size = new System.Drawing.Size(695, 13);
            this.lblmsg.TabIndex = 24;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lvicd);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.txtunit);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txttax);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtcartdetailproductcode);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtDongia);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.nudSoluong);
            this.groupBox1.Controls.Add(this.txtItemname);
            this.groupBox1.Controls.Add(this.btnNhap);
            this.groupBox1.Controls.Add(this.lvImportDetails);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox1.Location = new System.Drawing.Point(3, 107);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(741, 280);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chi tiết đơn hàng nhập";
            // 
            // lvicd
            // 
            this.lvicd.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader16,
            this.key,
            this.lvtitle,
            this.columnHeader17,
            this.cuont,
            this.columnHeader18});
            this.lvicd.FullRowSelect = true;
            this.lvicd.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.lvicd.Location = new System.Drawing.Point(10, 59);
            this.lvicd.Name = "lvicd";
            this.lvicd.Size = new System.Drawing.Size(384, 74);
            this.lvicd.TabIndex = 73;
            this.lvicd.UseCompatibleStateImageBehavior = false;
            this.lvicd.View = System.Windows.Forms.View.Details;
            this.lvicd.Visible = false;
            this.lvicd.DoubleClick += new System.EventHandler(this.lvicd_DoubleClick);
            this.lvicd.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lvicd_KeyUp);
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "";
            this.columnHeader16.Width = 0;
            // 
            // key
            // 
            this.key.Text = "Key";
            this.key.Width = 100;
            // 
            // lvtitle
            // 
            this.lvtitle.Text = "";
            this.lvtitle.Width = 130;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Width = 0;
            // 
            // cuont
            // 
            this.cuont.Text = "Nước sản xuất";
            this.cuont.Width = 127;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "gia";
            this.columnHeader18.Width = 0;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label17.Location = new System.Drawing.Point(312, 19);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 13);
            this.label17.TabIndex = 21;
            this.label17.Text = "Đơn vị tính";
            // 
            // txtunit
            // 
            this.txtunit.Enabled = false;
            this.txtunit.Location = new System.Drawing.Point(316, 36);
            this.txtunit.Name = "txtunit";
            this.txtunit.Size = new System.Drawing.Size(78, 22);
            this.txtunit.TabIndex = 22;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(546, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "Thuế (%)";
            // 
            // txttax
            // 
            this.txttax.Location = new System.Drawing.Point(548, 37);
            this.txttax.Name = "txttax";
            this.txttax.Size = new System.Drawing.Size(54, 22);
            this.txttax.TabIndex = 20;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(7, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Mã sản phẩm";
            // 
            // txtcartdetailproductcode
            // 
            this.txtcartdetailproductcode.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtcartdetailproductcode.Location = new System.Drawing.Point(10, 37);
            this.txtcartdetailproductcode.Name = "txtcartdetailproductcode";
            this.txtcartdetailproductcode.Size = new System.Drawing.Size(115, 22);
            this.txtcartdetailproductcode.TabIndex = 2;
            this.txtcartdetailproductcode.TextChanged += new System.EventHandler(this.txtcartdetailproductcode_TextChanged);
            this.txtcartdetailproductcode.Leave += new System.EventHandler(this.txtcartdetailproductcode_Leave);
            this.txtcartdetailproductcode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtcartdetailproductcode_KeyUp);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.Location = new System.Drawing.Point(396, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Đơn giá";
            // 
            // txtDongia
            // 
            this.txtDongia.Location = new System.Drawing.Point(397, 37);
            this.txtDongia.Name = "txtDongia";
            this.txtDongia.Size = new System.Drawing.Size(88, 22);
            this.txtDongia.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.Location = new System.Drawing.Point(487, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Số lượng";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label13.Location = new System.Drawing.Point(127, 21);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 13);
            this.label13.TabIndex = 16;
            this.label13.Text = "Tên sản phẩm";
            // 
            // nudSoluong
            // 
            this.nudSoluong.ForeColor = System.Drawing.Color.Black;
            this.nudSoluong.Location = new System.Drawing.Point(490, 37);
            this.nudSoluong.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nudSoluong.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudSoluong.Name = "nudSoluong";
            this.nudSoluong.Size = new System.Drawing.Size(54, 22);
            this.nudSoluong.TabIndex = 9;
            this.nudSoluong.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudSoluong.KeyUp += new System.Windows.Forms.KeyEventHandler(this.nudSoluong_KeyUp);
            // 
            // txtItemname
            // 
            this.txtItemname.Location = new System.Drawing.Point(129, 37);
            this.txtItemname.Name = "txtItemname";
            this.txtItemname.Size = new System.Drawing.Size(184, 22);
            this.txtItemname.TabIndex = 15;
            this.txtItemname.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemname_KeyUp);
            // 
            // btnNhap
            // 
            this.btnNhap.Image = global::CASALE.Properties.Resources.action_add;
            this.btnNhap.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnNhap.Location = new System.Drawing.Point(605, 36);
            this.btnNhap.Name = "btnNhap";
            this.btnNhap.Size = new System.Drawing.Size(126, 23);
            this.btnNhap.TabIndex = 12;
            this.btnNhap.Text = "Nhập hàng";
            this.btnNhap.UseVisualStyleBackColor = true;
            this.btnNhap.Click += new System.EventHandler(this.btnNhap_Click_1);
            // 
            // lvImportDetails
            // 
            this.lvImportDetails.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader11,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader10,
            this.columnHeader15,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader14,
            this.columnHeader9});
            this.lvImportDetails.ContextMenuStrip = this.cmnUpdateDelete;
            this.lvImportDetails.FullRowSelect = true;
            this.lvImportDetails.GridLines = true;
            this.lvImportDetails.Location = new System.Drawing.Point(10, 63);
            this.lvImportDetails.Name = "lvImportDetails";
            this.lvImportDetails.Size = new System.Drawing.Size(731, 211);
            this.lvImportDetails.TabIndex = 1;
            this.lvImportDetails.UseCompatibleStateImageBehavior = false;
            this.lvImportDetails.View = System.Windows.Forms.View.Details;
            this.lvImportDetails.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lvImportDetails_KeyUp);
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "ID";
            this.columnHeader11.Width = 0;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "STT";
            this.columnHeader5.Width = 43;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Mã sản phẩm";
            this.columnHeader6.Width = 110;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Tên sản phẩm";
            this.columnHeader10.Width = 127;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Đ.V";
            this.columnHeader15.Width = 65;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Đơn giá";
            this.columnHeader7.Width = 119;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Số lượng";
            this.columnHeader8.Width = 68;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Thuế";
            this.columnHeader14.Width = 43;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Thành tiền";
            this.columnHeader9.Width = 141;
            // 
            // cmnUpdateDelete
            // 
            this.cmnUpdateDelete.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmnUpdate,
            this.cmnDelete});
            this.cmnUpdateDelete.Name = "contextMenuStrip1";
            this.cmnUpdateDelete.Size = new System.Drawing.Size(133, 48);
            // 
            // cmnUpdate
            // 
            this.cmnUpdate.Enabled = false;
            this.cmnUpdate.Image = global::CASALE.Properties.Resources.edit1;
            this.cmnUpdate.Name = "cmnUpdate";
            this.cmnUpdate.Size = new System.Drawing.Size(132, 22);
            this.cmnUpdate.Text = "Hiệu chỉnh";
            // 
            // cmnDelete
            // 
            this.cmnDelete.Image = global::CASALE.Properties.Resources.trash_can;
            this.cmnDelete.Name = "cmnDelete";
            this.cmnDelete.Size = new System.Drawing.Size(132, 22);
            this.cmnDelete.Text = "Xóa";
            this.cmnDelete.Click += new System.EventHandler(this.cmnDelete_Click);
            // 
            // txtNguoilap
            // 
            this.txtNguoilap.Location = new System.Drawing.Point(133, 78);
            this.txtNguoilap.Name = "txtNguoilap";
            this.txtNguoilap.ReadOnly = true;
            this.txtNguoilap.Size = new System.Drawing.Size(261, 22);
            this.txtNguoilap.TabIndex = 22;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(10, 81);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 15);
            this.label16.TabIndex = 21;
            this.label16.Text = "Người lập";
            // 
            // txtNgaythang
            // 
            this.txtNgaythang.Location = new System.Drawing.Point(392, 53);
            this.txtNgaythang.Name = "txtNgaythang";
            this.txtNgaythang.ReadOnly = true;
            this.txtNgaythang.Size = new System.Drawing.Size(156, 22);
            this.txtNgaythang.TabIndex = 20;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(306, 56);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 15);
            this.label15.TabIndex = 19;
            this.label15.Text = "Ngày tháng";
            // 
            // txtimportorderid
            // 
            this.txtimportorderid.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtimportorderid.Location = new System.Drawing.Point(133, 53);
            this.txtimportorderid.Name = "txtimportorderid";
            this.txtimportorderid.ReadOnly = true;
            this.txtimportorderid.Size = new System.Drawing.Size(167, 22);
            this.txtimportorderid.TabIndex = 18;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(10, 56);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(102, 15);
            this.label14.TabIndex = 17;
            this.label14.Text = "Mã hóa đơn nhập";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(454, 391);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 15);
            this.label7.TabIndex = 13;
            this.label7.Text = "Tổng cộng:";
            // 
            // btncancelncreatenew
            // 
            this.btncancelncreatenew.Image = global::CASALE.Properties.Resources.replace2;
            this.btncancelncreatenew.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btncancelncreatenew.Location = new System.Drawing.Point(153, 387);
            this.btncancelncreatenew.Name = "btncancelncreatenew";
            this.btncancelncreatenew.Size = new System.Drawing.Size(125, 23);
            this.btncancelncreatenew.TabIndex = 11;
            this.btncancelncreatenew.Text = "Hủy && Làm lại";
            this.btncancelncreatenew.UseVisualStyleBackColor = true;
            this.btncancelncreatenew.Click += new System.EventHandler(this.btncancelncreatenew_Click);
            // 
            // btnsaveimportorder
            // 
            this.btnsaveimportorder.Image = global::CASALE.Properties.Resources.disk_blue;
            this.btnsaveimportorder.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnsaveimportorder.Location = new System.Drawing.Point(12, 387);
            this.btnsaveimportorder.Name = "btnsaveimportorder";
            this.btnsaveimportorder.Size = new System.Drawing.Size(140, 23);
            this.btnsaveimportorder.TabIndex = 10;
            this.btnsaveimportorder.Text = "Lưu thông tin";
            this.btnsaveimportorder.UseVisualStyleBackColor = true;
            this.btnsaveimportorder.Click += new System.EventHandler(this.btnsaveimportorder_Click);
            // 
            // frmNhaphang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(758, 509);
            this.Controls.Add(this.pnImportDetail);
            this.Controls.Add(this.lblTotalImport);
            this.Controls.Add(this.lblTonggiatri);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lvListImport);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "frmNhaphang";
            this.Text = "Nhập hàng";
            this.Load += new System.EventHandler(this.frmNhaphang_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.lvListImport, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.label12, 0);
            this.Controls.SetChildIndex(this.lblTonggiatri, 0);
            this.Controls.SetChildIndex(this.lblTotalImport, 0);
            this.Controls.SetChildIndex(this.pnImportDetail, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.cmnImport.ResumeLayout(false);
            this.pnImportDetail.ResumeLayout(false);
            this.pnImportDetail.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSoluong)).EndInit();
            this.cmnUpdateDelete.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmborderlistpages;
        private System.Windows.Forms.ComboBox cmborderlistitemsperpage;
        private System.Windows.Forms.Button btnExportExcel;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtkeyword;
        private System.Windows.Forms.Button btnAddImport;
        private System.Windows.Forms.ListView lvListImport;
        private System.Windows.Forms.ColumnHeader ID;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Label lblTotalImport;
        private System.Windows.Forms.Label lblTonggiatri;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel pnImportDetail;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblmoneyunit;
        private System.Windows.Forms.Label lblTongtien;
        private System.Windows.Forms.Button btncloseorderdetail;
        private System.Windows.Forms.Label lblmsg;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtunit;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txttax;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtcartdetailproductcode;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDongia;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown nudSoluong;
        private System.Windows.Forms.TextBox txtItemname;
        private System.Windows.Forms.Button btnNhap;
        private System.Windows.Forms.ListView lvImportDetails;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.TextBox txtNguoilap;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtNgaythang;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtimportorderid;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btncancelncreatenew;
        private System.Windows.Forms.Button btnsaveimportorder;
        private System.Windows.Forms.ContextMenuStrip cmnImport;
        private System.Windows.Forms.ToolStripMenuItem cmnImportDetail;
        private System.Windows.Forms.ToolStripMenuItem cmnDeleteImport;
        private System.Windows.Forms.Label lbltongt1;
        private System.Windows.Forms.ContextMenuStrip cmnUpdateDelete;
        private System.Windows.Forms.ToolStripMenuItem cmnUpdate;
        private System.Windows.Forms.ToolStripMenuItem cmnDelete;
        private System.Windows.Forms.ListView lvicd;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader key;
        private System.Windows.Forms.ColumnHeader lvtitle;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader cuont;
        private System.Windows.Forms.ColumnHeader columnHeader18;
    }
}