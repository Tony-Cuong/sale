﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CASALE.Class;
using LCProductCartUtiliti;
using LCMultiUtilities;
using LCMembersUtiliti;
using OfficeUtilities;

namespace CASALE
{
    public partial class frmNhaphang : templates
    {
        int curpage = 1;
        int inumofitems = 0;

        protected bool binsertupdate = false;
        protected int iIMEXid = -1;
        protected int iProductId = -1;
        bool fg = false;
        bool isloaddata = false;
        string iiid = "";
        public frmNhaphang()
        {
            InitializeComponent();
        }

        private void frmNhaphang_Load(object sender, EventArgs e)
        {
            isloaddata = true;

            DataTable dtitemsperpages = Common.ItemsPerPage;
            cmborderlistitemsperpage.DataSource = dtitemsperpages;
            cmborderlistitemsperpage.DisplayMember = "Text";
            cmborderlistitemsperpage.ValueMember = "Value";

            LoadImportOrderList();
            isloaddata = false;
            //lblmoneyunit.Text = Common.MoneyUnit;
        }
        string UserName(string senderparams)
        {
            string[] prs = senderparams.Split('|');
            if (prs.Length > 1)
            {
                return prs[1];
            }
            return prs[0];
        }
        private void LoadImportOrderList()
        {
            if (inumofitems < 1)
            {
                inumofitems = ImportExport.sale_objects_importexport_getiolist_count(1, -1, txtkeyword.Text,
                    "", Common.ConnectionString);
                // bind dữ liệu vào combobox pages.
                int pages = 1;
                if (inumofitems % Convert.ToInt32(cmborderlistitemsperpage.SelectedValue) == 0)
                {
                    pages = inumofitems / Convert.ToInt32(cmborderlistitemsperpage.SelectedValue);
                }
                else
                {
                    pages = inumofitems / Convert.ToInt32(cmborderlistitemsperpage.SelectedValue) + 1;
                }
                cmborderlistpages.Items.Clear();

                for (int i = 1; i <= pages; i++)
                {
                    cmborderlistpages.Items.Add(i);
                }
                cmborderlistpages.Text = "1";
            }


            curpage = Convert.ToInt32(cmborderlistpages.Text) - 1;

            lvListImport.Items.Clear();
            DataTable dt = ImportExport.sale_objects_importexport_getiolist(1, -1, txtkeyword.Text, "", "",
                curpage, Convert.ToInt32(cmborderlistitemsperpage.SelectedValue),
                Common.ConnectionString);
            if (dt.Rows.Count > 0)
            {
                double ftonggiatri = 0;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ListViewItem lvi = new ListViewItem(dt.Rows[i]["isoixid"].ToString());
                    lvi.SubItems.Add((i + 1).ToString());
                    lvi.SubItems.Add(dt.Rows[i]["vcode"].ToString());
                    lvi.SubItems.Add(dt.Rows[i]["ddatetime"].ToString());
                    lvi.SubItems.Add(dt.Rows[i]["iproquantity"].ToString());
                    lvi.SubItems.Add(UserName(dt.Rows[i]["vsenderparams"].ToString()));
                    lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dt.Rows[i]["ftotal"].ToString()));
                    ftonggiatri += Convert.ToDouble(dt.Rows[i]["ftotal"]);
                    lvListImport.Items.Add(lvi);
                }
                lblTotalImport.Text = LCUtiliti.ConvertNumber.FomatPrice(lvListImport.Items.Count.ToString());
                lblTonggiatri.Text = LCUtiliti.ConvertNumber.FomatPrice(ftonggiatri.ToString());
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            LoadImportOrderList();
        }
        private void resetData()
        {

            txtcartdetailproductcode.Text = "";
            txtDongia.Text = "";
            txtItemname.Text = "";
            nudSoluong.ResetText();
            lvImportDetails.Items.Clear();
            txtimportorderid.Text = Common.ImportCode;

        }
        private void btnAddImport_Click(object sender, EventArgs e)
        {
            resetData();
            txtNgaythang.Text = DateTime.Now.ToString();
            txtNguoilap.Text = Common.UserFullName + " (" + Common.UserName + ")";
            pnImportDetail.Visible = true;
            btnsaveimportorder.Enabled = true;
            btncancelncreatenew.Enabled = true;
            btnNhap.Enabled = true;
        }
        #region "ORDER"
        DataTable dtorderdetails = new DataTable();
        void OrderCreateColumns()
        {
            if (dtorderdetails.Columns.Count < 1)
            {
                dtorderdetails.Columns.Add("ID", typeof(Int32));
                dtorderdetails.Columns.Add("Code", typeof(String));
                dtorderdetails.Columns.Add("Name", typeof(String));
                dtorderdetails.Columns.Add("Unit", typeof(String));
                dtorderdetails.Columns.Add("Price", typeof(Double));
                dtorderdetails.Columns.Add("Quantity", typeof(Int32));
                dtorderdetails.Columns.Add("Tax", typeof(Double));
            }
        }
        void OrderAddProduct(int iid, string sproductcode, string productname, string productunit, string fprice, int iquantity, double ftax)
        {
            if (iid > -1 && sproductcode.Length > 0)
            {
                OrderCreateColumns();

                if (dtorderdetails.Select("ID=" + iid.ToString()).Length > 0)
                {
                    // tôn tại sản phẩm trong cart rồi
                    // cập nhật số lượng
                    for (int i = 0; i < dtorderdetails.Rows.Count; i++)
                    {
                        if (Convert.ToInt32(dtorderdetails.Rows[i]["ID"]) == iid)
                        {
                            dtorderdetails.Rows[i]["Quantity"] = Convert.ToInt32(dtorderdetails.Rows[i]["Quantity"]) + iquantity;
                            break;
                        }
                    }
                }
                else
                {
                    // thêm mới vào dtorderdetails
                    DataRow dr = dtorderdetails.NewRow();
                    dr["ID"] = iid;
                    dr["Code"] = sproductcode;
                    dr["Name"] = productname;
                    dr["Unit"] = productunit;
                    dr["Price"] = fprice;
                    dr["Quantity"] = iquantity;
                    dr["Tax"] = ftax;

                    dtorderdetails.Rows.Add(dr);
                }
                OrderLoadCartDetails();
            }
        }
        void OrderLoadCartDetails()
        {
            double ftotal = 0;
            lvImportDetails.Items.Clear();
            // load tu dtorderdetails vào listview.
            //DataTable tb = new DataTable();
            for (int i = 0; i < dtorderdetails.Rows.Count; i++)
            {
                ListViewItem lvi = new ListViewItem(dtorderdetails.Rows[i]["ID"].ToString());
                lvi.SubItems.Add((i + 1).ToString());
                lvi.SubItems.Add(dtorderdetails.Rows[i]["Code"].ToString());
                lvi.SubItems.Add(dtorderdetails.Rows[i]["Name"].ToString());
                lvi.SubItems.Add(dtorderdetails.Rows[i]["Unit"].ToString());
                lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dtorderdetails.Rows[i]["Price"].ToString()));
                lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dtorderdetails.Rows[i]["Quantity"].ToString()));
                lvi.SubItems.Add(dtorderdetails.Rows[i]["Tax"].ToString());

                double itemtotal =
                    (Convert.ToDouble(dtorderdetails.Rows[i]["Price"].ToString()) * Convert.ToInt32(dtorderdetails.Rows[i]["Quantity"].ToString())) +
                    (Convert.ToDouble(dtorderdetails.Rows[i]["Price"].ToString()) * Convert.ToInt32(dtorderdetails.Rows[i]["Quantity"].ToString()))
                    * Convert.ToDouble(dtorderdetails.Rows[i]["Tax"]) / 100;

                lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(itemtotal.ToString()));
                lvImportDetails.Items.Add(lvi);
                ftotal += itemtotal;
            }
            lblTongtien.Text = ftotal.ToString();
            lbltongt1.Text = LCUtiliti.ConvertNumber.FomatPrice(ftotal.ToString());
        }
        /// <summary>
        /// Xóa sản phẩm khỏi cart.
        /// </summary>
        /// <param name="iproductid"></param>
        void OrderDeleteProductFromCart(int iproductid)
        {
            for (int i = dtorderdetails.Rows.Count - 1; i > -1; i--)
            {
                if (Convert.ToInt32(dtorderdetails.Rows[i]["ID"]) == iproductid)
                {
                    dtorderdetails.Rows.RemoveAt(i);
                    break;
                }
            }
            OrderLoadCartDetails();
        }
        #endregion
        #region "Cart Detail"

        void LoadProduct()
        {
            this.txtItemname.Text = "";
            string strmasanpham = txtcartdetailproductcode.Text;
            string[] searchfield = { "vkey", "vtitle" };
            DataTable tb = mssql_multicates_multidb_items.dicts_cate_items_incate_v3(-1,
               Common.capp_product_code, Common.vietnames, -1,
               false, false, false, "", 1, strmasanpham, searchfield,
               false, "", "", Common.ConnectionString);

            if (tb.Rows.Count > 0)
            {
                txtcartdetailproductcode.Text = tb.Rows[0]["vkey"].ToString();
                txtItemname.Text = tb.Rows[0]["vtitle"].ToString();
                txtDongia.Text = tb.Rows[0]["vauthor"].ToString();
                txttax.Text = tb.Rows[0]["vurl"].ToString();
                txtunit.Text = tb.Rows[0]["vunit"].ToString();
                this.iProductId = Convert.ToInt32(tb.Rows[0]["iid"]);
            }
        }

        #endregion

        private void btnNhap_Click_1(object sender, EventArgs e)
        {
            if (fg == true)
            {
                string[] prm = iiid.Split('|');

                ImportExportDetail.sale_objects_imexdetails_update(Convert.ToInt32(prm[0]), Convert.ToInt32(prm[1]),
                    Convert.ToInt32(prm[2]), Convert.ToDouble(txtDongia.Text), Convert.ToInt32(nudSoluong.Value), Convert.ToDouble(txttax.Text), Common.ConnectionString);
                fg = false;
                btnNhap.Text = "Nhập hàng";
                txtcartdetailproductcode.Text = "";
                txtItemname.Text = "";
                txtDongia.Text = "";
                nudSoluong.Value = 1;
                txtcartdetailproductcode.Focus();
                getdetail();
            }
            else
            {
                string _codeproduct = txtcartdetailproductcode.Text;
                string sdongia = txtDongia.Text;
                string ssoluong = nudSoluong.Value.ToString();

                OrderAddProduct(iProductId, _codeproduct, txtItemname.Text, txtunit.Text, sdongia,
                    Convert.ToInt32(nudSoluong.Value), Convert.ToDouble(txttax.Text));
                txtcartdetailproductcode.Text = "";
                txtItemname.Text = "";
                txtDongia.Text = "";
                nudSoluong.Value = 1;
                txtcartdetailproductcode.Focus();
            }
        }
        void getdetail()
        {
            btnNhap.Enabled = false;
            string isoixid = lvListImport.SelectedItems[0].Text.ToString();
            DataTable dt = ImportExport.sale_objects_importexport_getdetailbyid(Convert.ToInt32(isoixid), Common.ConnectionString);

            if (dt.Rows.Count > 0)
            {
                txtimportorderid.Text = dt.Rows[0]["vcode"].ToString();
                txtNgaythang.Text = dt.Rows[0]["ddatetime"].ToString();
                string[] senderprms = dt.Rows[0]["vsenderparams"].ToString().Split('|');
                if (senderprms.Length > 1)
                {
                    DataTable dtmemberdetail = Members.users_getdetailbyid(senderprms[0], Common.ConnectionString);
                    {
                        txtNguoilap.Text = dtmemberdetail.Rows[0]["vlname"].ToString() + " " + dtmemberdetail.Rows[0]["vfname"].ToString() + " (" + dtmemberdetail.Rows[0]["vuserun"] + ")";
                    }
                }
                else
                {
                    txtNguoilap.Text = dt.Rows[0]["vsenderparams"].ToString();
                }
            }
            lvImportDetails.Items.Clear();
            DataTable dt1 = ImportExportDetail.sale_objects_imexdetails_getdetaillistby_ioid(Convert.ToInt32(isoixid), Common.ConnectionString);
            if (dt1.Rows.Count > 0)
            {
                double ftotal = 0;
                for (int i = 0; i < dt1.Rows.Count; i++)
                {
                    ListViewItem lvi = new ListViewItem(dt1.Rows[i]["isoixdid"].ToString() + "|" + dt1.Rows[i]["isoixid"].ToString() + "|" + dt1.Rows[i]["iproductid"].ToString());

                    lvi.SubItems.Add((i + 1).ToString());

                    lvi.SubItems.Add(dt1.Rows[i]["vproductkey"].ToString());
                    lvi.SubItems.Add(dt1.Rows[i]["vproductname"].ToString());
                    lvi.SubItems.Add(dt1.Rows[i]["vproductunit"].ToString());
                    lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dt1.Rows[i]["fprice"].ToString()));
                    lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dt1.Rows[i]["iquantity"].ToString()));

                    lvi.SubItems.Add(dt1.Rows[i]["ftaxpercent"].ToString());
                    double itemtotal =
                    (Convert.ToDouble(dt1.Rows[i]["fprice"].ToString()) * Convert.ToInt32(dt1.Rows[i]["iquantity"])) +
                    (Convert.ToDouble(dt1.Rows[i]["fprice"].ToString()) * Convert.ToInt32(dt1.Rows[i]["iquantity"]))
                    * Convert.ToDouble(dt1.Rows[i]["ftaxpercent"]) / 100;
                    ftotal += itemtotal;

                    lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(itemtotal.ToString()));
                    lvImportDetails.Items.Add(lvi);
                }
                lblTongtien.Text = LCUtiliti.ConvertNumber.FomatPrice(ftotal.ToString());
                btnsaveimportorder.Enabled = false;
                btncancelncreatenew.Enabled = false;
            }
            pnImportDetail.Visible = true;
        }

        private void cmnDeleteImport_Click(object sender, EventArgs e)
        {
            if (lvListImport.Items.Count > 0)
            {
                if (lvListImport.SelectedItems.Count > 0)
                {
                    int orderid = Convert.ToInt32(lvListImport.SelectedItems[0].SubItems[0].Text);
                    if (MessageBox.Show("Xóa đơn hàng đang chọn? Việc xóa sẽ dẫn đến dữ liệu sản phẩm không đúng thực tế. Nhân Yes để thực hiện", "Nhập hàng", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        // xóa tất cả các sản trong đơn hàng

                        // cập nhật số lượng trong sản phẩm.
                        DataTable dt = ImportExportDetail.sale_objects_imexdetails_getdetaillistby_ioid(orderid, Common.ConnectionString);
                        if (dt.Rows.Count > 0)
                        {
                            //double ftotal = 0;
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                // update lại số lượng
                                mssql_multicates_multidb_items.dicts_items_update_custom_update(
                                dt.Rows[i]["iproductid"].ToString(),
                                "iquantity=iquantity - " + dt.Rows[i]["iquantity"].ToString(),
                                Common.ConnectionString);
                                // sau đó xóa
                                ImportExportDetail.sale_objects_imexdetails_delete(
                                    Convert.ToInt32(dt.Rows[i]["isoixdid"]),
                                    Common.ConnectionString);
                            }
                        }

                        // xóa đơn hàng
                        ImportExport.sale_objects_importexport_delete(
                            orderid, Common.ConnectionString);
                        LoadImportOrderList();
                    }
                }
            }
        }

        private void btnsaveimportorder_Click(object sender, EventArgs e)
        {

            //1.insert vao bang import/export
            int isoixid = ImportExport.sale_objects_importexport_insert(txtimportorderid.Text, "", 1, -1, -1, float.Parse(lblTongtien.Text), -1, DateTime.Now, Common.UserId.ToString() + "|" + Common.UserName, "", 1, Common.ConnectionString);
            int numofquantity = 0;
            //2.insert vao bang import/export detail
            if (dtorderdetails.Rows.Count > 0)
            {
                for (int i = 0; i < dtorderdetails.Rows.Count; i++)
                {

                    int iproductid = Convert.ToInt32(dtorderdetails.Rows[i]["ID"]);
                    double fprice = Convert.ToDouble(dtorderdetails.Rows[i]["Price"]);
                    int iquantity = Convert.ToInt32(Convert.ToDouble(dtorderdetails.Rows[i]["Quantity"]));
                    numofquantity += iquantity;
                    ImportExportDetail.sale_objects_imexdetails_insert(
                        isoixid, iproductid, fprice, iquantity, Convert.ToDouble(dtorderdetails.Rows[i]["Tax"]),
                        dtorderdetails.Rows[i]["Code"].ToString(),
                        dtorderdetails.Rows[i]["Name"].ToString(),
                        dtorderdetails.Rows[i]["Unit"].ToString(), 0, "",
                        Common.ConnectionString);
                    // thêm vào số lượng sản phẩm có trong kho.
                    mssql_multicates_multidb_items.dicts_items_update_custom_update(
                        iproductid.ToString(),
                        "iquantity=iquantity + " + iquantity.ToString(),
                        Common.ConnectionString);

                }
                dtorderdetails.Rows.Clear();
            }
            ImportExport.sale_objects_importexport_updateimportquantity(isoixid, numofquantity, Common.ConnectionString);
            LoadImportOrderList();
            pnImportDetail.Visible = false;
        }

        private void btncancelncreatenew_Click(object sender, EventArgs e)
        {
            resetData();
        }

        private void btncloseorderdetail_Click(object sender, EventArgs e)
        {
            pnImportDetail.Visible = false;
        }

        private void txtcartdetailproductcode_KeyUp(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                LoadProduct();
                nudSoluong.Focus();
                lvicd.Visible = false;
            }
        }

        private void txtcartdetailproductcode_Leave(object sender, EventArgs e)
        {
            //if (txtcartdetailproductcode.Text.Trim().Length > 0)
            //{
            //    if (txtItemname.Text.Length < 1)
            //    {
            //        string[] arrsearchfields = { "vkey" };
            //        DataTable dt = mssql_multicates_multidb_items.
            //                dicts_cate_items_incate_v3(
            //                -1, Common.capp_dc,
            //                "-1", -1, true, false, false, "",
            //                1, txtcartdetailproductcode.Text,
            //                arrsearchfields, false, "", "", Common.ConnectionString);
            //        if (dt.Rows.Count > 0)
            //        {
            //            txtDongia.Text = dt.Rows[0]["vauthor"].ToString();
            //            txtunit.Text = dt.Rows[0]["vurl"].ToString();
            //            txtItemname.Text = dt.Rows[0]["vtitle"].ToString();
            //            icartdetailproductid = Convert.ToInt32(dt.Rows[0]["iid"].ToString());
            //            txtQuantity.Focus();
            //        }
            //        else
            //        {
            //            txtcartdetailproductcode.Focus();
            //        }
            //    }
            //}
        }

        private void txtItemname_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                LoadProduct();
                txtDongia.Focus();
            }
        }

        private void cmnImportDetail_Click(object sender, EventArgs e)
        {
            getdetail();
        }

        private void btnExportExcel_Click(object sender, EventArgs e)
        {
            ExcelUtilities.ExportListViewToExcel(ref lvListImport);
        }

        private void cmnDelete_Click(object sender, EventArgs e)
        {
            OrderDeleteProductFromCart(Convert.ToInt32(lvImportDetails.SelectedItems[0].Text.ToString())); 
        }
        private void loaddata(string str)
        {
            lvicd.Items.Clear();

            string[] arrsearchfields = { "vkey" };

            DataTable dt = mssql_multicates_multidb_items.
                dicts_cate_items_incate_v3(
                -1, Common.capp_product_code,
                Common.vietnames, -1, true, false, false, " di.vkey LIKE N'%" + str + "%'",
                1, txtcartdetailproductcode.Text,
                arrsearchfields, false, "", "", Common.ConnectionString);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ListViewItem lvi = new ListViewItem(dt.Rows[i]["iid"].ToString());
                    lvi.SubItems.Add(dt.Rows[i]["vkey"].ToString());
                    lvi.SubItems.Add(dt.Rows[i]["vtitle"].ToString());
                    lvi.SubItems.Add(dt.Rows[i]["vunit"].ToString());
                    lvi.SubItems.Add(dt.Rows[i]["vfimg"].ToString());
                    lvi.SubItems.Add(dt.Rows[i]["vauthor"].ToString());
                    lvicd.Items.Add(lvi);
                }
            }
            else
            {
                lvicd.Visible = false;
            }

        }
        private int lastItm = 0;
        private void txtcartdetailproductcode_TextChanged(object sender, EventArgs e)
        {
            if (txtcartdetailproductcode.Text.Trim().Equals(""))
            {
                lvicd.Visible = false;
                return;
            }
            else
            {
                lvicd.Visible = true;
                loaddata(txtcartdetailproductcode.Text.Trim());

                //if (lvicd.Items.Count>0)
                //{
                bool find = false;
                for (int i = 0; i < lvicd.Items.Count; i++)
                {
                    for (int lst12 = lastItm; lst12 < lvicd.Items.Count; lst12++)
                    {
                        if (lvicd.Items[lst12].SubItems[1].Text.IndexOf(txtcartdetailproductcode.Text) > -1 | lvicd.Items[lst12].SubItems[1].Text.ToUpper().IndexOf(txtcartdetailproductcode.Text.ToUpper()) > -1)
                        {
                            lvicd.TopItem = lvicd.Items[lst12];
                            if (lastItm > 0) lvicd.Items[lastItm - 1].BackColor = Color.CadetBlue;
                            lvicd.Items[lst12].BackColor = Color.CadetBlue;
                            lvicd.Items[lst12].Selected = true;
                            lastItm = lst12 + 1;
                            find = true;
                            break;
                        }
                    }
                    if (find)
                        break;
                    lvicd.Visible = false;
                    //txtQuantity.Focus();
                }
                if (lastItm > 0) lvicd.Items[lastItm - 1].BackColor = Color.CadetBlue;
                lastItm = 0;
            }
        }

        private void lvicd_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (lvicd.Items.Count > 0)
                {
                    for (int i = 0; i < lvicd.Items.Count; i++)
                    {
                        if (lvicd.Items[i].Selected)
                        {
                            txtcartdetailproductcode.Text = lvicd.Items[i].SubItems[1].Text;
                            txtcartdetailproductcode.Focus();
                            lvicd.Visible = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ;
            }
        }

        private void lvicd_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                if (lvicd.Items.Count > 0)
                {
                    for (int i = 0; i < lvicd.Items.Count; i++)
                    {
                        if (lvicd.Items[i].Selected)
                        {
                            txtcartdetailproductcode.Text = lvicd.Items[i].SubItems[1].Text;

                            string[] arrsearchfields = { "vkey" };
                            DataTable dt = mssql_multicates_multidb_items.
                                dicts_cate_items_incate_v3(
                                -1, Common.capp_product_code,
                                Common.vietnames, -1, true, false, false, "",
                                1, txtcartdetailproductcode.Text,
                                arrsearchfields, false, "", "", Common.ConnectionString);
                            if (dt.Rows.Count > 0)
                            {
                                txtcartdetailproductcode.Text = dt.Rows[0]["vkey"].ToString();
                                txtItemname.Text = dt.Rows[0]["vtitle"].ToString();
                                txtDongia.Text = dt.Rows[0]["vauthor"].ToString();
                                txttax.Text = dt.Rows[0]["vurl"].ToString();
                                txtunit.Text = dt.Rows[0]["vunit"].ToString();
                                this.iProductId = Convert.ToInt32(dt.Rows[0]["iid"]); 
                                nudSoluong.Focus();
                            }
                            lvicd.Visible = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ;
            }
        }

        private void nudSoluong_KeyUp(object sender, KeyEventArgs e)
        {
            btnNhap_Click_1(sender, e);
        }

        private void lvImportDetails_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Delete)
            {
                OrderDeleteProductFromCart(Convert.ToInt32(lvImportDetails.SelectedItems[0].Text.ToString())); 
            }
        }
        
    }
}
