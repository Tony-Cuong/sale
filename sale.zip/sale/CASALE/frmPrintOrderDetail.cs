﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LCProductCartUtiliti;
using CASALE.Class;
using LCUtiliti;

namespace CASALE
{
    public partial class frmPrintOrderDetail : templates
    {
        public int iOrderDetailId = -1;
        DataTable dtorder = new DataTable();// chứa thông tin đơn hàng
        DataTable dtorderdetail = new DataTable(); // chứa chi tiết đơn hàng
        
        public frmPrintOrderDetail()
        {
            InitializeComponent();
        }

        private void frmPrintOrderDetail_Load(object sender, EventArgs e)
        {
            try
            {
            dtorder = Cart.p_carts_getdetailbyid(iOrderDetailId.ToString(), Common.ConnectionString);
            dtorderdetail = Cart.p_cartdetails_getdetailby_cartid(iOrderDetailId, Common.ConnectionString);
            printDocument1.Print();

            }
            catch (Exception ex)
            {
                MessageBox.Show("File bạn không thể ghi vào vì đang được sử dụng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            printDocument1.Print(); 
        }
        int count = 0;
        float h = 0.0f;
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;
            float fcol1 = 10;
            float fcol2 = 165;
            float fcol3 = 185;
            float fcol4 = 130;
            Rectangle rFull = new Rectangle(
                e.PageBounds.Left - 10,
                e.PageBounds.Top,
                e.PageBounds.Right,
                e.PageBounds.Bottom);

            if (Common.PrintOrderType.Equals("0")) // in siêu thị
            {
                #region "Print SupperMarket Order"
                float y = 0;
                Font titleFont = new Font("Tahoma", 8, System.Drawing.GraphicsUnit.Point);
                Font font7 = new Font("Tahoma", 7, System.Drawing.GraphicsUnit.Point);

                string companyname = Common.CompanyName;
                g.DrawString(companyname, titleFont, Brushes.Black, fcol1, y);
                y += titleFont.Height + 3;
                g.DrawString("MST: " + Common.Taxcode, font7, Brushes.Black, fcol1, y);
                y += titleFont.Height + 2;

                string title = Common.PrintTitle;
                g.DrawString(title + " [" + dtorder.Rows[0]["vcode"].ToString() + "]", titleFont, Brushes.Black, fcol1, y);

                //g.DrawString(" ["+Common.Taxcode.ToString()+"]", titleFont, Brushes.Black, 145, y);
                y += titleFont.Height;
                string time = DateTime.Now.ToString("dd/MM/yyyy HH:mm");
                g.DrawString("Thời gian: " + time + "", font7, Brushes.Black, fcol1, y);

                y += titleFont.Height;
                g.DrawString("Khách hàng: " + dtorder.Rows[0]["vcname"].ToString(), titleFont, Brushes.Black, 10, y);
                y += titleFont.Height;
                g.DrawString("Địa chỉ: " + Common.frmbanhang.txtcustomeraddress.Text, titleFont, Brushes.Black, 10, y);

                y += titleFont.Height;
                g.DrawString("Điện thoại: " + Common.frmbanhang.txtcustomerphone.Text, titleFont, Brushes.Black, 10, y);
                //g.DrawString("Email: " + Common.frmbanhang.txtcustomeremail.Text, titleFont, Brushes.Black, fcol4, y);

                y += titleFont.Height + 10;


                // HEADER
                Font headerFont = new Font("Tahoma", 8, FontStyle.Underline, GraphicsUnit.Point);
                g.DrawString("SẢN PHẨM", headerFont, Brushes.Black, fcol1, y);
                g.DrawString("Đ.vị", headerFont, Brushes.Black, fcol4 + 10, y);
                g.DrawString("SL", headerFont, Brushes.Black, fcol2, y);
                g.DrawString("T.TIỀN", headerFont, Brushes.Black, fcol3, y);

                y += headerFont.Height + 5;

                Font rowFont = new Font("Tahoma", 8, System.Drawing.GraphicsUnit.Point);

                double carttotal = 0;
                double taxtotal = 0;
                for (int i = 0; i < dtorderdetail.Rows.Count; i++)
                {
                    double ftotal = Convert.ToDouble(dtorderdetail.Rows[i]["vprice"]) * Convert.ToDouble(dtorderdetail.Rows[i]["inumber"]);

                    taxtotal += ftotal * (Convert.ToDouble(dtorderdetail.Rows[i]["ftaxpercent"]) / 100);

                    carttotal += ftotal;

                    g.DrawString(StringUtilities.CutLeft(dtorderdetail.Rows[i]["vproductname"].ToString(), 150, 25), rowFont, Brushes.Black, fcol1, y);
                    g.DrawString(dtorderdetail.Rows[i]["vproductunit"].ToString(), rowFont, Brushes.Black, fcol4 + 10, y);
                    g.DrawString(dtorderdetail.Rows[i]["inumber"].ToString(), rowFont, Brushes.Black, fcol2 + 5, y);
                    g.DrawString(LCUtiliti.ConvertNumber.FomatPrice(ftotal.ToString()), rowFont, Brushes.Black, fcol3, y);

                    y += rowFont.Height + 1;
                    count++;
                }

                // in đường kẻ
                y += 6;
                g.DrawLine(new Pen(Brushes.Black, 0.5f), fcol1, y, e.PageBounds.Width - fcol1 - 5, y);
                y += 6;
                // Cộng
                Font footerFont = new Font("Tahoma", 8, FontStyle.Regular, GraphicsUnit.Point);
                g.DrawString("Cộng " + "(" + Common.MoneyUnit + "):", footerFont, Brushes.Black, fcol1, y);
                g.DrawString(LCUtiliti.ConvertNumber.FomatPrice(carttotal.ToString()), footerFont, Brushes.Black, fcol3, y);
                y += footerFont.Height + 3;
                // thuế
                g.DrawString(Common.PrintTax, footerFont, Brushes.Black, fcol1, y);
                g.DrawString(LCUtiliti.ConvertNumber.FomatPrice(taxtotal.ToString()), footerFont, Brushes.Black, fcol3, y);
                y += footerFont.Height + 3;
                // tổng cộng
                g.DrawString("Tổng cộng " + "(" + Common.MoneyUnit + "):", footerFont, Brushes.Black, fcol1, y);
                g.DrawString(LCUtiliti.ConvertNumber.FomatPrice((carttotal + taxtotal).ToString()), footerFont, Brushes.Black, fcol3, y);
                //y += footerFont.Height + 3;
                //g.DrawString("Tổng trọng lượng: " , footerFont, Brushes.Black, fcol1, y);

                y += footerFont.Height + 5;
                g.DrawString("N.V bán hàng: " + Common.UserFullName, footerFont, Brushes.Black, fcol1, y);
                y += footerFont.Height + 12;

                StringFormat footersf = new StringFormat();
                footersf.Alignment = StringAlignment.Center;

                g.DrawString(Common.PrintThanks, font7, Brushes.Black, fcol1, y);
                y += footerFont.Height + 3;

                if (count < dtorderdetail.Rows.Count)
                    e.HasMorePages = true;
                else
                {
                    e.HasMorePages = false;
                    this.Close();
                }
                // in mã vạch của mã đơn hàng ra đây.
                #endregion
            }
            else
            {
                #region header
                Font titleFont = new Font("Tahoma", 9, System.Drawing.GraphicsUnit.Point);
                Font titleFont2 = new Font("Tahoma", 10, System.Drawing.GraphicsUnit.Point);
                Font titleFont3italic = new Font("Tahoma", 8, System.Drawing.GraphicsUnit.Point);

                // load order ImportExportDetail.

                StringFormat sf = new StringFormat();
                float x = 25;
                float y = 25;
                g.DrawString(Common.CompanyName.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString(Common.CompanyAddress.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString("Điện thoại: " + Common.CompanyPhone.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);

                sf.Alignment = StringAlignment.Center;
                //float y1 = 32;
                y += titleFont.Height + 5;
                Font titleFont1 = new Font("Tahoma", 16, System.Drawing.GraphicsUnit.Point);
                g.DrawString(Common.PrintTitle , titleFont1, Brushes.Black, new RectangleF(3, y, e.PageBounds.Width - 20, 32), sf);

                y += titleFont1.Height + 2;

                if (dtorder.Rows.Count > 0)
                {

                    g.DrawString("(Mã hóa đơn:" + dtorder.Rows[0]["vcode"].ToString().ToUpper() + ")",
                        titleFont2, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 20, 32), sf);

                    sf.Alignment = StringAlignment.Near;
                    y += titleFont2.Height;
                    g.DrawString("Thời gian:" + Convert.ToDateTime(dtorder.Rows[0]["ddatetime"]).ToString("dd-MM-yyyy"),
                        titleFont2, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 20, 32), sf);

                    y += titleFont2.Height;
                    g.DrawString("Khách hàng:" + dtorder.Rows[0]["vcname"].ToString(),
                        titleFont2, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 20, 32), sf);
                    y += titleFont2.Height;
                    g.DrawString("Địa chỉ:" + dtorder.Rows[0]["vcaddress"].ToString(),
                        titleFont2, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 20, 32), sf);
                    y += titleFont2.Height;
                    g.DrawString("Điện thoại:" + dtorder.Rows[0]["vcphone"].ToString(),
                        titleFont2, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 20, 32), sf);
                    //g.DrawString("Email:" + dtorder.Rows[0]["vcemail"].ToString(),
                        //titleFont2, Brushes.Black, new RectangleF(250, y, e.PageBounds.Width - 270, 32), sf);

                    y += titleFont2.Height + 5;
                    sf.Alignment = StringAlignment.Near;
                    g.DrawString("Danh mục sản phẩm",
                       titleFont2, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 20, 32), sf);
                    y += titleFont2.Height + 1;
                }
                #endregion
                float colxpadding = 3;
                float colypadding = 3;

                #region in tieu de
                for (int i = 0; i < 1; i++)
                {
                    x = 20;
                    float h = 25;
                    float w = 0;
                    // draw table
                    for (int j = 0; j < 7; j++)
                    {
                        if (j > 0) x += w;

                        switch (j)
                        {
                            case 0:
                                w = 42;
                                break;
                            case 1:
                                w = 112;
                                break;
                            case 2:
                                w = 290;
                                break;
                            case 3:
                                w = 60;
                                break;
                            case 4:
                                w = 89;
                                break;
                            case 5:
                                w = 50;
                                break;
                            //case 6:
                            //    w = 60;
                            //    break;
                            case 6:
                                w = 122;
                                break;
                        }

                        Rectangle rect = new Rectangle(Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                        g.DrawRectangle(new Pen(Brushes.Black), rect);
                    }
                    // drawstrring
                    x = 20;
                    string content = "";
                    for (int j = 0; j < 7; j++)
                    {
                        if (j > 0) x += w;
                        StringFormat contentsf = new StringFormat();
                        contentsf.Alignment = StringAlignment.Near;
                        switch (j)
                        {
                            case 0:
                                w = 42;
                                content = "STT";
                                break;
                            case 1:
                                w = 112;
                                content = "Mã hàng";
                                break;
                            case 2:
                                w = 290;
                                content = "Tên hàng";
                                break;
                            case 3:
                                w = 60;
                                content = "Đ.Vị";
                                break;
                            case 4:
                                w = 89;
                                content = "Đ.giá (" + Common.MoneyUnit + ")";

                                break;
                            case 5:
                                w = 50;
                                content = "S.lượng";
                                break;
                            //case 6:
                            //    w = 60;
                            //    content = "Thuế(%)";
                            //    break;
                            case 6:
                                w = 122;
                                content = "Thành tiền (" + Common.MoneyUnit + ")";
                                contentsf.Alignment = StringAlignment.Far;
                                break;
                        }
                        Font titleFont3 = new Font("Tahoma", 8, FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
                        Rectangle rectC = new Rectangle(Convert.ToInt32(x + colxpadding), Convert.ToInt32(y + colypadding), Convert.ToInt32(w), Convert.ToInt32(h));
                        g.DrawString(content, titleFont3, Brushes.Black, rectC, contentsf);

                    }
                    y += h;
                }
                #endregion

                //MessageBox.Show(ImExOrderId.ToString());

                #region in noi dung
                double ftotal = 0;

                for (int i = 0; i < dtorderdetail.Rows.Count; i++)
                {
                    x = 20;
                    if (dtorderdetail.Rows[i]["vproductname"].ToString().Length > 42)
                    {
                        h = 40;
                    }

                    else
                    {
                        h = 32;
                    }
                    
                    float w = 0;
                    // draw table
                    if (dtorderdetail.Rows.Count > 0)
                    {
                        #region
                        for (int j = 0; j < 7; j++)
                        {
                            if (j > 0) x += w;
                            switch (j)
                            {
                                case 0:
                                    w = 42;
                                    break;
                                case 1:
                                    w = 112;
                                    break;
                                case 2:
                                    w = 290;
                                    break;
                                case 3:
                                    w = 60;
                                    break;
                                case 4:
                                    w = 89;
                                    break;
                                case 5:
                                    w = 50;
                                    break;
                                //case 6:
                                //    w = 60;
                                //    break;
                                case 6:
                                    w = 122;
                                    break;
                            }

                            Rectangle rect = new Rectangle(Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                            g.DrawRectangle(new Pen(Brushes.Black), rect);
                        }
                        // drawstrring
                        #endregion
                        x = 20;
                        string content = "";

                        for (int j = 0; j < 7; j++)
                        {
                            if (j > 0) x += w;
                            StringFormat contentsf = new StringFormat();
                            contentsf.Alignment = StringAlignment.Near;
                            switch (j)
                            {
                                case 0:
                                    w = 42;
                                    contentsf.Alignment = StringAlignment.Center;
                                    content = (i + 1).ToString();
                                    break;
                                case 1:
                                    w = 112;
                                    content = dtorderdetail.Rows[i]["vproductkey"].ToString().ToUpper();
                                    break;
                                case 2:
                                    w = 290;
                                    content = dtorderdetail.Rows[i]["vproductname"].ToString();
                                    break;
                                case 3:
                                    w = 60;
                                    contentsf.Alignment = StringAlignment.Center;
                                    content = dtorderdetail.Rows[i]["vproductunit"].ToString();
                                    break;
                                case 4:
                                    w = 85;
                                    content = LCUtiliti.ConvertNumber.FomatPrice(dtorderdetail.Rows[i]["vprice"].ToString());
                                    contentsf.Alignment = StringAlignment.Far;
                                    break;
                                case 5:
                                    w = 50;
                                    contentsf.Alignment = StringAlignment.Center;
                                    content = dtorderdetail.Rows[i]["inumber"].ToString();
                                    break;
                                //case 6:
                                //    w = 55;
                                //    contentsf.Alignment = StringAlignment.Center;
                                //    content = dtorderdetail.Rows[i]["ftaxpercent"].ToString();
                                //    break;
                                case 6:
                                    w = 120;
                                    contentsf.Alignment = StringAlignment.Far;
                                    double fitemtotal = (Convert.ToSingle(dtorderdetail.Rows[i]["vprice"]) *
                                    Convert.ToDouble(dtorderdetail.Rows[i]["inumber"]) +
                                    (Convert.ToSingle(dtorderdetail.Rows[i]["vprice"]) *
                                    Convert.ToDouble(dtorderdetail.Rows[i]["inumber"]) *
                                    (Convert.ToSingle(dtorderdetail.Rows[i]["ftaxpercent"]) / 100)));


                                    ftotal += fitemtotal;
                                    content = LCUtiliti.ConvertNumber.FomatPrice(fitemtotal.ToString());
                                    break;
                            }


                            Font titleFont3 = new Font("Tahoma", 9, System.Drawing.GraphicsUnit.Point);
                            Rectangle rectC = new Rectangle(Convert.ToInt32(x + colxpadding), Convert.ToInt32(y + colypadding), Convert.ToInt32(w), Convert.ToInt32(h));
                            g.DrawString(content, titleFont2, Brushes.Black, rectC, contentsf);
                        }
                        y += h;

                    }
                }
                #endregion

                g.DrawString("Tổng tiền: " + LCUtiliti.ConvertNumber.FomatPrice(ftotal.ToString()) + " " + Common.MoneyUnit.ToLower(),
                        titleFont2, Brushes.Black, new RectangleF(560, y += h - 20, e.PageBounds.Width - 120, 32), sf);

                g.DrawString("Viết bằng chữ: " + LCUtiliti.ConvertNumber.ConvertNumberToString(long.Parse(ftotal.ToString()))+" đồng",
                       titleFont2, Brushes.Black, new RectangleF(25, y += h - 15, e.PageBounds.Width - 120, 32), sf);
                
                //g.DrawString("Tiền khách trả: " + LCUtiliti.ConvertNumber.ConvertNumberToString(long.Parse(Common.frmbanhang.txttienkhach.Text)),
                //      titleFont2, Brushes.Black, new RectangleF(25, y += h - 12, e.PageBounds.Width - 120, 32), sf);
                //Double a = (ftotal - Convert.ToDouble(Common.frmbanhang.txttienkhach.Text));
                //g.DrawString("Tiền thừa trả lại khách: " + LCUtiliti.ConvertNumber.ConvertNumberToString(long.Parse(Common.frmbanhang.txtreturn.Text)),
                //                      titleFont2, Brushes.Black, new RectangleF(25, y += h - 10, e.PageBounds.Width - 120, 32), sf);



                g.DrawString("Khách hàng", titleFont2, Brushes.Black,
                    new RectangleF(80, y + h, e.PageBounds.Width - 40, 32), sf);
                //sf.Alignment = StringAlignment.Center;
                //g.DrawString("Thủ kho", titleFont2, Brushes.Black, new RectangleF(0, y + h, e.PageBounds.Width - 40, 32), sf);
                sf.Alignment = StringAlignment.Far;
                g.DrawString("Người lập", titleFont2, Brushes.Black, new RectangleF(0, y + h, e.PageBounds.Width - 160, 32), sf);
                
                //if (count < dtorderdetail.Rows.Count)
                //    e.HasMorePages = true;
                //else
                //{
                //    e.HasMorePages = false;
                //    this.Close();
                //}
            }
        }
    }
}
