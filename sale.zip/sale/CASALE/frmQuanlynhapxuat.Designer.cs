﻿using CASALE.Class;
namespace CASALE
{
    partial class frmQuanlynhapxuat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.frmquanlynhapxuat = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnprintlist = new System.Windows.Forms.Button();
            this.btndisplay = new System.Windows.Forms.Button();
            this.dtpietodate = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpimexdatetime = new System.Windows.Forms.DateTimePicker();
            this.rdimexbyperiod = new System.Windows.Forms.RadioButton();
            this.rdimexbymonth = new System.Windows.Forms.RadioButton();
            this.rdimexbyday = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.txtimexkeyword = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbimexstatus = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbimextype = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.lvitems = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.stt = new System.Windows.Forms.ColumnHeader();
            this.type = new System.Windows.Forms.ColumnHeader();
            this.key = new System.Windows.Forms.ColumnHeader();
            this.date = new System.Windows.Forms.ColumnHeader();
            this.user = new System.Windows.Forms.ColumnHeader();
            this.value = new System.Windows.Forms.ColumnHeader();
            this.status = new System.Windows.Forms.ColumnHeader();
            this.cmnuimexdetail = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mnuimportexportdetail = new System.Windows.Forms.ToolStripMenuItem();
            this.lblmoneyunit = new System.Windows.Forms.Label();
            this.lbltotal = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pndetail = new System.Windows.Forms.Panel();
            this.btnprintbarcode = new System.Windows.Forms.Button();
            this.btndetailimexclose = new System.Windows.Forms.Button();
            this.btndetailprintimexdetaillist = new System.Windows.Forms.Button();
            this.lvimexdetails = new System.Windows.Forms.ListView();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader6 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.dv = new System.Windows.Forms.ColumnHeader();
            this.columnHeader7 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader13 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader8 = new System.Windows.Forms.ColumnHeader();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbldetailclose = new System.Windows.Forms.Label();
            this.lbldetailimextitle = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printDocument2 = new System.Drawing.Printing.PrintDocument();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.cmnuimexdetail.SuspendLayout();
            this.pndetail.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.btnprintlist);
            this.panel2.Controls.Add(this.btndisplay);
            this.panel2.Controls.Add(this.dtpietodate);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.dtpimexdatetime);
            this.panel2.Controls.Add(this.rdimexbyperiod);
            this.panel2.Controls.Add(this.rdimexbymonth);
            this.panel2.Controls.Add(this.rdimexbyday);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtimexkeyword);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.cmbimexstatus);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.cmbimextype);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel2.ForeColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(0, 30);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(778, 45);
            this.panel2.TabIndex = 5;
            // 
            // btnprintlist
            // 
            this.btnprintlist.Image = global::CASALE.Properties.Resources.printer;
            this.btnprintlist.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnprintlist.Location = new System.Drawing.Point(650, 19);
            this.btnprintlist.Name = "btnprintlist";
            this.btnprintlist.Size = new System.Drawing.Size(127, 23);
            this.btnprintlist.TabIndex = 27;
            this.btnprintlist.Text = "In danh sách";
            this.btnprintlist.UseVisualStyleBackColor = true;
            this.btnprintlist.Click += new System.EventHandler(this.btnprintlist_Click);
            // 
            // btndisplay
            // 
            this.btndisplay.Image = global::CASALE.Properties.Resources.book_blue_view;
            this.btndisplay.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btndisplay.Location = new System.Drawing.Point(560, 19);
            this.btndisplay.Name = "btndisplay";
            this.btndisplay.Size = new System.Drawing.Size(91, 23);
            this.btndisplay.TabIndex = 26;
            this.btndisplay.Text = "Hiển thị";
            this.btndisplay.UseVisualStyleBackColor = true;
            this.btndisplay.Click += new System.EventHandler(this.btndisplay_Click);
            // 
            // dtpietodate
            // 
            this.dtpietodate.CustomFormat = "MM/dd/yyyy";
            this.dtpietodate.Enabled = false;
            this.dtpietodate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpietodate.Location = new System.Drawing.Point(337, 20);
            this.dtpietodate.Name = "dtpietodate";
            this.dtpietodate.Size = new System.Drawing.Size(105, 23);
            this.dtpietodate.TabIndex = 25;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(322, 24);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(12, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "-";
            // 
            // dtpimexdatetime
            // 
            this.dtpimexdatetime.CustomFormat = "MM/dd/yyyy";
            this.dtpimexdatetime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpimexdatetime.Location = new System.Drawing.Point(222, 20);
            this.dtpimexdatetime.Name = "dtpimexdatetime";
            this.dtpimexdatetime.Size = new System.Drawing.Size(100, 23);
            this.dtpimexdatetime.TabIndex = 23;
            // 
            // rdimexbyperiod
            // 
            this.rdimexbyperiod.AutoSize = true;
            this.rdimexbyperiod.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdimexbyperiod.Location = new System.Drawing.Point(334, 1);
            this.rdimexbyperiod.Name = "rdimexbyperiod";
            this.rdimexbyperiod.Size = new System.Drawing.Size(121, 17);
            this.rdimexbyperiod.TabIndex = 22;
            this.rdimexbyperiod.Text = "Khoảng thời gian";
            this.rdimexbyperiod.UseVisualStyleBackColor = true;
            this.rdimexbyperiod.CheckedChanged += new System.EventHandler(this.rdimexbyday_CheckedChanged);
            // 
            // rdimexbymonth
            // 
            this.rdimexbymonth.AutoSize = true;
            this.rdimexbymonth.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdimexbymonth.Location = new System.Drawing.Point(274, 0);
            this.rdimexbymonth.Name = "rdimexbymonth";
            this.rdimexbymonth.Size = new System.Drawing.Size(60, 17);
            this.rdimexbymonth.TabIndex = 21;
            this.rdimexbymonth.Text = "Tháng";
            this.rdimexbymonth.UseVisualStyleBackColor = true;
            this.rdimexbymonth.CheckedChanged += new System.EventHandler(this.rdimexbyday_CheckedChanged);
            // 
            // rdimexbyday
            // 
            this.rdimexbyday.AutoSize = true;
            this.rdimexbyday.Checked = true;
            this.rdimexbyday.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdimexbyday.Location = new System.Drawing.Point(222, 0);
            this.rdimexbyday.Name = "rdimexbyday";
            this.rdimexbyday.Size = new System.Drawing.Size(54, 17);
            this.rdimexbyday.TabIndex = 20;
            this.rdimexbyday.TabStop = true;
            this.rdimexbyday.Text = "Ngày";
            this.rdimexbyday.UseVisualStyleBackColor = true;
            this.rdimexbyday.CheckedChanged += new System.EventHandler(this.rdimexbyday_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(453, 4);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Từ khóa";
            // 
            // txtimexkeyword
            // 
            this.txtimexkeyword.Location = new System.Drawing.Point(456, 20);
            this.txtimexkeyword.Name = "txtimexkeyword";
            this.txtimexkeyword.Size = new System.Drawing.Size(100, 23);
            this.txtimexkeyword.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(91, 3);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Trạng thái";
            // 
            // cmbimexstatus
            // 
            this.cmbimexstatus.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cmbimexstatus.FormattingEnabled = true;
            this.cmbimexstatus.Items.AddRange(new object[] {
            "Nhập",
            "Xuất"});
            this.cmbimexstatus.Location = new System.Drawing.Point(91, 20);
            this.cmbimexstatus.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbimexstatus.Name = "cmbimexstatus";
            this.cmbimexstatus.Size = new System.Drawing.Size(130, 22);
            this.cmbimexstatus.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(6, 3);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Loại";
            // 
            // cmbimextype
            // 
            this.cmbimextype.FormattingEnabled = true;
            this.cmbimextype.Items.AddRange(new object[] {
            "Nhập",
            "Xuất"});
            this.cmbimextype.Location = new System.Drawing.Point(6, 20);
            this.cmbimextype.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbimextype.Name = "cmbimextype";
            this.cmbimextype.Size = new System.Drawing.Size(77, 24);
            this.cmbimextype.TabIndex = 14;
            this.cmbimextype.SelectedIndexChanged += new System.EventHandler(this.cmbimextype_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.label7);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(778, 30);
            this.panel1.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label7.Location = new System.Drawing.Point(4, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(185, 18);
            this.label7.TabIndex = 0;
            this.label7.Text = "QUẢN LÝ NHẬP XUẤT";
            // 
            // lvitems
            // 
            this.lvitems.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.stt,
            this.type,
            this.key,
            this.date,
            this.user,
            this.value,
            this.status});
            this.lvitems.ContextMenuStrip = this.cmnuimexdetail;
            this.lvitems.Dock = System.Windows.Forms.DockStyle.Top;
            this.lvitems.FullRowSelect = true;
            this.lvitems.GridLines = true;
            this.lvitems.Location = new System.Drawing.Point(0, 75);
            this.lvitems.Name = "lvitems";
            this.lvitems.Size = new System.Drawing.Size(778, 406);
            this.lvitems.TabIndex = 6;
            this.lvitems.UseCompatibleStateImageBehavior = false;
            this.lvitems.View = System.Windows.Forms.View.Details;
            this.lvitems.SelectedIndexChanged += new System.EventHandler(this.lvitems_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "";
            this.columnHeader1.Width = 0;
            // 
            // stt
            // 
            this.stt.Text = "STT";
            this.stt.Width = 44;
            // 
            // type
            // 
            this.type.Text = "Loại";
            this.type.Width = 107;
            // 
            // key
            // 
            this.key.Text = "Mã đơn hàng";
            this.key.Width = 132;
            // 
            // date
            // 
            this.date.Text = "Thời gian";
            this.date.Width = 140;
            // 
            // user
            // 
            this.user.Text = "Nhân viên";
            this.user.Width = 120;
            // 
            // value
            // 
            this.value.Text = "Giá trị";
            this.value.Width = 117;
            // 
            // status
            // 
            this.status.Text = "Trạng thái";
            this.status.Width = 93;
            // 
            // cmnuimexdetail
            // 
            this.cmnuimexdetail.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuimportexportdetail});
            this.cmnuimexdetail.Name = "cmnuimexdetail";
            this.cmnuimexdetail.Size = new System.Drawing.Size(192, 26);
            // 
            // mnuimportexportdetail
            // 
            this.mnuimportexportdetail.Image = global::CASALE.Properties.Resources.book_blue_view;
            this.mnuimportexportdetail.Name = "mnuimportexportdetail";
            this.mnuimportexportdetail.Size = new System.Drawing.Size(191, 22);
            this.mnuimportexportdetail.Text = "Xem chi tiết đơn hàng";
            this.mnuimportexportdetail.Click += new System.EventHandler(this.mnuimportexportdetail_Click);
            // 
            // lblmoneyunit
            // 
            this.lblmoneyunit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblmoneyunit.Location = new System.Drawing.Point(675, 484);
            this.lblmoneyunit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmoneyunit.Name = "lblmoneyunit";
            this.lblmoneyunit.Size = new System.Drawing.Size(36, 18);
            this.lblmoneyunit.TabIndex = 21;
            this.lblmoneyunit.Text = "VNĐ";
            // 
            // lbltotal
            // 
            this.lbltotal.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbltotal.Location = new System.Drawing.Point(545, 484);
            this.lbltotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(132, 18);
            this.lbltotal.TabIndex = 20;
            this.lbltotal.Text = "0";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.Location = new System.Drawing.Point(465, 484);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 18);
            this.label5.TabIndex = 19;
            this.label5.Text = "Tổng cộng";
            // 
            // pndetail
            // 
            this.pndetail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pndetail.Controls.Add(this.btnprintbarcode);
            this.pndetail.Controls.Add(this.btndetailimexclose);
            this.pndetail.Controls.Add(this.btndetailprintimexdetaillist);
            this.pndetail.Controls.Add(this.lvimexdetails);
            this.pndetail.Controls.Add(this.panel4);
            this.pndetail.Location = new System.Drawing.Point(71, 77);
            this.pndetail.Name = "pndetail";
            this.pndetail.Size = new System.Drawing.Size(637, 371);
            this.pndetail.TabIndex = 23;
            this.pndetail.Visible = false;
            // 
            // btnprintbarcode
            // 
            this.btnprintbarcode.ForeColor = System.Drawing.Color.Red;
            this.btnprintbarcode.Image = global::CASALE.Properties.Resources.images;
            this.btnprintbarcode.Location = new System.Drawing.Point(237, 345);
            this.btnprintbarcode.Name = "btnprintbarcode";
            this.btnprintbarcode.Size = new System.Drawing.Size(163, 23);
            this.btnprintbarcode.TabIndex = 15;
            this.btnprintbarcode.Text = "In mã vạch sản phẩm";
            this.btnprintbarcode.UseVisualStyleBackColor = true;
            this.btnprintbarcode.Click += new System.EventHandler(this.btnprintbarcode_Click);
            // 
            // btndetailimexclose
            // 
            this.btndetailimexclose.Image = global::CASALE.Properties.Resources.action_delete;
            this.btndetailimexclose.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btndetailimexclose.Location = new System.Drawing.Point(415, 345);
            this.btndetailimexclose.Name = "btndetailimexclose";
            this.btndetailimexclose.Size = new System.Drawing.Size(85, 23);
            this.btndetailimexclose.TabIndex = 14;
            this.btndetailimexclose.Text = "Đóng lại";
            this.btndetailimexclose.UseVisualStyleBackColor = true;
            this.btndetailimexclose.Click += new System.EventHandler(this.btndetailimexclose_Click);
            // 
            // btndetailprintimexdetaillist
            // 
            this.btndetailprintimexdetaillist.Image = global::CASALE.Properties.Resources.printer;
            this.btndetailprintimexdetaillist.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btndetailprintimexdetaillist.Location = new System.Drawing.Point(69, 345);
            this.btndetailprintimexdetaillist.Name = "btndetailprintimexdetaillist";
            this.btndetailprintimexdetaillist.Size = new System.Drawing.Size(162, 23);
            this.btndetailprintimexdetaillist.TabIndex = 13;
            this.btndetailprintimexdetaillist.Text = "In hóa đơn nhập/xuất";
            this.btndetailprintimexdetaillist.UseVisualStyleBackColor = true;
            this.btndetailprintimexdetaillist.Click += new System.EventHandler(this.btndetailprintimexdetaillist_Click);
            // 
            // lvimexdetails
            // 
            this.lvimexdetails.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader3,
            this.dv,
            this.columnHeader7,
            this.columnHeader4,
            this.columnHeader13,
            this.columnHeader8});
            this.lvimexdetails.Dock = System.Windows.Forms.DockStyle.Top;
            this.lvimexdetails.FullRowSelect = true;
            this.lvimexdetails.GridLines = true;
            this.lvimexdetails.Location = new System.Drawing.Point(0, 30);
            this.lvimexdetails.Name = "lvimexdetails";
            this.lvimexdetails.Size = new System.Drawing.Size(635, 313);
            this.lvimexdetails.TabIndex = 2;
            this.lvimexdetails.UseCompatibleStateImageBehavior = false;
            this.lvimexdetails.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "ID";
            this.columnHeader2.Width = 0;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "STT";
            this.columnHeader5.Width = 43;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Mã sản phẩm";
            this.columnHeader6.Width = 110;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Tên sản phẩm";
            this.columnHeader3.Width = 127;
            // 
            // dv
            // 
            this.dv.Text = "Đ.Vị";
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Đơn giá";
            this.columnHeader7.Width = 104;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "SL";
            this.columnHeader4.Width = 46;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Thuế";
            this.columnHeader13.Width = 45;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Thành tiền";
            this.columnHeader8.Width = 119;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel4.Controls.Add(this.lbldetailclose);
            this.panel4.Controls.Add(this.lbldetailimextitle);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel4.ForeColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(635, 30);
            this.panel4.TabIndex = 1;
            // 
            // lbldetailclose
            // 
            this.lbldetailclose.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbldetailclose.Location = new System.Drawing.Point(615, 7);
            this.lbldetailclose.Name = "lbldetailclose";
            this.lbldetailclose.Size = new System.Drawing.Size(16, 16);
            this.lbldetailclose.TabIndex = 1;
            this.lbldetailclose.Text = "X";
            this.lbldetailclose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbldetailclose.Click += new System.EventHandler(this.lbldetailclose_Click);
            // 
            // lbldetailimextitle
            // 
            this.lbldetailimextitle.AutoSize = true;
            this.lbldetailimextitle.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbldetailimextitle.Location = new System.Drawing.Point(4, 7);
            this.lbldetailimextitle.Name = "lbldetailimextitle";
            this.lbldetailimextitle.Size = new System.Drawing.Size(156, 16);
            this.lbldetailimextitle.TabIndex = 0;
            this.lbldetailimextitle.Text = "CHI TIẾT NHẬP XUẤT";
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printexport_PrintPage);
            // 
            // printDocument2
            // 
            this.printDocument2.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printorder_PrintPage);
            // 
            // frmQuanlynhapxuat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(778, 525);
            this.Controls.Add(this.pndetail);
            this.Controls.Add(this.lblmoneyunit);
            this.Controls.Add(this.lbltotal);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lvitems);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "frmQuanlynhapxuat";
            this.Text = "Quản lý bán hàng";
            this.Load += new System.EventHandler(this.frmQuanlynhapxuat_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.lvitems, 0);
            this.Controls.SetChildIndex(this.label5, 0);
            this.Controls.SetChildIndex(this.lbltotal, 0);
            this.Controls.SetChildIndex(this.lblmoneyunit, 0);
            this.Controls.SetChildIndex(this.pndetail, 0);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.cmnuimexdetail.ResumeLayout(false);
            this.pndetail.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnprintlist;
        private System.Windows.Forms.Button btndisplay;
        private System.Windows.Forms.DateTimePicker dtpietodate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpimexdatetime;
        private System.Windows.Forms.RadioButton rdimexbyperiod;
        private System.Windows.Forms.RadioButton rdimexbymonth;
        private System.Windows.Forms.RadioButton rdimexbyday;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtimexkeyword;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbimexstatus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbimextype;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListView lvitems;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader stt;
        private System.Windows.Forms.ColumnHeader type;
        private System.Windows.Forms.ColumnHeader key;
        private System.Windows.Forms.ColumnHeader date;
        private System.Windows.Forms.ColumnHeader user;
        private System.Windows.Forms.ColumnHeader status;
        private System.Windows.Forms.ColumnHeader value;
        private System.Windows.Forms.Label lblmoneyunit;
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ContextMenuStrip cmnuimexdetail;
        private System.Windows.Forms.ToolStripMenuItem mnuimportexportdetail;
        private System.Windows.Forms.Panel pndetail;
        private System.Windows.Forms.Button btnprintbarcode;
        private System.Windows.Forms.Button btndetailimexclose;
        private System.Windows.Forms.Button btndetailprintimexdetaillist;
        private System.Windows.Forms.ListView lvimexdetails;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader dv;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbldetailclose;
        private System.Windows.Forms.Label lbldetailimextitle;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Drawing.Printing.PrintDocument printDocument2;
    }
}