﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CASALE.Class;
using LCProductCartUtiliti;
using System.Drawing.Printing;
using LCMultiUtilities;

namespace CASALE
{
    public partial class frmQuanlynhapxuat : templates
    {
        int idaytype = 0;
        string datetypetype = "";// dung trong in ấn
        string datetypevalue = ""; // dùng trong in ấn
        int iselectedid = -1;

        int iselectedordertype = 0;
        int PrintFromPage = 0;
        int PrintCurrentRow = 0;

        double ftotal = 0;

        public frmQuanlynhapxuat()
        {
            InitializeComponent();
        }

        private void frmQuanlynhapxuat_Load(object sender, EventArgs e)
        {
            cmbimextype.DataSource = Common.ImportExportTypes;
            cmbimextype.DisplayMember = "Type";
            cmbimextype.ValueMember = "ID";

            dtpimexdatetime.Value = DateTime.Now;
            dtpietodate.Value = DateTime.Now;

            cmbimextype_SelectedIndexChanged(sender, e);
            lblmoneyunit.Text = Common.MoneyUnit;
            LoadImportExportList();
        }
        void LoadRadioDayTypeCheck()
        {
            dtpietodate.Enabled = false;
            if (rdimexbyday.Checked == true)
            {
                dtpimexdatetime.Format = DateTimePickerFormat.Custom;
                dtpimexdatetime.CustomFormat = "dd/MM/yyyy";
                idaytype = 0;
                datetypetype = " NGÀY ";
            }
            else if (rdimexbymonth.Checked == true)
            {
                dtpimexdatetime.Format = DateTimePickerFormat.Custom;
                dtpimexdatetime.CustomFormat = "MM/yyyy";
                idaytype = 1;
                datetypetype = " THÁNG ";

            }
            else if (rdimexbyperiod.Checked == true)
            {
                dtpimexdatetime.Format = DateTimePickerFormat.Custom;
                dtpimexdatetime.CustomFormat = "dd/MM/yyyy";
                dtpietodate.CustomFormat = "dd/MM/yyyy";
                dtpietodate.Enabled = true;
                idaytype = 2;
                datetypetype = " TRONG THỜI GIAN ";
            }
        }
        private void rdimexbyday_CheckedChanged(object sender, EventArgs e)
        {
            LoadRadioDayTypeCheck();
        }
        string UserName(string senderparams)
        {
            string[] prs = senderparams.Split('|');
            if (prs.Length > 1)
            {
                return prs[1];
            }
            return prs[0];
        }
        void LoadImportExportList()
        {
            double total = 0;
            DataTable dt = new DataTable();
            //MessageBox.Show(cmbimexstatus.SelectedValue.ToString());
            dt = ImportExport.sale_objects_importexport_getiolist(
                Convert.ToInt32(cmbimextype.SelectedValue),
                Convert.ToInt32(cmbimexstatus.SelectedValue),
                txtimexkeyword.Text,
                idaytype,
                dtpimexdatetime.Value,
                dtpietodate.Value,
                "", "",
                Common.ConnectionString);
            lvitems.Items.Clear();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ListViewItem lvi = new ListViewItem(dt.Rows[i]["isoixid"].ToString());
                lvi.SubItems.Add((i + 1).ToString());
                lvi.SubItems.Add(IMEXType(Convert.ToInt32(dt.Rows[i]["itype"])));
                lvi.SubItems.Add(dt.Rows[i]["vcode"].ToString());
                lvi.SubItems.Add(Convert.ToDateTime(dt.Rows[i]["ddatetime"]).ToString("dd/MM/yyyy"));
                lvi.SubItems.Add(UserName(dt.Rows[i]["vsenderparams"].ToString()).ToString());
                lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dt.Rows[i]["ftotal"].ToString()));
                lvitems.Items.Add(lvi);
                lvi.SubItems.Add(dt.Rows[i]["istatus"].ToString());
                total += Convert.ToDouble(dt.Rows[i]["ftotal"]);
            }
            lbltotal.Text = LCUtiliti.ConvertNumber.FomatPrice(total.ToString());
        }
        string IMEXType(int itype)
        {
            if (itype == 0)
                return "Xuất";
            else if (itype == 1)
                return "Nhập";
            return "--";
        }
        private void btndisplay_Click(object sender, EventArgs e)
        {
            LoadImportExportList();
        }

        private void cmbimextype_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbimextype.SelectedValue.ToString())
            {
                case "-1":
                    cmbimexstatus.DataSource = Common.AllStatus;
                    break;
                case "1":// nhập
                    cmbimexstatus.DataSource = Common.ImportStatus;
                    break;
                case "0":
                    cmbimexstatus.DataSource = Common.OrderStatus;
                    break;
            }
            cmbimexstatus.DisplayMember = "Status";
            cmbimexstatus.ValueMember = "ID";
        }

        private void mnuimportexportdetail_Click(object sender, EventArgs e)
        {
            if (iselectedid != -1)
            {
                DataTable dt = new DataTable();

                dt = ImportExport.sale_objects_importexport_getdetailbyid(iselectedid, Common.ConnectionString);
                if (dt.Rows.Count > 0)
                {
                    iselectedordertype = Convert.ToInt32(dt.Rows[0]["itype"]);
                    lbldetailimextitle.Text = "CHI TIẾT ĐƠN HÀNG ";
                    if (dt.Rows[0]["itype"].Equals("1"))
                    {
                        lbldetailimextitle.Text += "NHẬP";
                    }
                    else
                    {
                        lbldetailimextitle.Text += "XUẤT";
                    }
                    lbldetailimextitle.Text += " " + dt.Rows[0]["vcode"].ToString();
                }
                lvimexdetails.Items.Clear();
                dt = ImportExportDetail.sale_objects_imexdetails_getdetaillistby_ioid(iselectedid, Common.ConnectionString);
                double ftotal = 0;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ListViewItem lvi = new ListViewItem();
                    lvi.SubItems.Add((i + 1).ToString());
                    lvi.SubItems.Add(dt.Rows[i]["vproductkey"].ToString().ToUpper());
                    lvi.SubItems.Add(dt.Rows[i]["vproductname"].ToString());
                    lvi.SubItems.Add(dt.Rows[i]["vproductunit"].ToString());
                    lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dt.Rows[i]["fprice"].ToString()));
                    lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dt.Rows[i]["iquantity"].ToString()));
                    lvi.SubItems.Add(dt.Rows[i]["ftaxpercent"].ToString());

                    double fitemtotal = (Convert.ToSingle(dt.Rows[i]["fprice"]) *
                                Convert.ToInt32(dt.Rows[i]["iquantity"]) +
                                (Convert.ToSingle(dt.Rows[i]["fprice"]) *
                                Convert.ToInt32(dt.Rows[i]["iquantity"]) *
                                (Convert.ToSingle(dt.Rows[i]["ftaxpercent"]) / 100)));


                    ftotal += fitemtotal;

                    lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(fitemtotal.ToString()));
                    lvimexdetails.Items.Add(lvi);
                    pndetail.Visible = true;
                }
                //lblTongtien.Text = ftotal.ToString();
            }
        }

        private void lbldetailclose_Click(object sender, EventArgs e)
        {
            pndetail.Visible = false;
        }

        private void lvitems_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvitems.Items.Count > 0)
            {
                if (lvitems.SelectedItems.Count > 0)
                {
                    iselectedid = Convert.ToInt32(lvitems.SelectedItems[0].SubItems[0].Text);
                    cmnuimexdetail.Enabled = true;
                }
                else
                {
                    iselectedid = -1;
                    cmnuimexdetail.Enabled = false;
                }
            }
            else
            {
                iselectedid = -1;
                cmnuimexdetail.Enabled = false;
            }
        }
        DataTable tbimexport = new DataTable();
        double tong = 0;
        PrintPreviewDialog printpreviewdialog = new PrintPreviewDialog();
        System.Drawing.Printing.PrintDocument printdocument = new System.Drawing.Printing.PrintDocument();


        float h = 0.0f;

        int PrintImExOrderId = -1;
        //string CompanyName = "";
        string PrintTitle = "";// tiêu đề in.

        int PrintImExType = 0;// loại xuất hay  nhập
        string PrintImExOrderCode = "";
        DateTime PrintImExDateTime = DateTime.Now;
        DataTable PrintDtImEx = new DataTable();
        DataTable PrintDtImExDetail = new DataTable();
        double tonghoadon = 0;
        private void btnprintlist_Click(object sender, EventArgs e)
        {
            tong = 0;
            tbimexport = ImportExport.sale_objects_importexport_getiolist(
                Convert.ToInt32(cmbimextype.SelectedValue),
                Convert.ToInt32(cmbimexstatus.SelectedValue),
                txtimexkeyword.Text,
                idaytype,
                dtpimexdatetime.Value,
                dtpietodate.Value,
                "", "",
                Common.ConnectionString);
            PrintFromPage = 0;
            PrintCurrentRow = 0;
            ftotal = 0;

            //printdocument = new PrintDocument();
            //printdocument.PrintPage += new PrintPageEventHandler(printexport_PrintPage);
            //PrintDialog pdl = new PrintDialog();
            //if (pdl.ShowDialog() == DialogResult.OK)
            //{
            //    printDocument1.PrinterSettings = pdl.PrinterSettings;
                printDocument1.Print();
            //}
        }
        private void printexport_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            #region
            if (tbimexport.Rows.Count == 0 || PrintCurrentRow >= tbimexport.Rows.Count)
            {
                e.HasMorePages = false;
                PrintCurrentRow = 0;
                PrintFromPage = 0;

                return;
            }

            Graphics g = e.Graphics;
            Rectangle rFull = new Rectangle(
                e.PageBounds.Left - 10,
                e.PageBounds.Top,
                e.PageBounds.Right,
                e.PageBounds.Bottom);

            StringFormat sf = new StringFormat();
            float x = 10;
            float y = 10;
            float colxpadding = 3;
            float colypadding = 3;

            Font titleFont = new Font("Tahoma", 8, System.Drawing.GraphicsUnit.Point);
            Font titleFont2 = new Font("Tahoma", 10, System.Drawing.GraphicsUnit.Point);

            if (PrintFromPage == 0)
            {
                #region header

                PrintTitle = "THỐNG KÊ NHẬP XUẤT";

                g.DrawString(Common.CorporationName.ToString().ToUpper(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString(Common.CompanyName.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString(Common.CompanyAddress.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString("Điện thoại: " + Common.CompanyPhone.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);

                sf.Alignment = StringAlignment.Center;
                y += titleFont.Height + 5;
                Font titleFont1 = new Font("Tahoma", 16, System.Drawing.GraphicsUnit.Point);
                g.DrawString(PrintTitle, titleFont1, Brushes.Black, new RectangleF(3, y, e.PageBounds.Width - 20, 32), sf);

                y += titleFont1.Height + 2;
                if (tbimexport.Rows.Count > 0)
                {
                    sf.Alignment = StringAlignment.Near;
                    g.DrawString("Chi tiết nhập xuất",
                       titleFont2, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 20, 32), sf);
                    y += titleFont2.Height + 1;
                }
                #endregion
            }
            else
            {
                y = 50;
            }
            #endregion

            #region Table Header
            for (int i = 0; i < 1; i++)
            {
                x = 20;
                float h = 25;
                float w = 0;
                for (int j = 0; j < 7; j++)
                {
                    if (j > 0) x += w;

                    switch (j)
                    {
                        case 0:
                            w = 45;
                            break;
                        case 1:
                            w = 50;
                            break;
                        case 2:
                            w = 170;
                            break;
                        case 3:
                            w = 100;
                            break;
                        case 4:
                            w = 170;
                            break;
                        case 5:
                            w = 70;
                            break;
                        case 6:
                            w = 150;
                            break;

                    }
                    Brush brushHeader = new SolidBrush(Color.WhiteSmoke);
                    Rectangle rect = new Rectangle(Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                    g.FillRectangle(brushHeader, Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                    g.DrawRectangle(new Pen(Brushes.Black), rect);
                }
                // drawstrring
                x = 20;
                string content = "";
                for (int j = 0; j < 7; j++)
                {
                    if (j > 0) x += w;
                    StringFormat contentsf = new StringFormat();
                    contentsf.Alignment = StringAlignment.Near;
                    switch (j)
                    {
                        case 0:
                            w = 45;
                            content = "STT";
                            break;
                        case 1:
                            w = 50;
                            content = "Loại";
                            break;
                        case 2:
                            w = 170;
                            content = "Mã đơn hàng";
                            break;
                        case 3:
                            w = 100;
                            content = "Thời gian";
                            break;
                        case 4:
                            w = 170;
                            content = "Nhân viên";
                            break;
                        case 5:
                            w = 70;
                            content = "Trạng thái";
                            break;
                        case 6:
                            w = 150;
                            content = "Giá trị";
                            break;
                    }
                    Font titleFont3 = new Font("Tahoma", 8, FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
                    Rectangle rectC = new Rectangle(Convert.ToInt32(x + colxpadding), Convert.ToInt32(y + colypadding), Convert.ToInt32(w), Convert.ToInt32(h));
                    g.DrawString(content, titleFont3, Brushes.Black, rectC, contentsf);

                }
                y += h;
            }
            #endregion

            #region in noi dung

            for (int i = PrintCurrentRow; i < tbimexport.Rows.Count; i++)
            {
                x = 20;
                #region
                if (tbimexport.Rows[i]["ftotal"].ToString().Length > 30)
                {
                    h = 40;
                }
                else
                {
                    h = 32;
                }
                #endregion
                float w = 0;
                #region Print Item
                if (tbimexport.Rows.Count > 0)
                {
                    #region ve khung
                    for (int j = 0; j < 7; j++)
                    {
                        if (j > 0) x += w;
                        switch (j)
                        {
                            case 0:
                                w = 45;
                                break;
                            case 1:
                                w = 50;
                                break;
                            case 2:
                                w = 170;
                                break;
                            case 3:
                                w = 100;
                                break;
                            case 4:
                                w = 170;
                                break;
                            case 5:
                                w = 70;
                                break;
                            case 6:
                                w = 150;
                                break;
                        }

                        Rectangle rect = new Rectangle(Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                        g.DrawRectangle(new Pen(Brushes.Black), rect);
                    }
                    // drawstrring
                    #endregion
                    x = 20;
                    string content = "";

                    for (int j = 0; j < 7; j++)
                    {
                        if (j > 0) x += w;
                        StringFormat contentsf = new StringFormat();
                        contentsf.Alignment = StringAlignment.Near;
                        switch (j)
                        {
                            case 0:
                                w = 45;
                                content = (i + 1).ToString();
                                break;
                            case 1:
                                w = 50;
                                content = IMEXType(Convert.ToInt32(tbimexport.Rows[i]["itype"]));
                                break;
                            case 2:
                                w = 170;
                                content = tbimexport.Rows[i]["vcode"].ToString();
                                break;
                            case 3:
                                w = 100;
                                contentsf.Alignment = StringAlignment.Center;
                                content = Convert.ToDateTime(tbimexport.Rows[i]["ddatetime"]).ToString("dd/MM/yyyy");
                                break;
                            case 4:
                                w = 170;
                                content = UserName(tbimexport.Rows[i]["vsenderparams"].ToString()).ToString();
                                break;
                            case 5:
                                w = 70;
                                contentsf.Alignment = StringAlignment.Center;
                                content = tbimexport.Rows[i]["istatus"].ToString();
                                break;
                            case 6:
                                w = 140;
                                contentsf.Alignment = StringAlignment.Far;
                                content = LCUtiliti.ConvertNumber.FomatPrice(tbimexport.Rows[i]["ftotal"].ToString());
                                tong += Convert.ToDouble(tbimexport.Rows[i]["ftotal"]);
                                break;

                        }
                        Font titleFont3 = new Font("Tahoma", 9, System.Drawing.GraphicsUnit.Point);
                        Rectangle rectC = new Rectangle(Convert.ToInt32(x + colxpadding), Convert.ToInt32(y + colypadding), Convert.ToInt32(w), Convert.ToInt32(h));
                        g.DrawString(content, titleFont2, Brushes.Black, rectC, contentsf);
                    }
                    y += h;

                }
                #endregion

                PrintCurrentRow++;
                if (y > e.PageBounds.Height - 115)
                    break;
            }
            #endregion
            bool last = false;
            // e.HasMorePages = true;
            PrintFromPage++;
            if (PrintCurrentRow >= tbimexport.Rows.Count)
            {
                last = true;
            }
            else
            {
                last = false;
            }

            if (last == true)
            {
                sf.Alignment = StringAlignment.Far;
                g.DrawString("Tổng: " + LCUtiliti.ConvertNumber.FomatPrice(tong.ToString()) + "(" + Common.MoneyUnit + ")", titleFont2, Brushes.Black, new RectangleF(0, y += h - 20, e.PageBounds.Width - 100, 32), sf);

                sf.Alignment = StringAlignment.Near;
                g.DrawString("Người lập", titleFont2, Brushes.Black, new RectangleF(20, y + h + 30, e.PageBounds.Width - 40, 32), sf);
                sf.Alignment = StringAlignment.Center;
                g.DrawString("Thủ kho", titleFont2, Brushes.Black, new RectangleF(0, y + h + 30, e.PageBounds.Width - 40, 32), sf);
                sf.Alignment = StringAlignment.Far;
                g.DrawString("Giám đốc", titleFont2, Brushes.Black, new RectangleF(0, y + h + 30, e.PageBounds.Width - 120, 32), sf);
            }
            g.DrawString("Trang " + (PrintFromPage).ToString(), titleFont2, Brushes.Black, new RectangleF(e.PageBounds.Width - 120, e.PageBounds.Height - 60, 100, 20));

            if (last == false)
            {
                e.HasMorePages = true;
            }
            else
            {
                e.HasMorePages = false;
                PrintFromPage = 0;
                PrintCurrentRow = 0;
                tong = 0;
            }
        }

        private void btndetailprintimexdetaillist_Click(object sender, EventArgs e)
        {


            PrintImExOrderId = iselectedid;
            PrintImExType = iselectedordertype;
            PrintDtImEx = ImportExport.sale_objects_importexport_getdetailbyid(PrintImExOrderId, Common.ConnectionString);
            PrintDtImExDetail = ImportExportDetail.sale_objects_imexdetails_getdetaillistby_ioid(PrintImExOrderId, Common.ConnectionString);
            PrintFromPage = 0;
            PrintCurrentRow = 0;
            printdocument = new PrintDocument();
            //printdocument.PrintPage += new PrintPageEventHandler(printorder_PrintPage);
            //PrintDialog pdl = new PrintDialog();
            //if (pdl.ShowDialog() == DialogResult.OK)
            //{
                //printDocument2.PrinterSettings = pdl.PrinterSettings;
                printDocument2.Print();
            //}
            tonghoadon = 0;
        }
        private void printorder_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

            if (PrintDtImExDetail.Rows.Count == 0 || PrintCurrentRow >= PrintDtImExDetail.Rows.Count)
            {
                e.HasMorePages = false;
                PrintCurrentRow = 0;
                PrintFromPage = 0;

                return;
            }

            Graphics g = e.Graphics;
            Rectangle rFull = new Rectangle(
                e.PageBounds.Left - 10,
                e.PageBounds.Top,
                e.PageBounds.Right,
                e.PageBounds.Bottom);

            StringFormat sf = new StringFormat();
            float x = 10;
            float y = 10;
            float colxpadding = 3;
            float colypadding = 3;

            Font titleFont = new Font("Tahoma", 8, System.Drawing.GraphicsUnit.Point);
            Font titleFont2 = new Font("Tahoma", 10, System.Drawing.GraphicsUnit.Point);

            if (PrintFromPage == 0)
            {
                #region header
                if (PrintDtImEx.Rows.Count > 0)
                {
                    switch (PrintDtImEx.Rows[0]["itype"].ToString())
                    {
                        case "1":
                            PrintTitle = Common.ImExPrintImTitle;
                            break;
                        case "0":
                            PrintTitle = Common.ImExPrintExTitle;
                            break;
                    }
                }
                g.DrawString(Common.CorporationName.ToString().ToUpper(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString(Common.CompanyName.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString(Common.CompanyAddress.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString("Điện thoại: " + Common.CompanyPhone.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);

                sf.Alignment = StringAlignment.Center;
                //float y1 = 32;
                y += titleFont.Height + 5;
                Font titleFont1 = new Font("Tahoma", 16, System.Drawing.GraphicsUnit.Point);
                g.DrawString(PrintTitle, titleFont1, Brushes.Black, new RectangleF(3, y, e.PageBounds.Width - 20, 32), sf);

                y += titleFont1.Height + 2;
                if (PrintDtImEx.Rows.Count > 0)
                {
                    sf.Alignment = StringAlignment.Near;
                    g.DrawString("Mã đơn hàng:" + PrintDtImEx.Rows[0]["vcode"].ToString().ToUpper(),
                        titleFont2, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 20, 32), sf);
                    y += titleFont2.Height;
                    g.DrawString("Thời gian:" + Convert.ToDateTime(PrintDtImEx.Rows[0]["ddatetime"]).ToString("dd-MM-yyyy"),
                        titleFont2, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 20, 32), sf);

                    y += titleFont2.Height + 5;
                    sf.Alignment = StringAlignment.Near;
                    g.DrawString("Danh mục sản phẩm",
                       titleFont2, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 20, 32), sf);
                    y += titleFont2.Height + 1;
                }
                #endregion
            }
            else
            {
                y = 50;
            }
            #region Table Header
            for (int i = 0; i < 1; i++)
            {
                x = 20;
                float h = 25;
                float w = 0;
                // draw table
                for (int j = 0; j < 8; j++)
                {
                    if (j > 0) x += w;

                    switch (j)
                    {
                        case 0:
                            w = 42;
                            break;
                        case 1:
                            w = 122;
                            break;
                        case 2:
                            w = 200;
                            break;
                        case 3:
                            w = 60;
                            break;
                        case 4:
                            w = 100;
                            break;
                        case 5:
                            w = 50;
                            break;
                        case 6:
                            w = 70;
                            break;
                        case 7:
                            w = 112;
                            break;
                    }
                    Brush brushHeader = new SolidBrush(Color.WhiteSmoke);
                    Rectangle rect = new Rectangle(Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                    g.FillRectangle(brushHeader, Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                    g.DrawRectangle(new Pen(Brushes.Black), rect);
                }
                // drawstrring
                x = 20;
                string content = "";
                for (int j = 0; j < 8; j++)
                {
                    if (j > 0) x += w;
                    StringFormat contentsf = new StringFormat();
                    contentsf.Alignment = StringAlignment.Near;
                    switch (j)
                    {
                        case 0:
                            w = 42;
                            content = "STT";
                            break;
                        case 1:
                            w = 122;
                            content = "MSP";
                            break;
                        case 2:
                            w = 200;
                            content = "Tên sản phẩm";
                            break;
                        case 3:
                            w = 60;
                            content = "Đơn vị";
                            break;
                        case 4:
                            w = 97;
                            content = "Đ.giá (" + Common.MoneyUnit + ")";
                            contentsf.Alignment = StringAlignment.Far;
                            break;
                        case 5:
                            w = 50;
                            content = "S.lượng";
                            break;
                        case 6:
                            w = 70;
                            content = "Thuế(%)";
                            break;
                        case 7:
                            w = 112;
                            content = "Thành tiền (" + Common.MoneyUnit + ")";
                            contentsf.Alignment = StringAlignment.Far;
                            break;
                    }
                    Font titleFont3 = new Font("Tahoma", 8, FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
                    Rectangle rectC = new Rectangle(Convert.ToInt32(x + colxpadding), Convert.ToInt32(y + colypadding), Convert.ToInt32(w), Convert.ToInt32(h));
                    g.DrawString(content, titleFont3, Brushes.Black, rectC, contentsf);

                }
                y += h;
            }
            #endregion

            #region in noi dung

            for (int i = PrintCurrentRow; i < PrintDtImExDetail.Rows.Count; i++)
            {
                x = 20;
                h = 32;
                float w = 0;
                // draw table
                #region Print Item
                if (PrintDtImExDetail.Rows.Count > 0)
                {
                    #region
                    for (int j = 0; j < 8; j++)
                    {
                        if (j > 0) x += w;
                        switch (j)
                        {
                            case 0:
                                w = 42;
                                break;
                            case 1:
                                w = 122;
                                break;
                            case 2:
                                w = 200;
                                break;
                            case 3:
                                w = 60;
                                break;
                            case 4:
                                w = 100;
                                break;
                            case 5:
                                w = 50;
                                break;
                            case 6:
                                w = 70;
                                break;
                            case 7:
                                w = 112;
                                break;
                        }

                        Rectangle rect = new Rectangle(Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                        g.DrawRectangle(new Pen(Brushes.Black), rect);
                    }
                    // drawstrring
                    #endregion
                    x = 20;
                    string content = "";

                    for (int j = 0; j < 8; j++)
                    {
                        if (j > 0) x += w;
                        StringFormat contentsf = new StringFormat();
                        contentsf.Alignment = StringAlignment.Near;
                        switch (j)
                        {
                            case 0:
                                w = 42;
                                content = (i + 1).ToString();
                                break;
                            case 1:
                                w = 122;
                                content = PrintDtImExDetail.Rows[i]["vproductkey"].ToString().ToUpper();
                                break;
                            case 2:
                                w = 200;
                                content = PrintDtImExDetail.Rows[i]["vproductname"].ToString();
                                break;
                            case 3:
                                w = 60;
                                content = PrintDtImExDetail.Rows[i]["vproductunit"].ToString();
                                break;
                            case 4:
                                w = 97;
                                content = LCUtiliti.ConvertNumber.FomatPrice(PrintDtImExDetail.Rows[i]["fprice"].ToString());
                                contentsf.Alignment = StringAlignment.Far;
                                break;
                            case 5:
                                w = 50;
                                contentsf.Alignment = StringAlignment.Far;
                                content = LCUtiliti.ConvertNumber.FomatPrice(PrintDtImExDetail.Rows[i]["iquantity"].ToString());
                                break;
                            case 6:
                                w = 70;
                                contentsf.Alignment = StringAlignment.Center;
                                content = PrintDtImExDetail.Rows[i]["ftaxpercent"].ToString();
                                break;
                            case 7:
                                w = 112;
                                contentsf.Alignment = StringAlignment.Far;
                                double fitemtotal = (Convert.ToSingle(PrintDtImExDetail.Rows[i]["fprice"]) *
                                Convert.ToInt32(PrintDtImExDetail.Rows[i]["iquantity"]) +
                                (Convert.ToSingle(PrintDtImExDetail.Rows[i]["fprice"]) *
                                Convert.ToInt32(PrintDtImExDetail.Rows[i]["iquantity"]) *
                                (Convert.ToSingle(PrintDtImExDetail.Rows[i]["ftaxpercent"]) / 100)));

                                content = LCUtiliti.ConvertNumber.FomatPrice(fitemtotal.ToString());

                                tonghoadon += fitemtotal;

                                break;
                        }


                        Font titleFont3 = new Font("Tahoma", 9, System.Drawing.GraphicsUnit.Point);
                        Rectangle rectC = new Rectangle(Convert.ToInt32(x + colxpadding), Convert.ToInt32(y + colypadding), Convert.ToInt32(w), Convert.ToInt32(h));
                        g.DrawString(content, titleFont2, Brushes.Black, rectC, contentsf);
                    }
                    y += h;

                }
                #endregion

                PrintCurrentRow++;
                if (y > e.PageBounds.Height - 125)
                    break;
            }
            #endregion
            bool last = false;
            // e.HasMorePages = true;
            PrintFromPage++;
            if (PrintCurrentRow >= PrintDtImExDetail.Rows.Count)
            {
                last = true;
            }
            else
            {
                last = false;
            }

            if (last == true)
            {
                g.DrawString("Tổng cộng: " + LCUtiliti.ConvertNumber.FomatPrice(tonghoadon.ToString()) + " " + Common.MoneyUnit,
                        titleFont2, Brushes.Black, new RectangleF(560, y += h - 20, e.PageBounds.Width - 40, 32), sf);
                //g.DrawString("Tổng trọng lượng: ",
                //  titleFont2, Brushes.Black, new RectangleF(517, y += h - 15, e.PageBounds.Width - 50, 32), sf);
                g.DrawString("Người lập", titleFont2, Brushes.Black, new RectangleF(20, y + h + 20, e.PageBounds.Width - 40, 32), sf);
                sf.Alignment = StringAlignment.Center;
                g.DrawString("Thủ kho", titleFont2, Brushes.Black, new RectangleF(0, y + h + 20, e.PageBounds.Width - 40, 32), sf);
                sf.Alignment = StringAlignment.Far;
                g.DrawString("Giám đốc", titleFont2, Brushes.Black, new RectangleF(0, y + h + 20, e.PageBounds.Width - 120, 32), sf);
                //sf.Alignment = StringAlignment.Near;
                //g.DrawString("Hải quan giám sát", titleFont2, Brushes.Black, new RectangleF(20, y + h + 120, e.PageBounds.Width - 40, 32), sf);

            }
            g.DrawString("Trang " + (PrintFromPage).ToString(), titleFont2, Brushes.Black, new RectangleF(e.PageBounds.Width - 120, e.PageBounds.Height - 60, 100, 20));

            if (last == false)
            {
                e.HasMorePages = true;
            }
            else
            {
                e.HasMorePages = false;
                PrintFromPage = 0;
                PrintCurrentRow = 0;
                tonghoadon = 0;
            }
        }

        private void btndetailimexclose_Click(object sender, EventArgs e)
        {
            pndetail.Visible = false;
        }

        private void btnprintbarcode_Click(object sender, EventArgs e)
        {
            DataTable dt = ImportExportDetail.sale_objects_imexdetails_getdetaillistby_ioid(iselectedid, Common.ConnectionString);
            if (dt.Rows.Count > 0)
            {
                if (Common.fimexbarcode == null)
                {
                    Common.fimexbarcode = new frmbarcodeimportexport();
                    frmbarcodeimportexport.PrintBCodeList.Clear();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        int iproductquantity = Convert.ToInt32(dt.Rows[i]["iquantity"]);
                        DataTable dtprodetail = new DataTable();
                        dtprodetail = mssql_multicates_multidb_items.dicts_items_GetDetailByID(dt.Rows[i]["iproductid"].ToString(), Common.capp_product_code, Common.ConnectionString);
                        if (dtprodetail.Rows.Count > 0)
                        {
                            string code = dtprodetail.Rows[0]["vkey"].ToString();
                            string name = dtprodetail.Rows[0]["vtitle"].ToString();
                            double price = Convert.ToDouble(dtprodetail.Rows[0]["vauthor"]);

                            for (int j = 0; j < iproductquantity; j++)
                            {
                                barcodecontrol bcc = new barcodecontrol();
                                bcc.Index = i;
                                bcc.Width = 142;
                                bcc.Height = 70;
                                bcc.BarWidth = 140;
                                bcc.BarHeight = 22;
                                bcc.PrintCode = code;
                                bcc.PrintTitle = name;
                                bcc.PrintPrice = price.ToString();
                                bcc.PrintEnable = true;
                                frmbarcodeimportexport.PrintBCodeList.Add(bcc);
                            }
                        }
                    }
                    frmbarcodeimportexport.PrintBCodeList.FormatList();
                }
                Common.fimexbarcode.MdiParent = this.MdiParent;
                Common.fimexbarcode.Show();
                Common.fimexbarcode.Focus();
            }
        }
    }
}