﻿using CASALE.Class;
namespace CASALE
{
    partial class frmReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.frmreport = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rdimexbyyear = new System.Windows.Forms.RadioButton();
            this.btnprintlist = new System.Windows.Forms.Button();
            this.btndisplay = new System.Windows.Forms.Button();
            this.dtpietodate = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpimexdatetime = new System.Windows.Forms.DateTimePicker();
            this.rdimexbyperiod = new System.Windows.Forms.RadioButton();
            this.rdimexbymonth = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.txtimexkeyword = new System.Windows.Forms.TextBox();
            this.lvitems = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.stt = new System.Windows.Forms.ColumnHeader();
            this.time = new System.Windows.Forms.ColumnHeader();
            this.imp = new System.Windows.Forms.ColumnHeader();
            this.xm = new System.Windows.Forms.ColumnHeader();
            this.total = new System.Windows.Forms.ColumnHeader();
            this.lblmoneyunit1 = new System.Windows.Forms.Label();
            this.lblsumimporttotal = new System.Windows.Forms.Label();
            this.lblmoneyunit2 = new System.Windows.Forms.Label();
            this.lblsumexporttotal = new System.Windows.Forms.Label();
            this.lblmoneyunit = new System.Windows.Forms.Label();
            this.lblsumtotal = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.label7);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(787, 30);
            this.panel1.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label7.Location = new System.Drawing.Point(4, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(303, 18);
            this.label7.TabIndex = 0;
            this.label7.Text = "THỐNG KÊ - BÁO CÁO KINH DOANH";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rdimexbyyear);
            this.panel2.Controls.Add(this.btnprintlist);
            this.panel2.Controls.Add(this.btndisplay);
            this.panel2.Controls.Add(this.dtpietodate);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.dtpimexdatetime);
            this.panel2.Controls.Add(this.rdimexbyperiod);
            this.panel2.Controls.Add(this.rdimexbymonth);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtimexkeyword);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 30);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(787, 51);
            this.panel2.TabIndex = 3;
            // 
            // rdimexbyyear
            // 
            this.rdimexbyyear.AutoSize = true;
            this.rdimexbyyear.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdimexbyyear.Location = new System.Drawing.Point(59, 1);
            this.rdimexbyyear.Name = "rdimexbyyear";
            this.rdimexbyyear.Size = new System.Drawing.Size(51, 17);
            this.rdimexbyyear.TabIndex = 29;
            this.rdimexbyyear.Text = "Năm";
            this.rdimexbyyear.UseVisualStyleBackColor = true;
            this.rdimexbyyear.CheckedChanged += new System.EventHandler(this.rdimexbymonth_CheckedChanged);
            // 
            // btnprintlist
            // 
            this.btnprintlist.Image = global::CASALE.Properties.Resources.page_white_excel;
            this.btnprintlist.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnprintlist.Location = new System.Drawing.Point(442, 18);
            this.btnprintlist.Name = "btnprintlist";
            this.btnprintlist.Size = new System.Drawing.Size(101, 23);
            this.btnprintlist.TabIndex = 28;
            this.btnprintlist.Text = "Xuất excel";
            this.btnprintlist.UseVisualStyleBackColor = true;
            this.btnprintlist.Click += new System.EventHandler(this.btnprintlist_Click);
            // 
            // btndisplay
            // 
            this.btndisplay.Image = global::CASALE.Properties.Resources.book_blue_view;
            this.btndisplay.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btndisplay.Location = new System.Drawing.Point(343, 18);
            this.btndisplay.Name = "btndisplay";
            this.btndisplay.Size = new System.Drawing.Size(93, 23);
            this.btndisplay.TabIndex = 27;
            this.btndisplay.Text = "Hiển thị";
            this.btndisplay.UseVisualStyleBackColor = true;
            this.btndisplay.Click += new System.EventHandler(this.btndisplay_Click);
            // 
            // dtpietodate
            // 
            this.dtpietodate.CustomFormat = "MM/dd/yyyy";
            this.dtpietodate.Enabled = false;
            this.dtpietodate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpietodate.Location = new System.Drawing.Point(118, 19);
            this.dtpietodate.Name = "dtpietodate";
            this.dtpietodate.Size = new System.Drawing.Size(105, 22);
            this.dtpietodate.TabIndex = 26;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(103, 23);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(12, 13);
            this.label4.TabIndex = 25;
            this.label4.Text = "-";
            // 
            // dtpimexdatetime
            // 
            this.dtpimexdatetime.CustomFormat = "MM/yyyy";
            this.dtpimexdatetime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpimexdatetime.Location = new System.Drawing.Point(3, 19);
            this.dtpimexdatetime.Name = "dtpimexdatetime";
            this.dtpimexdatetime.Size = new System.Drawing.Size(93, 22);
            this.dtpimexdatetime.TabIndex = 24;
            // 
            // rdimexbyperiod
            // 
            this.rdimexbyperiod.AutoSize = true;
            this.rdimexbyperiod.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdimexbyperiod.Location = new System.Drawing.Point(115, 1);
            this.rdimexbyperiod.Name = "rdimexbyperiod";
            this.rdimexbyperiod.Size = new System.Drawing.Size(121, 17);
            this.rdimexbyperiod.TabIndex = 23;
            this.rdimexbyperiod.Text = "Khoảng thời gian";
            this.rdimexbyperiod.UseVisualStyleBackColor = true;
            this.rdimexbyperiod.CheckedChanged += new System.EventHandler(this.rdimexbymonth_CheckedChanged);
            // 
            // rdimexbymonth
            // 
            this.rdimexbymonth.AutoSize = true;
            this.rdimexbymonth.Checked = true;
            this.rdimexbymonth.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdimexbymonth.Location = new System.Drawing.Point(3, 1);
            this.rdimexbymonth.Name = "rdimexbymonth";
            this.rdimexbymonth.Size = new System.Drawing.Size(60, 17);
            this.rdimexbymonth.TabIndex = 22;
            this.rdimexbymonth.TabStop = true;
            this.rdimexbymonth.Text = "Tháng";
            this.rdimexbymonth.UseVisualStyleBackColor = true;
            this.rdimexbymonth.CheckedChanged += new System.EventHandler(this.rdimexbymonth_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(234, 3);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 21;
            this.label3.Text = "Từ khóa";
            // 
            // txtimexkeyword
            // 
            this.txtimexkeyword.Location = new System.Drawing.Point(237, 19);
            this.txtimexkeyword.Name = "txtimexkeyword";
            this.txtimexkeyword.Size = new System.Drawing.Size(100, 22);
            this.txtimexkeyword.TabIndex = 20;
            // 
            // lvitems
            // 
            this.lvitems.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.stt,
            this.time,
            this.imp,
            this.xm,
            this.total});
            this.lvitems.Dock = System.Windows.Forms.DockStyle.Top;
            this.lvitems.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvitems.FullRowSelect = true;
            this.lvitems.GridLines = true;
            this.lvitems.Location = new System.Drawing.Point(0, 81);
            this.lvitems.MultiSelect = false;
            this.lvitems.Name = "lvitems";
            this.lvitems.Size = new System.Drawing.Size(787, 347);
            this.lvitems.TabIndex = 4;
            this.lvitems.UseCompatibleStateImageBehavior = false;
            this.lvitems.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Width = 0;
            // 
            // stt
            // 
            this.stt.Text = "STT";
            this.stt.Width = 50;
            // 
            // time
            // 
            this.time.Text = "Thời gian";
            this.time.Width = 148;
            // 
            // imp
            // 
            this.imp.Text = "Nhập vào(-)";
            this.imp.Width = 148;
            // 
            // xm
            // 
            this.xm.Text = "Bán (+)";
            this.xm.Width = 144;
            // 
            // total
            // 
            this.total.Text = "Tổng";
            this.total.Width = 140;
            // 
            // lblmoneyunit1
            // 
            this.lblmoneyunit1.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblmoneyunit1.Location = new System.Drawing.Point(320, 433);
            this.lblmoneyunit1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmoneyunit1.Name = "lblmoneyunit1";
            this.lblmoneyunit1.Size = new System.Drawing.Size(36, 18);
            this.lblmoneyunit1.TabIndex = 29;
            this.lblmoneyunit1.Text = "VNĐ";
            // 
            // lblsumimporttotal
            // 
            this.lblsumimporttotal.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblsumimporttotal.Location = new System.Drawing.Point(205, 431);
            this.lblsumimporttotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsumimporttotal.Name = "lblsumimporttotal";
            this.lblsumimporttotal.Size = new System.Drawing.Size(117, 18);
            this.lblsumimporttotal.TabIndex = 28;
            this.lblsumimporttotal.Text = "0";
            this.lblsumimporttotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblmoneyunit2
            // 
            this.lblmoneyunit2.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblmoneyunit2.Location = new System.Drawing.Point(467, 433);
            this.lblmoneyunit2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmoneyunit2.Name = "lblmoneyunit2";
            this.lblmoneyunit2.Size = new System.Drawing.Size(36, 18);
            this.lblmoneyunit2.TabIndex = 27;
            this.lblmoneyunit2.Text = "VNĐ";
            // 
            // lblsumexporttotal
            // 
            this.lblsumexporttotal.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblsumexporttotal.Location = new System.Drawing.Point(358, 431);
            this.lblsumexporttotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsumexporttotal.Name = "lblsumexporttotal";
            this.lblsumexporttotal.Size = new System.Drawing.Size(109, 18);
            this.lblsumexporttotal.TabIndex = 26;
            this.lblsumexporttotal.Text = "0";
            this.lblsumexporttotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblmoneyunit
            // 
            this.lblmoneyunit.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblmoneyunit.Location = new System.Drawing.Point(645, 433);
            this.lblmoneyunit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmoneyunit.Name = "lblmoneyunit";
            this.lblmoneyunit.Size = new System.Drawing.Size(36, 18);
            this.lblmoneyunit.TabIndex = 25;
            this.lblmoneyunit.Text = "VNĐ";
            // 
            // lblsumtotal
            // 
            this.lblsumtotal.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblsumtotal.Location = new System.Drawing.Point(501, 431);
            this.lblsumtotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsumtotal.Name = "lblsumtotal";
            this.lblsumtotal.Size = new System.Drawing.Size(144, 18);
            this.lblsumtotal.TabIndex = 24;
            this.lblsumtotal.Text = "0";
            this.lblsumtotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frmReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(787, 481);
            this.Controls.Add(this.lblmoneyunit1);
            this.Controls.Add(this.lblsumimporttotal);
            this.Controls.Add(this.lblmoneyunit2);
            this.Controls.Add(this.lblsumexporttotal);
            this.Controls.Add(this.lblmoneyunit);
            this.Controls.Add(this.lblsumtotal);
            this.Controls.Add(this.lvitems);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "frmReport";
            this.Text = "Báo cáo";
            this.Load += new System.EventHandler(this.frmReport_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.lvitems, 0);
            this.Controls.SetChildIndex(this.lblsumtotal, 0);
            this.Controls.SetChildIndex(this.lblmoneyunit, 0);
            this.Controls.SetChildIndex(this.lblsumexporttotal, 0);
            this.Controls.SetChildIndex(this.lblmoneyunit2, 0);
            this.Controls.SetChildIndex(this.lblsumimporttotal, 0);
            this.Controls.SetChildIndex(this.lblmoneyunit1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rdimexbyyear;
        private System.Windows.Forms.Button btnprintlist;
        private System.Windows.Forms.Button btndisplay;
        private System.Windows.Forms.DateTimePicker dtpietodate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpimexdatetime;
        private System.Windows.Forms.RadioButton rdimexbyperiod;
        private System.Windows.Forms.RadioButton rdimexbymonth;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtimexkeyword;
        private System.Windows.Forms.ListView lvitems;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader stt;
        private System.Windows.Forms.ColumnHeader time;
        private System.Windows.Forms.ColumnHeader imp;
        private System.Windows.Forms.ColumnHeader xm;
        private System.Windows.Forms.ColumnHeader total;
        private System.Windows.Forms.Label lblmoneyunit1;
        private System.Windows.Forms.Label lblsumimporttotal;
        private System.Windows.Forms.Label lblmoneyunit2;
        private System.Windows.Forms.Label lblsumexporttotal;
        private System.Windows.Forms.Label lblmoneyunit;
        private System.Windows.Forms.Label lblsumtotal;
    }
}