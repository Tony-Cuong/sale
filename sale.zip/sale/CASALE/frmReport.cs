﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CASALE.Class;
using LCProductCartUtiliti;
using OfficeUtilities;

namespace CASALE
{
    public partial class frmReport : templates
    {
        int idaytype = 1; // nhóm theo ngày (thống kê tháng)
        string datetypetype = "";// dung trong in ấn
        string datetypevalue = ""; // dùng trong in ấn
        public frmReport()
        {
            InitializeComponent();
        }

        private void frmReport_Load(object sender, EventArgs e)
        {
            dtpimexdatetime.Value = DateTime.Now;
            dtpietodate.Value = DateTime.Now;
            lblmoneyunit.Text = Common.MoneyUnit;
            lblmoneyunit1.Text = Common.MoneyUnit;
            lblmoneyunit2.Text = Common.MoneyUnit;
            LoadSaleReportList();
        }
        void LoadRadioDayTypeCheck()
        {
            dtpietodate.Enabled = false;
            if (rdimexbymonth.Checked == true)
            {
                dtpimexdatetime.Format = DateTimePickerFormat.Custom;
                dtpimexdatetime.CustomFormat = "MM/yyyy";
                idaytype = 1;
                datetypetype = " THÁNG ";

            }
            else if (rdimexbyyear.Checked == true)
            {
                dtpimexdatetime.Format = DateTimePickerFormat.Custom;
                dtpimexdatetime.CustomFormat = "yyyy";
                idaytype = 0;
                datetypetype = " NĂM ";

            }
            else if (rdimexbyperiod.Checked == true)
            {
                dtpimexdatetime.Format = DateTimePickerFormat.Custom;
                dtpimexdatetime.CustomFormat = "dd/MM/yyyy";
                dtpietodate.CustomFormat = "dd/MM/yyyy";
                dtpietodate.Enabled = true;
                idaytype = 3;
                datetypetype = " TRONG THỜI GIAN ";
            }
        }
        private void btndisplay_Click(object sender, EventArgs e)
        {
            LoadSaleReportList();
        }
        string UserName(string senderparams)
        {
            string[] prs = senderparams.Split('|');
            if (prs.Length > 1)
            {
                return prs[1];
            }
            return prs[0];
        }
        void LoadSaleReportList()
        {
            DataTable dtimportsalereport = new DataTable();
            DataTable dtexportsalereport = new DataTable();

            string sql = "";
            /// lấy báo cáo nhập
            dtimportsalereport = ImportExport.sale_objects_importexport_report(
                1, idaytype, dtpimexdatetime.Value,
                dtpietodate.Value,
                "",
                Common.ConnectionString);
            /// lấy báo cáo xuất.
            dtexportsalereport = ImportExport.sale_objects_importexport_report(
                0, idaytype, dtpimexdatetime.Value,
                dtpietodate.Value,
                "",
                Common.ConnectionString);


            //MessageBox.Show(dtimportsalereport.Rows.Count.ToString());

            lvitems.Items.Clear();

            double sumtotal = 0;
            double sumimtotal = 0;
            double sumextotal = 0;

            if (idaytype != 3)
            {
                int count = DateTime.DaysInMonth(dtpimexdatetime.Value.Year, dtpimexdatetime.Value.Month);
                if (idaytype == 0) // nhóm theo năm.
                    count = 12;

                for (int i = 0; i < count; i++)
                {
                    ListViewItem lvi = new ListViewItem(i.ToString());
                    lvi.SubItems.Add((i + 1).ToString());
                    if (idaytype == 0)// theo năm
                    {
                        lvi.SubItems.Add("Tháng " + (i + 1).ToString());
                    }
                    else if (idaytype == 1 || idaytype == 3)// theo tháng hoặc khoảng thời gian
                    {
                        lvi.SubItems.Add("Ngày " + (i + 1).ToString());
                    }
                    double dbimtotal = 0;
                    if (idaytype == 0)
                    {
                        dbimtotal = Convert.ToDouble(GetImportExportItem(
                             dtpimexdatetime.Value.Year,
                             i + 1,
                             i + 1, ref dtimportsalereport));
                    }
                    else
                    {
                        dbimtotal = Convert.ToDouble(GetImportExportItem(
                            dtpimexdatetime.Value.Year,
                            dtpimexdatetime.Value.Month,
                            i + 1, ref dtimportsalereport));
                    }
                    lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dbimtotal.ToString()));

                    double dbextotal = 0;
                    if (idaytype == 0)
                    {
                        dbextotal = Convert.ToDouble(GetImportExportItem(
                             dtpimexdatetime.Value.Year,
                             i + 1,
                             i + 1, ref dtexportsalereport));
                    }
                    else
                    {
                        dbextotal = Convert.ToDouble(GetImportExportItem(
                            dtpimexdatetime.Value.Year,
                            dtpimexdatetime.Value.Month,
                            i + 1, ref dtexportsalereport));
                    }

                    lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dbextotal.ToString()));

                    double dbtotal = dbextotal - dbimtotal;
                    lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dbtotal.ToString()));
                    lvitems.Items.Add(lvi);

                    sumimtotal += dbimtotal;
                    sumextotal += dbextotal;
                    sumtotal += dbtotal;
                }
            }
            else
            {
                int count = 1;
                DateTime dttemp = dtpimexdatetime.Value;
                while (dttemp < dtpietodate.Value)
                {
                    ListViewItem lvi = new ListViewItem("-1");
                    lvi.SubItems.Add(count.ToString());
                    lvi.SubItems.Add("Ngày " + dttemp.Day.ToString() + "/" + dttemp.Month.ToString() + " " + dttemp.Year.ToString());

                    double dbimtotal = Convert.ToDouble(GetImportExportItem(
                        dttemp.Year,
                        dttemp.Month,
                        dttemp.Day, ref dtimportsalereport));
                    lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dbimtotal.ToString()));

                    double dbextotal = Convert.ToDouble(GetImportExportItem(
                        dttemp.Year,
                        dttemp.Month,
                        dttemp.Day, ref dtexportsalereport));
                    lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dbextotal.ToString()));

                    double dbtotal = dbextotal - dbimtotal;
                    lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dbtotal.ToString()));
                    lvitems.Items.Add(lvi);

                    sumimtotal += dbimtotal;
                    sumextotal += dbextotal;
                    sumtotal += dbtotal;

                    count++;
                    dttemp = dttemp.AddDays(1);
                }
            }

            lblsumexporttotal.Text = LCUtiliti.ConvertNumber.FomatPrice(sumextotal.ToString());
            lblsumimporttotal.Text = LCUtiliti.ConvertNumber.FomatPrice(sumimtotal.ToString());
            lblsumtotal.Text = LCUtiliti.ConvertNumber.FomatPrice(sumtotal.ToString());

        }

        Object GetImportExportItem(int year, int month, int day, ref DataTable dtimportexport)
        {
            DataRow[] drs = null;
            if (idaytype == 0)
                drs = dtimportexport.Select("yyyy=" + year.ToString() + " and MM=" + month.ToString());
            else if (idaytype == 1 || idaytype == 3)
            {
                drs = dtimportexport.Select("yyyy=" + year.ToString() + " and MM=" + month.ToString() + " and dd=" + day.ToString());
            }

            if (drs != null)
            {
                if (drs.Length > 0)
                {
                    //MessageBox.Show(idaytype.ToString() + " " +year.ToString() + " " + month.ToString() + " " + day.ToString() + " "  + drs[0]["ftotal"].ToString());

                    return drs[0]["ftotal"];
                }

            }
            return 0;
        }


        private void rdimexbymonth_CheckedChanged(object sender, EventArgs e)
        {
            LoadRadioDayTypeCheck();
        }

        private void btnprintlist_Click(object sender, EventArgs e)
        {
            ExcelUtilities.ExportListViewToExcel(ref lvitems);
        }
    }
}
