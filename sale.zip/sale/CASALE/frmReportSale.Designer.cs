﻿using CASALE.Class;
namespace CASALE
{
    partial class frmReportSale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.frmreportsale = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbltitle = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rdtimebydate = new System.Windows.Forms.RadioButton();
            this.rdimexbyyear = new System.Windows.Forms.RadioButton();
            this.dtpietodate = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpimexdatetime = new System.Windows.Forms.DateTimePicker();
            this.rdimexbyperiod = new System.Windows.Forms.RadioButton();
            this.rdimexbymonth = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.txtimexkeyword = new System.Windows.Forms.TextBox();
            this.lvitems = new System.Windows.Forms.ListView();
            this.id = new System.Windows.Forms.ColumnHeader();
            this.stt = new System.Windows.Forms.ColumnHeader();
            this.key = new System.Windows.Forms.ColumnHeader();
            this.name = new System.Windows.Forms.ColumnHeader();
            this.dv = new System.Windows.Forms.ColumnHeader();
            this.price = new System.Windows.Forms.ColumnHeader();
            this.slnhap = new System.Windows.Forms.ColumnHeader();
            this.totalmn = new System.Windows.Forms.ColumnHeader();
            this.slban = new System.Windows.Forms.ColumnHeader();
            this.totalb = new System.Windows.Forms.ColumnHeader();
            this.total = new System.Windows.Forms.ColumnHeader();
            this.lbltong = new System.Windows.Forms.Label();
            this.lblttban = new System.Windows.Forms.Label();
            this.lblslban = new System.Windows.Forms.Label();
            this.lblnumofitems = new System.Windows.Forms.Label();
            this.lblslnhap = new System.Windows.Forms.Label();
            this.lbltotalim = new System.Windows.Forms.Label();
            this.btnprintlist = new System.Windows.Forms.Button();
            this.btndisplay = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.lbltitle);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(914, 30);
            this.panel1.TabIndex = 2;
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbltitle.Location = new System.Drawing.Point(4, 7);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(178, 18);
            this.lbltitle.TabIndex = 0;
            this.lbltitle.Text = "BÁO CÁO HÀNG BÁN";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rdtimebydate);
            this.panel2.Controls.Add(this.rdimexbyyear);
            this.panel2.Controls.Add(this.btnprintlist);
            this.panel2.Controls.Add(this.btndisplay);
            this.panel2.Controls.Add(this.dtpietodate);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.dtpimexdatetime);
            this.panel2.Controls.Add(this.rdimexbyperiod);
            this.panel2.Controls.Add(this.rdimexbymonth);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtimexkeyword);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 30);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(914, 43);
            this.panel2.TabIndex = 3;
            // 
            // rdtimebydate
            // 
            this.rdtimebydate.AutoSize = true;
            this.rdtimebydate.Checked = true;
            this.rdtimebydate.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdtimebydate.Location = new System.Drawing.Point(11, 2);
            this.rdtimebydate.Name = "rdtimebydate";
            this.rdtimebydate.Size = new System.Drawing.Size(54, 17);
            this.rdtimebydate.TabIndex = 52;
            this.rdtimebydate.TabStop = true;
            this.rdtimebydate.Text = "Ngày";
            this.rdtimebydate.UseVisualStyleBackColor = true;
            this.rdtimebydate.CheckedChanged += new System.EventHandler(this.rdtimebydate_CheckedChanged);
            // 
            // rdimexbyyear
            // 
            this.rdimexbyyear.AutoSize = true;
            this.rdimexbyyear.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdimexbyyear.Location = new System.Drawing.Point(130, 2);
            this.rdimexbyyear.Name = "rdimexbyyear";
            this.rdimexbyyear.Size = new System.Drawing.Size(51, 17);
            this.rdimexbyyear.TabIndex = 51;
            this.rdimexbyyear.Text = "Năm";
            this.rdimexbyyear.UseVisualStyleBackColor = true;
            this.rdimexbyyear.CheckedChanged += new System.EventHandler(this.rdtimebydate_CheckedChanged);
            // 
            // dtpietodate
            // 
            this.dtpietodate.CustomFormat = "MM/dd/yyyy";
            this.dtpietodate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpietodate.Location = new System.Drawing.Point(127, 19);
            this.dtpietodate.Name = "dtpietodate";
            this.dtpietodate.Size = new System.Drawing.Size(105, 22);
            this.dtpietodate.TabIndex = 48;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(112, 23);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(12, 13);
            this.label4.TabIndex = 47;
            this.label4.Text = "-";
            // 
            // dtpimexdatetime
            // 
            this.dtpimexdatetime.CustomFormat = "dd/MM/yyyy";
            this.dtpimexdatetime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpimexdatetime.Location = new System.Drawing.Point(12, 19);
            this.dtpimexdatetime.Name = "dtpimexdatetime";
            this.dtpimexdatetime.Size = new System.Drawing.Size(93, 22);
            this.dtpimexdatetime.TabIndex = 46;
            // 
            // rdimexbyperiod
            // 
            this.rdimexbyperiod.AutoSize = true;
            this.rdimexbyperiod.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdimexbyperiod.Location = new System.Drawing.Point(186, 2);
            this.rdimexbyperiod.Name = "rdimexbyperiod";
            this.rdimexbyperiod.Size = new System.Drawing.Size(121, 17);
            this.rdimexbyperiod.TabIndex = 45;
            this.rdimexbyperiod.Text = "Khoảng thời gian";
            this.rdimexbyperiod.UseVisualStyleBackColor = true;
            this.rdimexbyperiod.CheckedChanged += new System.EventHandler(this.rdtimebydate_CheckedChanged);
            // 
            // rdimexbymonth
            // 
            this.rdimexbymonth.AutoSize = true;
            this.rdimexbymonth.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdimexbymonth.Location = new System.Drawing.Point(74, 2);
            this.rdimexbymonth.Name = "rdimexbymonth";
            this.rdimexbymonth.Size = new System.Drawing.Size(60, 17);
            this.rdimexbymonth.TabIndex = 44;
            this.rdimexbymonth.Text = "Tháng";
            this.rdimexbymonth.UseVisualStyleBackColor = true;
            this.rdimexbymonth.CheckedChanged += new System.EventHandler(this.rdtimebydate_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(307, 3);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 43;
            this.label3.Text = "Từ khóa";
            // 
            // txtimexkeyword
            // 
            this.txtimexkeyword.Location = new System.Drawing.Point(306, 19);
            this.txtimexkeyword.Name = "txtimexkeyword";
            this.txtimexkeyword.Size = new System.Drawing.Size(181, 22);
            this.txtimexkeyword.TabIndex = 42;
            // 
            // lvitems
            // 
            this.lvitems.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.id,
            this.stt,
            this.key,
            this.name,
            this.dv,
            this.price,
            this.slnhap,
            this.totalmn,
            this.slban,
            this.totalb,
            this.total});
            this.lvitems.Dock = System.Windows.Forms.DockStyle.Top;
            this.lvitems.FullRowSelect = true;
            this.lvitems.GridLines = true;
            this.lvitems.Location = new System.Drawing.Point(0, 73);
            this.lvitems.Name = "lvitems";
            this.lvitems.Size = new System.Drawing.Size(914, 478);
            this.lvitems.TabIndex = 4;
            this.lvitems.UseCompatibleStateImageBehavior = false;
            this.lvitems.View = System.Windows.Forms.View.Details;
            // 
            // id
            // 
            this.id.Text = "";
            this.id.Width = 0;
            // 
            // stt
            // 
            this.stt.Text = "STT";
            this.stt.Width = 39;
            // 
            // key
            // 
            this.key.Text = "Mã sản phẩm";
            this.key.Width = 98;
            // 
            // name
            // 
            this.name.Text = "Tên sản phẩm";
            this.name.Width = 154;
            // 
            // dv
            // 
            this.dv.Text = "Đ.Vị";
            this.dv.Width = 54;
            // 
            // price
            // 
            this.price.Text = "Giá bán";
            this.price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.price.Width = 101;
            // 
            // slnhap
            // 
            this.slnhap.Text = "S.L Nhập";
            this.slnhap.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.slnhap.Width = 74;
            // 
            // totalmn
            // 
            this.totalmn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.totalmn.Width = 110;
            // 
            // slban
            // 
            this.slban.Text = "S.L Bán";
            this.slban.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.slban.Width = 54;
            // 
            // totalb
            // 
            this.totalb.Text = "Tổng tiền bán";
            this.totalb.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.totalb.Width = 106;
            // 
            // total
            // 
            this.total.Text = "Tổng";
            this.total.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.total.Width = 106;
            // 
            // lbltong
            // 
            this.lbltong.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbltong.Location = new System.Drawing.Point(802, 553);
            this.lbltong.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltong.Name = "lbltong";
            this.lbltong.Size = new System.Drawing.Size(99, 18);
            this.lbltong.TabIndex = 57;
            this.lbltong.Text = "0";
            this.lbltong.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblttban
            // 
            this.lblttban.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblttban.Location = new System.Drawing.Point(701, 554);
            this.lblttban.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblttban.Name = "lblttban";
            this.lblttban.Size = new System.Drawing.Size(93, 18);
            this.lblttban.TabIndex = 56;
            this.lblttban.Text = "0";
            this.lblttban.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblslban
            // 
            this.lblslban.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblslban.Location = new System.Drawing.Point(634, 554);
            this.lblslban.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblslban.Name = "lblslban";
            this.lblslban.Size = new System.Drawing.Size(59, 18);
            this.lblslban.TabIndex = 55;
            this.lblslban.Text = "0";
            this.lblslban.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblnumofitems
            // 
            this.lblnumofitems.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblnumofitems.Location = new System.Drawing.Point(4, 554);
            this.lblnumofitems.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblnumofitems.Name = "lblnumofitems";
            this.lblnumofitems.Size = new System.Drawing.Size(306, 18);
            this.lblnumofitems.TabIndex = 54;
            this.lblnumofitems.Text = "0";
            this.lblnumofitems.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblslnhap
            // 
            this.lblslnhap.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblslnhap.Location = new System.Drawing.Point(442, 554);
            this.lblslnhap.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblslnhap.Name = "lblslnhap";
            this.lblslnhap.Size = new System.Drawing.Size(76, 18);
            this.lblslnhap.TabIndex = 53;
            this.lblslnhap.Text = "0";
            this.lblslnhap.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbltotalim
            // 
            this.lbltotalim.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbltotalim.Location = new System.Drawing.Point(525, 554);
            this.lbltotalim.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltotalim.Name = "lbltotalim";
            this.lbltotalim.Size = new System.Drawing.Size(111, 18);
            this.lbltotalim.TabIndex = 52;
            this.lbltotalim.Text = "0";
            this.lbltotalim.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnprintlist
            // 
            this.btnprintlist.Image = global::CASALE.Properties.Resources.page_white_excel;
            this.btnprintlist.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnprintlist.Location = new System.Drawing.Point(577, 18);
            this.btnprintlist.Name = "btnprintlist";
            this.btnprintlist.Size = new System.Drawing.Size(100, 23);
            this.btnprintlist.TabIndex = 50;
            this.btnprintlist.Text = "Xuất excel";
            this.btnprintlist.UseVisualStyleBackColor = true;
            this.btnprintlist.Click += new System.EventHandler(this.btnprintlist_Click);
            // 
            // btndisplay
            // 
            this.btndisplay.Image = global::CASALE.Properties.Resources.book_blue_view;
            this.btndisplay.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btndisplay.Location = new System.Drawing.Point(493, 18);
            this.btndisplay.Name = "btndisplay";
            this.btndisplay.Size = new System.Drawing.Size(83, 23);
            this.btndisplay.TabIndex = 49;
            this.btndisplay.Text = "Hiển thị";
            this.btndisplay.UseVisualStyleBackColor = true;
            this.btndisplay.Click += new System.EventHandler(this.btndisplay_Click);
            // 
            // frmReportSale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 597);
            this.Controls.Add(this.lbltong);
            this.Controls.Add(this.lblttban);
            this.Controls.Add(this.lblslban);
            this.Controls.Add(this.lblnumofitems);
            this.Controls.Add(this.lblslnhap);
            this.Controls.Add(this.lbltotalim);
            this.Controls.Add(this.lvitems);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.MaximizeBox = false;
            this.Name = "frmReportSale";
            this.Text = "Báo cáo";
            this.Load += new System.EventHandler(this.frmReportSale_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.lvitems, 0);
            this.Controls.SetChildIndex(this.lbltotalim, 0);
            this.Controls.SetChildIndex(this.lblslnhap, 0);
            this.Controls.SetChildIndex(this.lblnumofitems, 0);
            this.Controls.SetChildIndex(this.lblslban, 0);
            this.Controls.SetChildIndex(this.lblttban, 0);
            this.Controls.SetChildIndex(this.lbltong, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbltitle;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rdtimebydate;
        private System.Windows.Forms.RadioButton rdimexbyyear;
        private System.Windows.Forms.Button btnprintlist;
        private System.Windows.Forms.Button btndisplay;
        private System.Windows.Forms.DateTimePicker dtpietodate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpimexdatetime;
        private System.Windows.Forms.RadioButton rdimexbyperiod;
        private System.Windows.Forms.RadioButton rdimexbymonth;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtimexkeyword;
        private System.Windows.Forms.ListView lvitems;
        private System.Windows.Forms.ColumnHeader id;
        private System.Windows.Forms.ColumnHeader stt;
        private System.Windows.Forms.ColumnHeader key;
        private System.Windows.Forms.ColumnHeader name;
        private System.Windows.Forms.ColumnHeader dv;
        private System.Windows.Forms.ColumnHeader price;
        private System.Windows.Forms.ColumnHeader slnhap;
        private System.Windows.Forms.ColumnHeader totalmn;
        private System.Windows.Forms.ColumnHeader slban;
        private System.Windows.Forms.ColumnHeader totalb;
        private System.Windows.Forms.ColumnHeader total;
        private System.Windows.Forms.Label lbltong;
        private System.Windows.Forms.Label lblttban;
        private System.Windows.Forms.Label lblslban;
        private System.Windows.Forms.Label lblnumofitems;
        private System.Windows.Forms.Label lblslnhap;
        private System.Windows.Forms.Label lbltotalim;
    }
}