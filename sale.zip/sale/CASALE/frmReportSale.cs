﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LCProductCartUtiliti;
using CASALE.Class;
using OfficeUtilities;

namespace CASALE
{
    public partial class frmReportSale : templates
    {
        int idaytype = 1; // nhóm theo ngày (thống kê tháng)
        string datetypetype = "";// dung trong in ấn
        string datetypevalue = ""; // dùng trong in ấn

        public frmReportSale()
        {
            InitializeComponent();
        }

        private void frmReportSale_Load(object sender, EventArgs e)
        {
            LoadRadioDayTypeCheck();
            LoadSaleReportList();
        }
        void LoadRadioDayTypeCheck()
        {
            dtpietodate.Enabled = false;
            if (rdtimebydate.Checked == true)
            {
                dtpimexdatetime.Format = DateTimePickerFormat.Custom;
                dtpimexdatetime.CustomFormat = "dd/MM/yyyy";
                idaytype = 2;
                datetypetype = " NGÀY ";
            }
            else if (rdimexbymonth.Checked == true)
            {
                dtpimexdatetime.Format = DateTimePickerFormat.Custom;
                dtpimexdatetime.CustomFormat = "MM/yyyy";
                idaytype = 0;
                datetypetype = " THÁNG ";
            }
            else if (rdimexbyyear.Checked == true)
            {
                dtpimexdatetime.Format = DateTimePickerFormat.Custom;
                dtpimexdatetime.CustomFormat = "yyyy";
                idaytype = 1;
                datetypetype = " NĂM ";
            }
            else if (rdimexbyperiod.Checked == true)
            {
                dtpimexdatetime.Format = DateTimePickerFormat.Custom;
                dtpimexdatetime.CustomFormat = "dd/MM/yyyy";
                dtpietodate.CustomFormat = "dd/MM/yyyy";
                dtpietodate.Enabled = true;
                idaytype = 3;
                datetypetype = " TRONG THỜI GIAN ";
            }
        }
        string UserName(string senderparams)
        {
            string[] prs = senderparams.Split('|');
            if (prs.Length > 1)
            {
                return prs[1];
            }
            return prs[0];
        }
        void LoadSaleReportList()
        {
            DataTable dtreport = new DataTable();
            dtreport = Cart.getproduct(idaytype, dtpimexdatetime.Value,
            dtpietodate.Value, Common.ConnectionString);

            lvitems.Items.Clear();


            double sumtotal = 0;
            double sumextotal = 0;
            double tongxuat = 0;
            double tongton = 0;
            int slban = 0;
            int slton = 0;
            for (int i = 0; i < dtreport.Rows.Count; i++)
            {

                ListViewItem lvi = new ListViewItem("-1");
                lvi.SubItems.Add((i + 1).ToString());
                lvi.SubItems.Add(dtreport.Rows[i]["vproductkey"].ToString());
                lvi.SubItems.Add(dtreport.Rows[i]["vproductname"].ToString());
                lvi.SubItems.Add(dtreport.Rows[i]["vproductunit"].ToString());
                //lvi.SubItems.Add("");
                lvi.SubItems.Add(dtreport.Rows[i]["vprice"].ToString());//gia

                lvi.SubItems.Add(dtreport.Rows[i]["totalimquantity"].ToString());//tong nhap
                slton += (Convert.ToInt32(dtreport.Rows[i]["totalimquantity"]));

                lvi.SubItems.Add(dtreport.Rows[i]["totalimvalue"].ToString());
                sumextotal += (Convert.ToDouble(dtreport.Rows[i]["totalimvalue"]));

                lvi.SubItems.Add(dtreport.Rows[i]["totalexquantity"].ToString());//tong ban
                slban += (Convert.ToInt32(dtreport.Rows[i]["totalexquantity"]));

                lvi.SubItems.Add(dtreport.Rows[i]["totalexvalue"].ToString());
                tongxuat += Convert.ToDouble(dtreport.Rows[i]["totalexvalue"]);

                lvi.SubItems.Add((Convert.ToDouble(dtreport.Rows[i]["totalexvalue"]) - (Convert.ToDouble(dtreport.Rows[i]["totalimvalue"]))).ToString());//tong ton
                tongton += (Convert.ToDouble(dtreport.Rows[i]["totalexvalue"]) - (Convert.ToDouble(dtreport.Rows[i]["totalimvalue"])));
                lvitems.Items.Add(lvi);
            }


            lblttban.Text = tongxuat.ToString();
            lblslnhap.Text = sumextotal.ToString();

            lblnumofitems.Text = dtreport.Rows.Count.ToString() + " mục hiển thị";

            lblslban.Text = slban.ToString();
            lblslnhap.Text = slton.ToString();

            lbltong.Text = tongton.ToString();
            lbltotalim.Text = sumextotal.ToString();
        }
        Object GetImportItem(int year, int month, int day, ref DataTable dtimport)
        {
            DataRow[] drs = null;
            if (idaytype == 0)
                drs = dtimport.Select("MM=" + month.ToString());
            else if (idaytype == 1 || idaytype == 3)
            {
                drs = dtimport.Select("yyyy=" + year.ToString() + " and MM=" + month.ToString() + " and dd=" + day.ToString());
            }

            if (drs != null)
            {
                if (drs.Length > 0)
                {
                    return drs[0]["ftotal"];
                }
            }
            return 0;
        }
        private void btndisplay_Click(object sender, EventArgs e)
        {
            LoadSaleReportList();
        }

        private void rdtimebydate_CheckedChanged(object sender, EventArgs e)
        {
            LoadRadioDayTypeCheck();
        }

        private void btnprintlist_Click(object sender, EventArgs e)
        {
            ExcelUtilities.ExportListViewToExcel(ref lvitems);
        }
    }
}
