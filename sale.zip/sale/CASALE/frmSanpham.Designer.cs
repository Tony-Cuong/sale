﻿using CASALE.Class;
namespace CASALE
{
    partial class frmSanpham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.frmsanpham = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Tất cả sản phẩm");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Nhóm 1...");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSanpham));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.pnAddCategory = new System.Windows.Forms.Panel();
            this.lblsl = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCateOrder = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCateName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnHuyCategory = new System.Windows.Forms.Button();
            this.btnLuuCate = new System.Windows.Forms.Button();
            this.trvcategories = new System.Windows.Forms.TreeView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmnedit = new System.Windows.Forms.ToolStripMenuItem();
            this.cmncreate = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.cmndelete = new System.Windows.Forms.ToolStripMenuItem();
            this.lblTotalCategory = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lnkcategorycreatenew = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.pnAddProduct = new System.Windows.Forms.Panel();
            this.cboUnit = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtproductdesc = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtitemorder = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.lblmoneyunit = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.utondauky = new System.Windows.Forms.NumericUpDown();
            this.nudThue = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.lblMsg = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbdetailcategories = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnHuyProduct = new System.Windows.Forms.Button();
            this.btnLuuProduct = new System.Windows.Forms.Button();
            this.txtGia = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtItemName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtcode = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pnprintproductbarcode = new System.Windows.Forms.Panel();
            this.txtprintbcproprice = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.nuprintbcitems = new System.Windows.Forms.NumericUpDown();
            this.pnprintbcpropreview = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.btnprintbccancel = new System.Windows.Forms.Button();
            this.btnprintbcprintbarcodes = new System.Windows.Forms.Button();
            this.txtprintbcproname = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtprintbcprocode = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.btnprintnoall = new System.Windows.Forms.Button();
            this.btnprintall = new System.Windows.Forms.Button();
            this.lblTotalProduct = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lvListProduct = new System.Windows.Forms.ListView();
            this.ID = new System.Windows.Forms.ColumnHeader();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader7 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader8 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader6 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader9 = new System.Windows.Forms.ColumnHeader();
            this.cmnProduct = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmnUpdateProduct = new System.Windows.Forms.ToolStripMenuItem();
            this.cmnuproductprintbarcode = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.cmnDeleteProduct = new System.Windows.Forms.ToolStripMenuItem();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnsyndataonline = new System.Windows.Forms.Button();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument2 = new System.Drawing.Printing.PrintDocument();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.pnAddCategory.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pnAddProduct.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.utondauky)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudThue)).BeginInit();
            this.pnprintproductbarcode.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nuprintbcitems)).BeginInit();
            this.panel5.SuspendLayout();
            this.cmnProduct.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.pnAddCategory);
            this.splitContainer1.Panel1.Controls.Add(this.trvcategories);
            this.splitContainer1.Panel1.Controls.Add(this.lblTotalCategory);
            this.splitContainer1.Panel1.Controls.Add(this.label10);
            this.splitContainer1.Panel1.Controls.Add(this.panel3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.label24);
            this.splitContainer1.Panel2.Controls.Add(this.pnAddProduct);
            this.splitContainer1.Panel2.Controls.Add(this.pnprintproductbarcode);
            this.splitContainer1.Panel2.Controls.Add(this.btnprintnoall);
            this.splitContainer1.Panel2.Controls.Add(this.btnprintall);
            this.splitContainer1.Panel2.Controls.Add(this.lblTotalProduct);
            this.splitContainer1.Panel2.Controls.Add(this.label9);
            this.splitContainer1.Panel2.Controls.Add(this.lvListProduct);
            this.splitContainer1.Panel2.Controls.Add(this.panel2);
            this.splitContainer1.Size = new System.Drawing.Size(1254, 625);
            this.splitContainer1.SplitterDistance = 254;
            this.splitContainer1.SplitterWidth = 6;
            this.splitContainer1.TabIndex = 2;
            // 
            // pnAddCategory
            // 
            this.pnAddCategory.Controls.Add(this.lblsl);
            this.pnAddCategory.Controls.Add(this.label8);
            this.pnAddCategory.Controls.Add(this.txtCateOrder);
            this.pnAddCategory.Controls.Add(this.label7);
            this.pnAddCategory.Controls.Add(this.txtCateName);
            this.pnAddCategory.Controls.Add(this.label2);
            this.pnAddCategory.Controls.Add(this.btnHuyCategory);
            this.pnAddCategory.Controls.Add(this.btnLuuCate);
            this.pnAddCategory.Location = new System.Drawing.Point(4, 41);
            this.pnAddCategory.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnAddCategory.Name = "pnAddCategory";
            this.pnAddCategory.Size = new System.Drawing.Size(266, 213);
            this.pnAddCategory.TabIndex = 2;
            this.pnAddCategory.Visible = false;
            // 
            // lblsl
            // 
            this.lblsl.AutoSize = true;
            this.lblsl.Location = new System.Drawing.Point(141, 134);
            this.lblsl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsl.Name = "lblsl";
            this.lblsl.Size = new System.Drawing.Size(18, 19);
            this.lblsl.TabIndex = 28;
            this.lblsl.Text = "0";
            this.lblsl.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.Location = new System.Drawing.Point(4, 18);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(220, 18);
            this.label8.TabIndex = 27;
            this.label8.Text = "Thông tin nhóm sản phẩm";
            // 
            // txtCateOrder
            // 
            this.txtCateOrder.Location = new System.Drawing.Point(19, 134);
            this.txtCateOrder.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCateOrder.Name = "txtCateOrder";
            this.txtCateOrder.Size = new System.Drawing.Size(94, 26);
            this.txtCateOrder.TabIndex = 26;
            this.txtCateOrder.Text = "1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 113);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 19);
            this.label7.TabIndex = 25;
            this.label7.Text = "Thứ tự";
            // 
            // txtCateName
            // 
            this.txtCateName.Location = new System.Drawing.Point(18, 77);
            this.txtCateName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCateName.Name = "txtCateName";
            this.txtCateName.Size = new System.Drawing.Size(243, 26);
            this.txtCateName.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 56);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 19);
            this.label2.TabIndex = 23;
            this.label2.Text = "Tên nhóm";
            // 
            // btnHuyCategory
            // 
            this.btnHuyCategory.Image = global::CASALE.Properties.Resources.action_delete;
            this.btnHuyCategory.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHuyCategory.Location = new System.Drawing.Point(121, 170);
            this.btnHuyCategory.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnHuyCategory.Name = "btnHuyCategory";
            this.btnHuyCategory.Size = new System.Drawing.Size(75, 29);
            this.btnHuyCategory.TabIndex = 22;
            this.btnHuyCategory.Text = "Hủy";
            this.btnHuyCategory.UseVisualStyleBackColor = true;
            this.btnHuyCategory.Click += new System.EventHandler(this.btnHuyCategory_Click);
            // 
            // btnLuuCate
            // 
            this.btnLuuCate.Image = global::CASALE.Properties.Resources.disk_blue;
            this.btnLuuCate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuuCate.Location = new System.Drawing.Point(19, 170);
            this.btnLuuCate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLuuCate.Name = "btnLuuCate";
            this.btnLuuCate.Size = new System.Drawing.Size(99, 29);
            this.btnLuuCate.TabIndex = 21;
            this.btnLuuCate.Text = "Lưu";
            this.btnLuuCate.UseVisualStyleBackColor = true;
            this.btnLuuCate.Click += new System.EventHandler(this.btnLuuCate_Click);
            // 
            // trvcategories
            // 
            this.trvcategories.ContextMenuStrip = this.contextMenuStrip1;
            this.trvcategories.Dock = System.Windows.Forms.DockStyle.Top;
            this.trvcategories.Location = new System.Drawing.Point(0, 41);
            this.trvcategories.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.trvcategories.Name = "trvcategories";
            treeNode1.Name = "Node0";
            treeNode1.Tag = "-1";
            treeNode1.Text = "Tất cả sản phẩm";
            treeNode2.Name = "Node0";
            treeNode2.Text = "Nhóm 1...";
            this.trvcategories.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2});
            this.trvcategories.Size = new System.Drawing.Size(254, 541);
            this.trvcategories.TabIndex = 0;
            this.trvcategories.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.trvcategories_AfterSelect);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmnedit,
            this.cmncreate,
            this.toolStripMenuItem1,
            this.cmndelete});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(221, 82);
            // 
            // cmnedit
            // 
            this.cmnedit.Image = global::CASALE.Properties.Resources.edit1;
            this.cmnedit.Name = "cmnedit";
            this.cmnedit.Size = new System.Drawing.Size(220, 24);
            this.cmnedit.Text = "Hiệu chỉnh";
            this.cmnedit.Click += new System.EventHandler(this.cmnedit_Click);
            // 
            // cmncreate
            // 
            this.cmncreate.Image = global::CASALE.Properties.Resources.action_add;
            this.cmncreate.Name = "cmncreate";
            this.cmncreate.Size = new System.Drawing.Size(220, 24);
            this.cmncreate.Text = "Tạo nhóm con";
            this.cmncreate.Click += new System.EventHandler(this.cmncreate_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(217, 6);
            // 
            // cmndelete
            // 
            this.cmndelete.Image = global::CASALE.Properties.Resources.trash_can;
            this.cmndelete.Name = "cmndelete";
            this.cmndelete.Size = new System.Drawing.Size(220, 24);
            this.cmndelete.Text = "Xóa nhóm đang chọn";
            this.cmndelete.Click += new System.EventHandler(this.cmndelete_Click);
            // 
            // lblTotalCategory
            // 
            this.lblTotalCategory.AutoSize = true;
            this.lblTotalCategory.Location = new System.Drawing.Point(149, 592);
            this.lblTotalCategory.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalCategory.Name = "lblTotalCategory";
            this.lblTotalCategory.Size = new System.Drawing.Size(18, 19);
            this.lblTotalCategory.TabIndex = 4;
            this.lblTotalCategory.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(5, 592);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(114, 19);
            this.label10.TabIndex = 3;
            this.label10.Text = "Tổng số nhóm: ";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel3.Controls.Add(this.lnkcategorycreatenew);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(254, 41);
            this.panel3.TabIndex = 1;
            // 
            // lnkcategorycreatenew
            // 
            this.lnkcategorycreatenew.AutoSize = true;
            this.lnkcategorycreatenew.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lnkcategorycreatenew.ForeColor = System.Drawing.Color.White;
            this.lnkcategorycreatenew.LinkColor = System.Drawing.Color.White;
            this.lnkcategorycreatenew.Location = new System.Drawing.Point(157, 13);
            this.lnkcategorycreatenew.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lnkcategorycreatenew.Name = "lnkcategorycreatenew";
            this.lnkcategorycreatenew.Size = new System.Drawing.Size(89, 17);
            this.lnkcategorycreatenew.TabIndex = 2;
            this.lnkcategorycreatenew.TabStop = true;
            this.lnkcategorycreatenew.Text = "[Thêm mới]";
            this.lnkcategorycreatenew.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkcategorycreatenew_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(5, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nhóm sản phẩm";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.Color.DimGray;
            this.label24.Location = new System.Drawing.Point(309, 586);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(335, 19);
            this.label24.TabIndex = 18;
            this.label24.Text = "Bạn có thể  ấn Ctrl hoặc Shift để chọn xóa nhiều";
            // 
            // pnAddProduct
            // 
            this.pnAddProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnAddProduct.Controls.Add(this.cboUnit);
            this.pnAddProduct.Controls.Add(this.label21);
            this.pnAddProduct.Controls.Add(this.txtproductdesc);
            this.pnAddProduct.Controls.Add(this.label20);
            this.pnAddProduct.Controls.Add(this.txtitemorder);
            this.pnAddProduct.Controls.Add(this.label16);
            this.pnAddProduct.Controls.Add(this.lblmoneyunit);
            this.pnAddProduct.Controls.Add(this.panel1);
            this.pnAddProduct.Controls.Add(this.utondauky);
            this.pnAddProduct.Controls.Add(this.nudThue);
            this.pnAddProduct.Controls.Add(this.label15);
            this.pnAddProduct.Controls.Add(this.lblMsg);
            this.pnAddProduct.Controls.Add(this.label14);
            this.pnAddProduct.Controls.Add(this.label22);
            this.pnAddProduct.Controls.Add(this.label13);
            this.pnAddProduct.Controls.Add(this.label11);
            this.pnAddProduct.Controls.Add(this.cmbdetailcategories);
            this.pnAddProduct.Controls.Add(this.label5);
            this.pnAddProduct.Controls.Add(this.btnHuyProduct);
            this.pnAddProduct.Controls.Add(this.btnLuuProduct);
            this.pnAddProduct.Controls.Add(this.txtGia);
            this.pnAddProduct.Controls.Add(this.label6);
            this.pnAddProduct.Controls.Add(this.txtItemName);
            this.pnAddProduct.Controls.Add(this.label4);
            this.pnAddProduct.Controls.Add(this.txtcode);
            this.pnAddProduct.Controls.Add(this.label3);
            this.pnAddProduct.Location = new System.Drawing.Point(112, 98);
            this.pnAddProduct.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnAddProduct.Name = "pnAddProduct";
            this.pnAddProduct.Size = new System.Drawing.Size(644, 461);
            this.pnAddProduct.TabIndex = 11;
            this.pnAddProduct.Visible = false;
            // 
            // cboUnit
            // 
            this.cboUnit.FormattingEnabled = true;
            this.cboUnit.Location = new System.Drawing.Point(158, 315);
            this.cboUnit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cboUnit.Name = "cboUnit";
            this.cboUnit.Size = new System.Drawing.Size(300, 27);
            this.cboUnit.TabIndex = 6;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(30, 319);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(84, 19);
            this.label21.TabIndex = 39;
            this.label21.Text = "Đơn vị tính";
            // 
            // txtproductdesc
            // 
            this.txtproductdesc.Location = new System.Drawing.Point(161, 205);
            this.txtproductdesc.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtproductdesc.Multiline = true;
            this.txtproductdesc.Name = "txtproductdesc";
            this.txtproductdesc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtproductdesc.Size = new System.Drawing.Size(446, 90);
            this.txtproductdesc.TabIndex = 4;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(30, 209);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 19);
            this.label20.TabIndex = 35;
            this.label20.Text = "Mô tả";
            // 
            // txtitemorder
            // 
            this.txtitemorder.Location = new System.Drawing.Point(158, 385);
            this.txtitemorder.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtitemorder.Name = "txtitemorder";
            this.txtitemorder.Size = new System.Drawing.Size(71, 26);
            this.txtitemorder.TabIndex = 8;
            this.txtitemorder.Text = "1";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(27, 389);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 19);
            this.label16.TabIndex = 33;
            this.label16.Text = "Thứ tự";
            // 
            // lblmoneyunit
            // 
            this.lblmoneyunit.AutoSize = true;
            this.lblmoneyunit.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblmoneyunit.ForeColor = System.Drawing.Color.DimGray;
            this.lblmoneyunit.Location = new System.Drawing.Point(346, 288);
            this.lblmoneyunit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmoneyunit.Name = "lblmoneyunit";
            this.lblmoneyunit.Size = new System.Drawing.Size(39, 17);
            this.lblmoneyunit.TabIndex = 32;
            this.lblmoneyunit.Text = "VNĐ";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.label12);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(642, 38);
            this.panel1.TabIndex = 31;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(4, 9);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(247, 23);
            this.label12.TabIndex = 25;
            this.label12.Text = "THÔNGTIN SẢN PHẨM";
            // 
            // utondauky
            // 
            this.utondauky.Location = new System.Drawing.Point(387, 352);
            this.utondauky.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.utondauky.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.utondauky.Name = "utondauky";
            this.utondauky.Size = new System.Drawing.Size(100, 26);
            this.utondauky.TabIndex = 7;
            // 
            // nudThue
            // 
            this.nudThue.Location = new System.Drawing.Point(158, 348);
            this.nudThue.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.nudThue.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nudThue.Name = "nudThue";
            this.nudThue.Size = new System.Drawing.Size(72, 26);
            this.nudThue.TabIndex = 7;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label15.ForeColor = System.Drawing.Color.DimGray;
            this.label15.Location = new System.Drawing.Point(27, 60);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(320, 17);
            this.label15.TabIndex = 29;
            this.label15.Text = "Cung cấp thông tin sản phẩm theo mẫu sau";
            // 
            // lblMsg
            // 
            this.lblMsg.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblMsg.ForeColor = System.Drawing.Color.DarkRed;
            this.lblMsg.Location = new System.Drawing.Point(154, 80);
            this.lblMsg.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(454, 16);
            this.lblMsg.TabIndex = 28;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label14.ForeColor = System.Drawing.Color.DimGray;
            this.label14.Location = new System.Drawing.Point(238, 352);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(23, 17);
            this.label14.TabIndex = 27;
            this.label14.Text = "%";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(275, 355);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(83, 19);
            this.label22.TabIndex = 23;
            this.label22.Text = "Tồn đầu kỳ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(459, 19);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 19);
            this.label13.TabIndex = 26;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(27, 351);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 19);
            this.label11.TabIndex = 23;
            this.label11.Text = "Thuế";
            // 
            // cmbdetailcategories
            // 
            this.cmbdetailcategories.FormattingEnabled = true;
            this.cmbdetailcategories.Location = new System.Drawing.Point(158, 137);
            this.cmbdetailcategories.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbdetailcategories.Name = "cmbdetailcategories";
            this.cmbdetailcategories.Size = new System.Drawing.Size(300, 27);
            this.cmbdetailcategories.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 141);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 19);
            this.label5.TabIndex = 21;
            this.label5.Text = "Loại sản phẩm";
            // 
            // btnHuyProduct
            // 
            this.btnHuyProduct.Image = global::CASALE.Properties.Resources.action_delete;
            this.btnHuyProduct.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHuyProduct.Location = new System.Drawing.Point(361, 423);
            this.btnHuyProduct.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnHuyProduct.Name = "btnHuyProduct";
            this.btnHuyProduct.Size = new System.Drawing.Size(96, 29);
            this.btnHuyProduct.TabIndex = 10;
            this.btnHuyProduct.Text = "Hủy bỏ";
            this.btnHuyProduct.UseVisualStyleBackColor = true;
            this.btnHuyProduct.Click += new System.EventHandler(this.btnHuyProduct_Click);
            // 
            // btnLuuProduct
            // 
            this.btnLuuProduct.Image = global::CASALE.Properties.Resources.disk_blue;
            this.btnLuuProduct.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuuProduct.Location = new System.Drawing.Point(157, 423);
            this.btnLuuProduct.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLuuProduct.Name = "btnLuuProduct";
            this.btnLuuProduct.Size = new System.Drawing.Size(197, 29);
            this.btnLuuProduct.TabIndex = 9;
            this.btnLuuProduct.Text = "Lưu thông tin";
            this.btnLuuProduct.UseVisualStyleBackColor = true;
            this.btnLuuProduct.Click += new System.EventHandler(this.btnLuuProduct_Click);
            // 
            // txtGia
            // 
            this.txtGia.Location = new System.Drawing.Point(158, 282);
            this.txtGia.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtGia.Name = "txtGia";
            this.txtGia.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtGia.Size = new System.Drawing.Size(179, 26);
            this.txtGia.TabIndex = 5;
            this.txtGia.TextChanged += new System.EventHandler(this.txtGia_TextChanged);
            this.txtGia.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtGia_KeyUp);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 286);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 19);
            this.label6.TabIndex = 17;
            this.label6.Text = "Đơn giá";
            // 
            // txtItemName
            // 
            this.txtItemName.Location = new System.Drawing.Point(158, 171);
            this.txtItemName.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtItemName.Name = "txtItemName";
            this.txtItemName.Size = new System.Drawing.Size(449, 26);
            this.txtItemName.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 175);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 19);
            this.label4.TabIndex = 13;
            this.label4.Text = "Tên sản phẩm";
            // 
            // txtcode
            // 
            this.txtcode.Location = new System.Drawing.Point(158, 103);
            this.txtcode.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtcode.Name = "txtcode";
            this.txtcode.Size = new System.Drawing.Size(300, 26);
            this.txtcode.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 106);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 19);
            this.label3.TabIndex = 11;
            this.label3.Text = "Mã sản phẩm";
            // 
            // pnprintproductbarcode
            // 
            this.pnprintproductbarcode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnprintproductbarcode.Controls.Add(this.txtprintbcproprice);
            this.pnprintproductbarcode.Controls.Add(this.label18);
            this.pnprintproductbarcode.Controls.Add(this.nuprintbcitems);
            this.pnprintproductbarcode.Controls.Add(this.pnprintbcpropreview);
            this.pnprintproductbarcode.Controls.Add(this.label17);
            this.pnprintproductbarcode.Controls.Add(this.panel5);
            this.pnprintproductbarcode.Controls.Add(this.label23);
            this.pnprintproductbarcode.Controls.Add(this.btnprintbccancel);
            this.pnprintproductbarcode.Controls.Add(this.btnprintbcprintbarcodes);
            this.pnprintproductbarcode.Controls.Add(this.txtprintbcproname);
            this.pnprintproductbarcode.Controls.Add(this.label27);
            this.pnprintproductbarcode.Controls.Add(this.txtprintbcprocode);
            this.pnprintproductbarcode.Controls.Add(this.label28);
            this.pnprintproductbarcode.Location = new System.Drawing.Point(112, 99);
            this.pnprintproductbarcode.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnprintproductbarcode.Name = "pnprintproductbarcode";
            this.pnprintproductbarcode.Size = new System.Drawing.Size(638, 364);
            this.pnprintproductbarcode.TabIndex = 12;
            this.pnprintproductbarcode.Visible = false;
            // 
            // txtprintbcproprice
            // 
            this.txtprintbcproprice.Location = new System.Drawing.Point(158, 127);
            this.txtprintbcproprice.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtprintbcproprice.Name = "txtprintbcproprice";
            this.txtprintbcproprice.Size = new System.Drawing.Size(298, 26);
            this.txtprintbcproprice.TabIndex = 38;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(27, 130);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(37, 19);
            this.label18.TabIndex = 37;
            this.label18.Text = "Giá ";
            // 
            // nuprintbcitems
            // 
            this.nuprintbcitems.Location = new System.Drawing.Point(157, 272);
            this.nuprintbcitems.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.nuprintbcitems.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.nuprintbcitems.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nuprintbcitems.Name = "nuprintbcitems";
            this.nuprintbcitems.Size = new System.Drawing.Size(93, 26);
            this.nuprintbcitems.TabIndex = 36;
            this.nuprintbcitems.Value = new decimal(new int[] {
            40,
            0,
            0,
            0});
            // 
            // pnprintbcpropreview
            // 
            this.pnprintbcpropreview.Location = new System.Drawing.Point(158, 172);
            this.pnprintbcpropreview.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnprintbcpropreview.Name = "pnprintbcpropreview";
            this.pnprintbcpropreview.Size = new System.Drawing.Size(188, 91);
            this.pnprintbcpropreview.TabIndex = 35;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(27, 275);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 19);
            this.label17.TabIndex = 33;
            this.label17.Text = "Số lượng";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel5.Controls.Add(this.label19);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(636, 38);
            this.panel5.TabIndex = 31;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(4, 9);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(218, 23);
            this.label19.TabIndex = 25;
            this.label19.Text = "IN PHIẾU MÃ VẠCH";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(459, 19);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(0, 19);
            this.label23.TabIndex = 26;
            // 
            // btnprintbccancel
            // 
            this.btnprintbccancel.Location = new System.Drawing.Point(363, 305);
            this.btnprintbccancel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnprintbccancel.Name = "btnprintbccancel";
            this.btnprintbccancel.Size = new System.Drawing.Size(96, 29);
            this.btnprintbccancel.TabIndex = 20;
            this.btnprintbccancel.Text = "Hủy bỏ";
            this.btnprintbccancel.UseVisualStyleBackColor = true;
            this.btnprintbccancel.Click += new System.EventHandler(this.btnprintbccancel_Click);
            // 
            // btnprintbcprintbarcodes
            // 
            this.btnprintbcprintbarcodes.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprintbcprintbarcodes.ForeColor = System.Drawing.Color.Red;
            this.btnprintbcprintbarcodes.Image = global::CASALE.Properties.Resources.images;
            this.btnprintbcprintbarcodes.Location = new System.Drawing.Point(157, 305);
            this.btnprintbcprintbarcodes.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnprintbcprintbarcodes.Name = "btnprintbcprintbarcodes";
            this.btnprintbcprintbarcodes.Size = new System.Drawing.Size(197, 29);
            this.btnprintbcprintbarcodes.TabIndex = 19;
            this.btnprintbcprintbarcodes.Text = "In ấn mã vạch";
            this.btnprintbcprintbarcodes.UseVisualStyleBackColor = true;
            this.btnprintbcprintbarcodes.Click += new System.EventHandler(this.btnprintbcprintbarcodes_Click);
            // 
            // txtprintbcproname
            // 
            this.txtprintbcproname.Location = new System.Drawing.Point(158, 95);
            this.txtprintbcproname.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtprintbcproname.Name = "txtprintbcproname";
            this.txtprintbcproname.Size = new System.Drawing.Size(449, 26);
            this.txtprintbcproname.TabIndex = 14;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(27, 99);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(100, 19);
            this.label27.TabIndex = 13;
            this.label27.Text = "Tên sản phẩm";
            // 
            // txtprintbcprocode
            // 
            this.txtprintbcprocode.Location = new System.Drawing.Point(158, 65);
            this.txtprintbcprocode.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtprintbcprocode.Name = "txtprintbcprocode";
            this.txtprintbcprocode.Size = new System.Drawing.Size(300, 26);
            this.txtprintbcprocode.TabIndex = 12;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(30, 68);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(97, 19);
            this.label28.TabIndex = 11;
            this.label28.Text = "Mã sản phẩm";
            // 
            // btnprintnoall
            // 
            this.btnprintnoall.Image = global::CASALE.Properties.Resources.printer;
            this.btnprintnoall.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnprintnoall.Location = new System.Drawing.Point(706, 588);
            this.btnprintnoall.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnprintnoall.Name = "btnprintnoall";
            this.btnprintnoall.Size = new System.Drawing.Size(154, 29);
            this.btnprintnoall.TabIndex = 13;
            this.btnprintnoall.Text = "In theo danh sách lọc ";
            this.btnprintnoall.UseVisualStyleBackColor = true;
            this.btnprintnoall.Click += new System.EventHandler(this.btnprintnoall_Click);
            // 
            // btnprintall
            // 
            this.btnprintall.Image = global::CASALE.Properties.Resources.printer;
            this.btnprintall.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnprintall.Location = new System.Drawing.Point(868, 588);
            this.btnprintall.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnprintall.Name = "btnprintall";
            this.btnprintall.Size = new System.Drawing.Size(116, 29);
            this.btnprintall.TabIndex = 13;
            this.btnprintall.Text = "In tất cả ";
            this.btnprintall.UseVisualStyleBackColor = true;
            this.btnprintall.Click += new System.EventHandler(this.btnprintall_Click);
            // 
            // lblTotalProduct
            // 
            this.lblTotalProduct.AutoSize = true;
            this.lblTotalProduct.Location = new System.Drawing.Point(177, 592);
            this.lblTotalProduct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalProduct.Name = "lblTotalProduct";
            this.lblTotalProduct.Size = new System.Drawing.Size(18, 19);
            this.lblTotalProduct.TabIndex = 17;
            this.lblTotalProduct.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(5, 592);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(138, 19);
            this.label9.TabIndex = 16;
            this.label9.Text = "Tổng số sản phẩm: ";
            // 
            // lvListProduct
            // 
            this.lvListProduct.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ID,
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader5,
            this.columnHeader4,
            this.columnHeader6,
            this.columnHeader9});
            this.lvListProduct.ContextMenuStrip = this.cmnProduct;
            this.lvListProduct.Dock = System.Windows.Forms.DockStyle.Top;
            this.lvListProduct.FullRowSelect = true;
            this.lvListProduct.GridLines = true;
            this.lvListProduct.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvListProduct.Location = new System.Drawing.Point(0, 41);
            this.lvListProduct.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lvListProduct.Name = "lvListProduct";
            this.lvListProduct.Size = new System.Drawing.Size(994, 541);
            this.lvListProduct.TabIndex = 10;
            this.lvListProduct.UseCompatibleStateImageBehavior = false;
            this.lvListProduct.View = System.Windows.Forms.View.Details;
            // 
            // ID
            // 
            this.ID.Width = 0;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "#";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Mã sản phẩm";
            this.columnHeader2.Width = 108;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Tên sản phẩm";
            this.columnHeader3.Width = 163;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Loại sản phẩm";
            this.columnHeader7.Width = 125;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Đ.Vị";
            this.columnHeader8.Width = 80;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Đơn giá";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader5.Width = 97;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Số lượng";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader4.Width = 83;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Thuế";
            this.columnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader6.Width = 81;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "#";
            this.columnHeader9.Width = 0;
            // 
            // cmnProduct
            // 
            this.cmnProduct.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmnUpdateProduct,
            this.cmnuproductprintbarcode,
            this.toolStripSeparator2,
            this.cmnDeleteProduct});
            this.cmnProduct.Name = "contextMenuStrip2";
            this.cmnProduct.Size = new System.Drawing.Size(285, 82);
            // 
            // cmnUpdateProduct
            // 
            this.cmnUpdateProduct.Image = global::CASALE.Properties.Resources.edit1;
            this.cmnUpdateProduct.Name = "cmnUpdateProduct";
            this.cmnUpdateProduct.Size = new System.Drawing.Size(284, 24);
            this.cmnUpdateProduct.Text = "Hiệu chỉnh thông tin sản phẩm";
            this.cmnUpdateProduct.Click += new System.EventHandler(this.cmnUpdateProduct_Click);
            // 
            // cmnuproductprintbarcode
            // 
            this.cmnuproductprintbarcode.Image = global::CASALE.Properties.Resources.images;
            this.cmnuproductprintbarcode.Name = "cmnuproductprintbarcode";
            this.cmnuproductprintbarcode.Size = new System.Drawing.Size(284, 24);
            this.cmnuproductprintbarcode.Text = "In mã vạch sản phẩm";
            this.cmnuproductprintbarcode.Click += new System.EventHandler(this.cmnuproductprintbarcode_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(281, 6);
            // 
            // cmnDeleteProduct
            // 
            this.cmnDeleteProduct.Image = global::CASALE.Properties.Resources.trash_can;
            this.cmnDeleteProduct.Name = "cmnDeleteProduct";
            this.cmnDeleteProduct.Size = new System.Drawing.Size(284, 24);
            this.cmnDeleteProduct.Text = "Xóa sản phẩm được đang chọn";
            this.cmnDeleteProduct.Click += new System.EventHandler(this.cmnDeleteProduct_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel2.Controls.Add(this.btnsyndataonline);
            this.panel2.Controls.Add(this.btnExportExcel);
            this.panel2.Controls.Add(this.btnAddProduct);
            this.panel2.Controls.Add(this.txtSearch);
            this.panel2.Controls.Add(this.btnSearch);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(994, 41);
            this.panel2.TabIndex = 15;
            // 
            // btnsyndataonline
            // 
            this.btnsyndataonline.Enabled = false;
            this.btnsyndataonline.Location = new System.Drawing.Point(550, 6);
            this.btnsyndataonline.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnsyndataonline.Name = "btnsyndataonline";
            this.btnsyndataonline.Size = new System.Drawing.Size(253, 29);
            this.btnsyndataonline.TabIndex = 17;
            this.btnsyndataonline.Text = "Đồng bộ dữ liệu với website";
            this.btnsyndataonline.UseVisualStyleBackColor = true;
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.Image = global::CASALE.Properties.Resources.page_white_excel;
            this.btnExportExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportExcel.Location = new System.Drawing.Point(302, 6);
            this.btnExportExcel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(143, 29);
            this.btnExportExcel.TabIndex = 16;
            this.btnExportExcel.Text = "Xuất ra Excel";
            this.btnExportExcel.UseVisualStyleBackColor = true;
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.Image = global::CASALE.Properties.Resources.action_add;
            this.btnAddProduct.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddProduct.Location = new System.Drawing.Point(813, 6);
            this.btnAddProduct.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(175, 29);
            this.btnAddProduct.TabIndex = 15;
            this.btnAddProduct.Text = "Thêm mới sản phẩm";
            this.btnAddProduct.UseVisualStyleBackColor = true;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(4, 8);
            this.txtSearch.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(187, 26);
            this.txtSearch.TabIndex = 13;
            // 
            // btnSearch
            // 
            this.btnSearch.Image = global::CASALE.Properties.Resources.book_blue_view;
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSearch.Location = new System.Drawing.Point(199, 6);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(100, 29);
            this.btnSearch.TabIndex = 14;
            this.btnSearch.Text = "Tìm kiếm";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printorder_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDocument2
            // 
            this.printDocument2.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printorder_PrintPageNoAll);
            // 
            // frmSanpham
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1254, 650);
            this.Controls.Add(this.splitContainer1);
            this.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.MaximizeBox = false;
            this.Name = "frmSanpham";
            this.Text = "Danh mục sản phẩm";
            this.Load += new System.EventHandler(this.frmSanpham_Load);
            this.Controls.SetChildIndex(this.splitContainer1, 0);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.pnAddCategory.ResumeLayout(false);
            this.pnAddCategory.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.pnAddProduct.ResumeLayout(false);
            this.pnAddProduct.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.utondauky)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudThue)).EndInit();
            this.pnprintproductbarcode.ResumeLayout(false);
            this.pnprintproductbarcode.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nuprintbcitems)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.cmnProduct.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel pnAddCategory;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCateOrder;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCateName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnHuyCategory;
        private System.Windows.Forms.Button btnLuuCate;
        private System.Windows.Forms.TreeView trvcategories;
        private System.Windows.Forms.Label lblTotalCategory;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.LinkLabel lnkcategorycreatenew;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnprintall;
        private System.Windows.Forms.Panel pnprintproductbarcode;
        private System.Windows.Forms.TextBox txtprintbcproprice;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown nuprintbcitems;
        private System.Windows.Forms.Panel pnprintbcpropreview;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btnprintbccancel;
        private System.Windows.Forms.Button btnprintbcprintbarcodes;
        private System.Windows.Forms.TextBox txtprintbcproname;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtprintbcprocode;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel pnAddProduct;
        private System.Windows.Forms.ComboBox cboUnit;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtproductdesc;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtitemorder;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblmoneyunit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown nudThue;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblMsg;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmbdetailcategories;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnHuyProduct;
        private System.Windows.Forms.Button btnLuuProduct;
        private System.Windows.Forms.TextBox txtGia;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtItemName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtcode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblTotalProduct;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListView lvListProduct;
        private System.Windows.Forms.ColumnHeader ID;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnsyndataonline;
        private System.Windows.Forms.Button btnExportExcel;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cmnedit;
        private System.Windows.Forms.ToolStripMenuItem cmncreate;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cmndelete;
        private System.Windows.Forms.ContextMenuStrip cmnProduct;
        private System.Windows.Forms.ToolStripMenuItem cmnUpdateProduct;
        private System.Windows.Forms.ToolStripMenuItem cmnuproductprintbarcode;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem cmnDeleteProduct;
        private System.Windows.Forms.NumericUpDown utondauky;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.Label lblsl;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Button btnprintnoall;
        private System.Drawing.Printing.PrintDocument printDocument2;
        private System.Windows.Forms.Label label24;
    }
}