﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LCMultiUtilities;
using CASALE.Class;
using OfficeUtilities;
using System.Drawing.Printing;
using System.IO;
using LCUtiliti;

namespace CASALE
{
    public partial class frmSanpham : templates
    {
        int ilevel = -1;
        bool binsertupdate = false;
        protected string ino = "-1";
        protected string iid = "-1";
        protected string strselectedcategoryid = "-1";
        protected int iparentid = -1;
        protected double iproductquantity = 0;
        public frmSanpham()
        {
            InitializeComponent();
        }

        private void frmSanpham_Load(object sender, EventArgs e)
        {
            pnAddProduct.Visible = false;
            pnAddCategory.Visible = false;
            LoadCategoriesTree();
            LoadUnit();
            LoadProducts();
            LoadCate();
        }
        void LoadProducts()
        {

            bool getthiscategoryonly = false;
            if (strselectedcategoryid.Equals("-1"))
            {
                getthiscategoryonly = true;
            }

            this.lvListProduct.Items.Clear();
            string[] searchfield = { "vkey", "vtitle" };
            DataTable tb = mssql_multicates_multidb_items.dicts_cate_items_incate_v3(-1,
                Common.capp_product_code, Common.vietnames, Convert.ToInt32(strselectedcategoryid),
                getthiscategoryonly, false, false, "", 1, txtSearch.Text, searchfield,
                false, "", "", Common.ConnectionString);
            if (tb.Rows.Count > 0)
            {
                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    ListViewItem lvi = new ListViewItem(tb.Rows[i]["iid"].ToString() + "|" + tb.Rows[i]["ino"].ToString());

                    lvi.SubItems.Add((i + 1).ToString());
                    lvi.SubItems.Add(tb.Rows[i]["vkey"].ToString());
                    lvi.SubItems.Add(tb.Rows[i]["vtitle"].ToString());
                    lvi.SubItems.Add(getnamecate(tb.Rows[i]["icid"].ToString()));
                    lvi.SubItems.Add(tb.Rows[i]["vunit"].ToString());
                    lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(tb.Rows[i]["vauthor"].ToString()));
                    lvi.SubItems.Add(tb.Rows[i]["iquantity"].ToString());
                    lvi.SubItems.Add(tb.Rows[i]["vurl"].ToString());
                    lvi.SubItems.Add(tb.Rows[i]["icid"].ToString());
                    lvListProduct.Items.Add(lvi);
                }
            }
            this.lblTotalProduct.Text = lvListProduct.Items.Count.ToString();
        }
        protected string getnamecate(string icid)
        {
            if (!icid.Equals(""))
            {
                DataTable dt = mssql_modcategories.LoadcateDetail(icid);
                if (dt.Rows.Count > 0)
                {
                    return dt.Rows[0]["vname"].ToString();
                }
            }
            return "";
        }
        private void lnkcategorycreatenew_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            pnAddCategory.Visible = true;
            binsertupdate = false;
            txtCateName.Text = "";
            txtCateOrder.Text = "1";
        }

        private void btnLuuCate_Click(object sender, EventArgs e)
        {
            string _catename = txtCateName.Text;
            string order = txtCateOrder.Text;
            if (this.binsertupdate == false)
            {
                mssql_modcategories_data.cate_Insert("-1", Common.capp_product_code,
                    Common.vietnames, strselectedcategoryid, "-1",
                    _catename, "", "", "", "", "0", order,
                    "0", "1", Common.ConnectionString);
            }
            else
                mssql_modcategories_data.cate_Update(strselectedcategoryid,
                    Common.capp_product_code, Common.vietnames, iparentid.ToString(),
                    "-1", _catename, "", "", "", lblsl.Text, order, "0", "1", Common.ConnectionString);

            LoadCategoriesTree();
            txtCateName.Text = "";
            pnAddCategory.Visible = false;
        }
        void LoadCategoriesTree()
        {
            trvcategories.Nodes.Clear();
            trvcategories.Nodes.Add("Tất cả nhóm");
            trvcategories.Nodes[0].Tag = "-1";
            DataTable tb = new DataTable();
            tb = mssql_modcategories.LoadChildrencates(Common.capp_product_code, Common.vietnames, "-1", "1");
            if (tb.Rows.Count > 0)
            {

                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    //TreeNode tn = new TreeNode(tb.Rows[i]["vname"].ToString());
                    TreeNode tn = new TreeNode(tb.Rows[i]["vname"].ToString() + "  (" + tb.Rows[i]["iitems"].ToString() + ")");
                    tn.Tag = tb.Rows[i]["icid"].ToString();
                    LoadCategories2Tree(ref tn);
                    trvcategories.Nodes.Add(tn);
                }

                // combobox
                //DataTable dtcmb = tb;
                //for (int i = 0; i < dtcmb.Rows.Count; i++)
                //{
                //    string tm = "";
                //    ilevel = Convert.ToInt32(tb.Rows[i]["ilevel"]);

                //    for (int j = 0; j < ilevel; j++)
                //    {
                //        tm += "--"; ;
                //    }
                //    dtcmb.Rows[i]["vname"] = tm + dtcmb.Rows[i]["vname"].ToString();
                //}
                //cmbdetailcategories.DataSource = dtcmb;
                //cmbdetailcategories.DisplayMember = "vname";
                //cmbdetailcategories.ValueMember = "icid";
                trvcategories.ExpandAll();
            }
            this.lblTotalCategory.Text = (trvcategories.Nodes.Count - 1).ToString();
        }
        void LoadCategories2Tree(ref TreeNode trnode)
        {
            int icid = Convert.ToInt32(trnode.Tag);
            DataTable dt = mssql_modcategories.LoadChildrencates(icid.ToString());
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //TreeNode tn = new TreeNode(dt.Rows[i]["vname"].ToString());
                TreeNode tn = new TreeNode(dt.Rows[i]["vname"].ToString() + "  (" + dt.Rows[i]["iitems"].ToString() + ")");
                tn.Tag = dt.Rows[i]["icid"].ToString();
                LoadCategories2Tree(ref tn);
                trnode.Nodes.Add(tn);
            }
        }
        private void cmnedit_Click(object sender, EventArgs e)
        {
            if (trvcategories.Nodes.Count > 0)
            {
                if (trvcategories.SelectedNode != null)
                {
                    this.strselectedcategoryid = trvcategories.SelectedNode.Tag.ToString();
                    DataTable dt = new DataTable();
                    dt = mssql_modcategories.LoadcateDetail(strselectedcategoryid);
                    if (dt.Rows.Count > 0)
                    {
                        iparentid = Convert.ToInt32(dt.Rows[0]["ic_par_id"]);
                        txtCateName.Text = dt.Rows[0]["vname"].ToString();
                        txtCateOrder.Text = dt.Rows[0]["iorders"].ToString();
                        lblsl.Text = dt.Rows[0]["iitems"].ToString();
                    }
                    pnAddCategory.Visible = true;
                    this.binsertupdate = true;
                }
            }
        }

        private void cmncreate_Click(object sender, EventArgs e)
        {
            if (trvcategories.Nodes.Count > 0)
            {
                if (trvcategories.SelectedNode != null)
                {
                    pnAddCategory.Visible = true;
                    txtCateName.Text = "";
                    txtCateOrder.Text = "1";
                    binsertupdate = false;
                }
            }
        }

        private void cmndelete_Click(object sender, EventArgs e)
        {
            if (trvcategories.Nodes.Count > 0)
            {
                if (trvcategories.SelectedNode != null)
                {
                    if (MessageBox.Show("Xóa nhóm đang chọn?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        try
                        {
                            this.strselectedcategoryid = trvcategories.SelectedNode.Tag.ToString();
                            this.txtSearch.Text = "";
                            mssql_modcategories_data.cate_Delete(this.strselectedcategoryid, Common.ConnectionString);
                            LoadCategoriesTree();
                        }
                        catch
                        {
                            MessageBox.Show("Phải xóa tất cả sản phẩm trong nhóm trước khi xóa nhóm", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private void trvcategories_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (trvcategories.Nodes.Count > 0)
            {
                if (trvcategories.SelectedNode != null)
                {
                    this.strselectedcategoryid = trvcategories.SelectedNode.Tag.ToString();
                    LoadProducts();
                }
            }
        }

        void LoadCate()
        {
            DataTable tb = new DataTable();
            mssql_modcategories.LoadAllChildrencates(ref tb, "-1", Common.capp_product_code, "1");
            if (tb.Rows.Count > 0)
            {
                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    string tm = "-";
                    int ilevel = Convert.ToInt32(tb.Rows[i]["ilevel"]);
                    for (int j = 1; j < ilevel; j++)
                    {
                        tm += "--"; ;
                    }
                    tb.Rows[i]["vname"] = tm + tb.Rows[i]["vname"].ToString();
                }
                cmbdetailcategories.DataSource = tb;
                cmbdetailcategories.DisplayMember = "vname";
                cmbdetailcategories.ValueMember = "icid";
            }
        }

        void LoadUnit()
        {
            DataTable tb = new DataTable();
            mssql_modcategories.LoadAllChildrencates(ref tb, "-1", Common.app_code_quote_unit_id, "1");
            if (tb.Rows.Count > 0)
            {
                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    string tm = "-";
                    int ilevel = Convert.ToInt32(tb.Rows[i]["ilevel"]);
                    for (int j = 1; j < ilevel; j++)
                    {
                        tm += "--"; ;
                    }
                    tb.Rows[i]["vname"] = tm + tb.Rows[i]["vname"].ToString();
                }
                cboUnit.DataSource = tb;
                cboUnit.DisplayMember = "vname";
                cboUnit.ValueMember = "vname";
            }
        }

        private void txtGia_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtGia_KeyUp(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode==Keys.Enter)
            //{
            //      txtGia.Text = LCUtiliti.ConvertNumber.FomatPrice(txtGia.Text.Trim());
            
            //}
        }

        private void btnLuuProduct_Click(object sender, EventArgs e)
        {
            this.lvListProduct.Items.Clear();
            string _codeproduct = txtcode.Text;
            int _category = Convert.ToInt32(cmbdetailcategories.SelectedValue);
            int[] cate = { _category };
            string _productname = txtItemName.Text;
            string _dongia = txtGia.Text;
            string _thue = nudThue.Value.ToString();
            string _tondauky = utondauky.Value.ToString();
            string[] strunit = cboUnit.SelectedValue.ToString().Split('-');
            string unit = strunit[strunit.Length - 1];
            //MessageBox.Show(unit);
            //if (strunit.Length == 4)
            //{

                if (this.binsertupdate == false) //insert
                {
                    mssql_multicates_multidb_items.dicts_items_insert_v3(
                        cate, _codeproduct,
                        _productname, txtproductdesc.Text, "", _dongia, _thue, "", "",
                        0, DateTime.Now, DateTime.Now, DateTime.Now,unit,
                        Convert.ToDouble(_tondauky), Convert.ToInt32(txtitemorder.Text), "0", "1", Convert.ToInt32(txtitemorder.Text),
                        DateTime.Now,
                        DateTime.Now, DateTime.Now, 1, false, Common.ConnectionString);
                    mssql_modcategories_data.cate_Update(cmbdetailcategories.SelectedValue.ToString(), " iitems=iitems+1", Common.ConnectionString);
                    LoadCategoriesTree();
                }
                else //update
                {
                    mssql_multicates_multidb_items.dicts_items_update_v3(Convert.ToInt32(this.ino),
                        Convert.ToInt32(this.iid), Common.capp_product_code,
                        Convert.ToInt32(this.strselectedcategoryid),
                        Convert.ToInt32(cmbdetailcategories.SelectedValue), txtcode.Text,
                        txtItemName.Text,"", txtproductdesc.Text, "", txtGia.Text, nudThue.Value.ToString(),
                        "", "", unit, Convert.ToDouble(_tondauky), Convert.ToInt32(txtitemorder.Text), 1, 0,
                        DateTime.Now, DateTime.Now,
                        true, false, Common.ConnectionString);
                    this.binsertupdate = false;
                }
            //}
            //else
            //{
            //    lblMsg.Text = "Thông tin chưa hợp lệ";
            //    this.lblMsg.ForeColor = System.Drawing.Color.Red;
            //    return;
            //}
            pnAddProduct.Visible = false;
            lblMsg.Visible = false;
            LoadProducts();
        }

        private void btnHuyProduct_Click(object sender, EventArgs e)
        {
            this.binsertupdate = false;
            pnAddProduct.Visible = false;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            LoadProducts();
        }

        private void btnExportExcel_Click(object sender, EventArgs e)
        {
            //ExcelUtilities.ExportListViewToExcel(ref lvListProduct);
            //LCExcelUtiliti.ToExcel(lvListProduct);;
            ToExcel();
            
            
        }

        private void ToExcel()
        {
            try
            {
                Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                app.Visible = true;
                Microsoft.Office.Interop.Excel.Workbook wb = app.Workbooks.Add(1);
                Microsoft.Office.Interop.Excel.Worksheet ws = (Microsoft.Office.Interop.Excel.Worksheet)wb.Worksheets[1];
                int i = 1;
                int i2 = 1;
                foreach (ListViewItem lvi in lvListProduct.Items)
                {
                    i = 1;
                    foreach (ListViewItem.ListViewSubItem lvs in lvi.SubItems)
                    {
                        ws.Cells[i2, i] = lvs.Text;
                        i++;
                    }
                    i2++;
                }
            }
            catch (Exception ex)
            {;
            }
           
        }

        private void Tocsv()
        {
            {
                SaveFileDialog sfd = new SaveFileDialog
                {
                    Title = "Choose file to save to",
                    FileName = "example.csv",
                    Filter = "CSV (*.csv)|*.csv",
                    FilterIndex = 0,
                    InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
                };

                //show the dialog + display the results in a msgbox unless cancelled


                if (sfd.ShowDialog() == DialogResult.OK)
                {

                    string[] headers = lvListProduct.Columns
                               .OfType<ColumnHeader>()
                               .Select(header => header.Text.Trim())
                               .ToArray();

                    string[][] items = lvListProduct.Items
                                .OfType<ListViewItem>()
                                .Select(lvi => lvi.SubItems
                                    .OfType<ListViewItem.ListViewSubItem>()
                                    .Select(si => si.Text).ToArray()).ToArray();

                    string table = string.Join(",", headers) + Environment.NewLine;
                    foreach (string[] a in items)
                    {
                        table += string.Join(",", a) + Environment.NewLine;
                    }
                    table = table.TrimEnd('\r', '\n');
                    System.IO.File.WriteAllText(sfd.FileName, table);

                }
            }
        }
        private void btnAddProduct_Click(object sender, EventArgs e)
        {
           pnAddProduct.Visible = true;
        }

        private void cmnUpdateProduct_Click(object sender, EventArgs e)
        {
            if (lvListProduct.Items.Count > 0)
            {
                if (lvListProduct.SelectedItems.Count > 0)
                {
                    pnAddProduct.Visible = true;
                    string[] prms = lvListProduct.SelectedItems[0].Text.ToString().Split('|');
                    if (prms.Length == 2)
                    {
                        this.iid = prms[0];
                        this.ino = prms[1];
                    }
                    DataTable dt = mssql_multicates_multidb_items.dicts_items_GetDetailByID(this.iid, Common.capp_product_code, Common.ConnectionString);

                    if (dt.Rows.Count > 0)
                    {
                        txtcode.Text = dt.Rows[0]["vkey"].ToString();
                        txtItemName.Text = dt.Rows[0]["vtitle"].ToString();
                        txtproductdesc.Text = dt.Rows[0]["vdesc"].ToString();
                        txtGia.Text = dt.Rows[0]["vauthor"].ToString();
                        nudThue.Value = Decimal.Parse(dt.Rows[0]["vurl"].ToString());
                        utondauky.Value = Decimal.Parse(dt.Rows[0]["iquantity"].ToString());
                        cmbdetailcategories.SelectedValue = this.strselectedcategoryid = dt.Rows[0]["icid"].ToString();
                        iproductquantity = Convert.ToDouble(dt.Rows[0]["iquantity"]);

                        this.binsertupdate = true;
                    }
                }
            }
        }
        PrintPreviewDialog printpreviewdialog = new PrintPreviewDialog();
        System.Drawing.Printing.PrintDocument printdocument = new System.Drawing.Printing.PrintDocument();
        float h = 0.0f;
        string PrintTitle = "";// tiêu đề in.
        DateTime PrintImExDateTime = DateTime.Now;
        DataTable PrintDtImExDetail = new DataTable();
        DataTable catagore = new DataTable();
        int PrintFromPage = 0;
        int PrintCurrentRow = 0;
        private void btnprintall_Click(object sender, EventArgs e)
        {
            bool getthiscategoryonly = false;
            if (strselectedcategoryid.Equals("-1"))
            {
                getthiscategoryonly = true;
            }
            string[] searchfield = { "vkey", "vtitle" };
            PrintDtImExDetail = mssql_multicates_multidb_items.dicts_cate_items_incate_v3(-1,
                Common.capp_product_code, Common.vietnames, Convert.ToInt32(strselectedcategoryid),
                getthiscategoryonly, false, false, "", 1, txtSearch.Text, searchfield,
                false, "", "", Common.ConnectionString);

            PrintFromPage = 0;
            PrintCurrentRow = 0;
            printdocument = new PrintDocument();
            printdocument.PrintPage += new PrintPageEventHandler(printorder_PrintPage);
            //PrintDialog pdl = new PrintDialog();
            //if (pdl.ShowDialog() == DialogResult.OK)
            //{
            //    printDocument1.PrinterSettings = pdl.PrinterSettings;
            //    printDocument1.Print();
            //}
            //printDocument1.PrinterSettings = pdl.PrinterSettings;
            printDocument1.Print();
            //printdocument.Print();
            //printdocument = new PrintDocument();
            //printdocument.PrintPage += new PrintPageEventHandler(printorder_PrintPage);
            //this.printPreviewDialog1.PrintPreviewControl.Zoom = 1.2;
            //printPreviewDialog1.ShowDialog();
        }

        private void printorder_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            #region
            if (PrintDtImExDetail.Rows.Count == 0 || PrintCurrentRow >= PrintDtImExDetail.Rows.Count)
            {
                e.HasMorePages = false;
                PrintCurrentRow = 0;
                PrintFromPage = 0;

                return;
            }

            Graphics g = e.Graphics;
            Rectangle rFull = new Rectangle(
                e.PageBounds.Left - 10,
                e.PageBounds.Top,
                e.PageBounds.Right,
                e.PageBounds.Bottom);

            StringFormat sf = new StringFormat();
            float x = 25;
            float y = 25;
            float colxpadding = 3;
            float colypadding = 3;

            Font titleFont = new Font("Tahoma", 9, System.Drawing.GraphicsUnit.Point);
            Font titleFont2 = new Font("Tahoma", 10, System.Drawing.GraphicsUnit.Point);

            if (PrintFromPage == 0)
            {
                #region header

                PrintTitle = "BẢNG BÁO GIÁ";
                g.DrawString(Common.CorporationName.ToString().ToUpper(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString(Common.CompanyName.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString(Common.CompanyAddress.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString("Điện thoại: " + Common.CompanyPhone.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);

                //sf.Alignment = StringAlignment.Center;
                //y += titleFont.Height ;
                Font titleFont1 = new Font("Tahoma", 16, System.Drawing.GraphicsUnit.Point);
                //g.DrawString("Công ty TNHH đầu tư Ngọc Dung", titleFont1, Brushes.Black, new RectangleF(3, y, e.PageBounds.Width - 20, 32), sf);

                sf.Alignment = StringAlignment.Center;
                y += titleFont.Height + 15;
                Font titleFont12 = new Font("Tahoma", 16, FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
                g.DrawString(PrintTitle, titleFont12, Brushes.Black, new RectangleF(3, y, e.PageBounds.Width - 20, 32), sf);

                y += titleFont1.Height;
                if (PrintDtImExDetail.Rows.Count > 0)
                {
                    y += titleFont2.Height;
                    sf.Alignment = StringAlignment.Near;
                    g.DrawString("Danh mục sản phẩm",
                       titleFont2, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 20, 32), sf);
                    y += titleFont2.Height + 1;
                }
                #endregion
            }
            else
            {
                y = 30;
            }
            #endregion

            #region Table Header
            for (int i = 0; i < 1; i++)
            {
                x = 20;
                float h = 25;
                float w = 0;
                for (int j = 0; j < 5; j++)
                {
                    if (j > 0) x += w;

                    switch (j)
                    {
                        case 0:
                            w = 45;
                            break;
                        case 1:
                            w = 140;
                            break;
                        case 2:
                            w = 380;
                            break;
                        case 3:
                            w = 60;
                            break;
                        case 4:
                            w = 120;
                            break;

                    }
                    Brush brushHeader = new SolidBrush(Color.WhiteSmoke);
                    Rectangle rect = new Rectangle(Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                    g.FillRectangle(brushHeader, Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                    g.DrawRectangle(new Pen(Brushes.Black), rect);
                }
                // drawstrring
                x = 20;
                string content = "";
                for (int j = 0; j < 5; j++)
                {
                    if (j > 0) x += w;
                    StringFormat contentsf = new StringFormat();
                    contentsf.Alignment = StringAlignment.Near;
                    switch (j)
                    {
                        case 0:
                            w = 45;
                            content = "STT";
                            break;
                        case 1:
                            w = 140;
                            content = "Mã sản phẩm";
                            break;
                        case 2:
                            w = 380;
                            content = "Tên sản phẩm";
                            break;
                        case 3:
                            w = 60;
                            content = "Đơn vị";
                            break;
                        case 4:
                            w = 116;
                            contentsf.Alignment = StringAlignment.Far;
                            content = "Đơn giá(" + Common.MoneyUnit + ")";
                            break;
                    }
                    Font titleFont3 = new Font("Tahoma", 8, FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
                    Rectangle rectC = new Rectangle(Convert.ToInt32(x + colxpadding), Convert.ToInt32(y + colypadding), Convert.ToInt32(w), Convert.ToInt32(h));
                    g.DrawString(content, titleFont3, Brushes.Black, rectC, contentsf);

                }
                y += h;
            }
            #endregion


            #region in noi dung

            for (int i = PrintCurrentRow; i < PrintDtImExDetail.Rows.Count; i++)
            {
                x = 20;
                #region

                if (PrintDtImExDetail.Rows[i]["vtitle"].ToString().Length > 50)
                {
                    h = 40;
                }

                else
                {
                    h = 25;
                }
                #endregion
                float w = 0;
                #region Print Item
                if (PrintDtImExDetail.Rows.Count > 0)
                {
                    #region
                    for (int j = 0; j < 5; j++)
                    {
                        if (j > 0) x += w;
                        switch (j)
                        {
                            case 0:
                                w = 45;
                                break;
                            case 1:
                                w = 140;
                                break;
                            case 2:
                                w = 380;
                                break;
                            case 3:
                                w = 60;
                                break;
                            case 4:
                                w = 120;
                                break;
                        }

                        Rectangle rect = new Rectangle(Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                        g.DrawRectangle(new Pen(Brushes.Black), rect);
                    }
                    // drawstrring
                    #endregion

                    x = 20;
                    string content = "";
                    StringFormat contentsf = new StringFormat();

                    for (int j = 0; j < 5; j++)
                    {
                        if (j > 0) x += w;

                        contentsf.Alignment = StringAlignment.Near;
                        switch (j)
                        {
                            case 0:
                                w = 45;
                                content = (i + 1).ToString();
                                break;
                            case 1:
                                w = 140;
                                content = PrintDtImExDetail.Rows[i]["vkey"].ToString().ToUpper();
                                break;
                            case 2:
                                w = 380;
                                content = PrintDtImExDetail.Rows[i]["vtitle"].ToString();
                                break;
                            case 3:
                                w = 60;
                                content = PrintDtImExDetail.Rows[i]["vunit"].ToString();
                                break;
                            case 4:
                                w = 116;
                                contentsf.Alignment = StringAlignment.Far;
                                content =LCUtiliti.ConvertNumber.FomatPrice(PrintDtImExDetail.Rows[i]["vauthor"].ToString());
                                break;

                        }


                        Font titleFont3 = new Font("Tahoma", 9, System.Drawing.GraphicsUnit.Point);
                        Rectangle rectC = new Rectangle(Convert.ToInt32(x + colxpadding), Convert.ToInt32(y + colypadding), Convert.ToInt32(w), Convert.ToInt32(h));
                        g.DrawString(content, titleFont2, Brushes.Black, rectC, contentsf);
                    }
                    y += h;

                }
                #endregion

                PrintCurrentRow++;
                if (y > e.PageBounds.Height - 115)
                    break;
            }
            #endregion


            bool last = false;

            PrintFromPage++;
            if (PrintCurrentRow >= PrintDtImExDetail.Rows.Count)
            {
                last = true;
            }
            else
            {
                last = false;
            }

            if (last == true)
            {
                g.DrawString("Tổng số sản phẩm: " + PrintDtImExDetail.Rows.Count, titleFont2, Brushes.Black, new RectangleF(20, y += h - 20, e.PageBounds.Width - 40, 32), sf);
                //Pen _pen = new Pen(Color.Black, 1.5F);
                //g.DrawLine(_pen, 600, y + h, 200, y + h);
                sf.Alignment = StringAlignment.Near;
                g.DrawString("Người lập", titleFont2, Brushes.Black, new RectangleF(20, y + h + 10, e.PageBounds.Width - 40, 32), sf);
                sf.Alignment = StringAlignment.Center;
                g.DrawString("Thủ kho", titleFont2, Brushes.Black, new RectangleF(0, y + h + 10, e.PageBounds.Width - 40, 32), sf);
                sf.Alignment = StringAlignment.Far;
                g.DrawString("Giám đốc", titleFont2, Brushes.Black, new RectangleF(0, y + h + 10, e.PageBounds.Width - 120, 32), sf);
            }
            g.DrawString("Trang " + (PrintFromPage).ToString(), titleFont2, Brushes.Black, new RectangleF(e.PageBounds.Width - 120, e.PageBounds.Height - 60, 100, 20));

            if (last == false)
            {
                e.HasMorePages = true;
            }
            else
            {
                e.HasMorePages = false;
                PrintFromPage = 0;
                PrintCurrentRow = 0;
            }
        }
        private void printorder_PrintPageNoAll(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            #region
            if (Convert.ToInt32(lblTotalProduct.Text) == 0 || PrintCurrentRow >= Convert.ToInt32(lblTotalProduct.Text))
            {
                e.HasMorePages = false;
                PrintCurrentRow = 0;
                PrintFromPage = 0;

                return;
            }

            Graphics g = e.Graphics;
            Rectangle rFull = new Rectangle(
                e.PageBounds.Left - 10,
                e.PageBounds.Top,
                e.PageBounds.Right,
                e.PageBounds.Bottom);

            StringFormat sf = new StringFormat();
            float x = 25;
            float y = 25;
            float colxpadding = 3;
            float colypadding = 3;

            Font titleFont = new Font("Tahoma", 9, System.Drawing.GraphicsUnit.Point);
            Font titleFont2 = new Font("Tahoma", 10, System.Drawing.GraphicsUnit.Point);

            if (PrintFromPage == 0)
            {
                #region header

                PrintTitle = "BẢNG BÁO GIÁ";
                g.DrawString(Common.CorporationName.ToString().ToUpper(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString(Common.CompanyName.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString(Common.CompanyAddress.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);
                y += titleFont.Height;
                g.DrawString("Điện thoại: " + Common.CompanyPhone.ToString(), titleFont, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 40, 32), sf);

                //sf.Alignment = StringAlignment.Center;
                //y += titleFont.Height ;
                Font titleFont1 = new Font("Tahoma", 16, System.Drawing.GraphicsUnit.Point);
                //g.DrawString("Công ty TNHH đầu tư Ngọc Dung", titleFont1, Brushes.Black, new RectangleF(3, y, e.PageBounds.Width - 20, 32), sf);

                sf.Alignment = StringAlignment.Center;
                y += titleFont.Height + 15;
                Font titleFont12 = new Font("Tahoma", 16, FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
                g.DrawString(PrintTitle, titleFont12, Brushes.Black, new RectangleF(3, y, e.PageBounds.Width - 20, 32), sf);

                y += titleFont1.Height;
                if (Convert.ToInt32(lblTotalProduct.Text) > 0)
                {
                    y += titleFont2.Height;
                    sf.Alignment = StringAlignment.Near;
                    g.DrawString("Danh mục sản phẩm",
                       titleFont2, Brushes.Black, new RectangleF(20, y, e.PageBounds.Width - 20, 32), sf);
                    y += titleFont2.Height + 1;
                }
                #endregion
            }
            else
            {
                y = 30;
            }
            #endregion

            #region Table Header
            for (int i = 0; i < 1; i++)
            {
                x = 20;
                float h = 25;
                float w = 0;
                for (int j = 0; j < 5; j++)
                {
                    if (j > 0) x += w;

                    switch (j)
                    {
                        case 0:
                            w = 45;
                            break;
                        case 1:
                            w = 140;
                            break;
                        case 2:
                            w = 380;
                            break;
                        case 3:
                            w = 60;
                            break;
                        case 4:
                            w = 120;
                            break;

                    }
                    Brush brushHeader = new SolidBrush(Color.WhiteSmoke);
                    Rectangle rect = new Rectangle(Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                    g.FillRectangle(brushHeader, Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                    g.DrawRectangle(new Pen(Brushes.Black), rect);
                }
                // drawstrring
                x = 20;
                string content = "";
                for (int j = 0; j < 5; j++)
                {
                    if (j > 0) x += w;
                    StringFormat contentsf = new StringFormat();
                    contentsf.Alignment = StringAlignment.Near;
                    switch (j)
                    {
                        case 0:
                            w = 45;
                            content = "STT";
                            break;
                        case 1:
                            w = 140;
                            content = "Mã sản phẩm";
                            break;
                        case 2:
                            w = 380;
                            content = "Tên sản phẩm";
                            break;
                        case 3:
                            w = 60;
                            content = "Đơn vị";
                            break;
                        case 4:
                            w = 116;
                            contentsf.Alignment = StringAlignment.Far;
                            content = "Đơn giá(" + Common.MoneyUnit + ")";
                            break;
                    }
                    Font titleFont3 = new Font("Tahoma", 8, FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
                    Rectangle rectC = new Rectangle(Convert.ToInt32(x + colxpadding), Convert.ToInt32(y + colypadding), Convert.ToInt32(w), Convert.ToInt32(h));
                    g.DrawString(content, titleFont3, Brushes.Black, rectC, contentsf);

                }
                y += h;
            }
            #endregion


            #region in noi dung

            for (int i = PrintCurrentRow; i < Convert.ToInt32(lblTotalProduct.Text); i++)
            {
                x = 20;
                #region

                if (lvListProduct.Items[i].SubItems[3].Text.Length > 50)
                {
                    h = 40;
                }

                else
                {
                    h = 25;
                }
                #endregion
                float w = 0;
                #region Print Item
                if (Convert.ToInt32(lblTotalProduct.Text) > 0)
                {
                    #region
                    for (int j = 0; j < 5; j++)
                    {
                        if (j > 0) x += w;
                        switch (j)
                        {
                            case 0:
                                w = 45;
                                break;
                            case 1:
                                w = 140;
                                break;
                            case 2:
                                w = 380;
                                break;
                            case 3:
                                w = 60;
                                break;
                            case 4:
                                w = 120;
                                break;
                        }

                        Rectangle rect = new Rectangle(Convert.ToInt32(x), Convert.ToInt32(y), Convert.ToInt32(w), Convert.ToInt32(h));
                        g.DrawRectangle(new Pen(Brushes.Black), rect);
                    }
                    // drawstrring
                    #endregion

                    x = 20;
                    string content = "";
                    StringFormat contentsf = new StringFormat();

                    for (int j = 0; j < 5; j++)
                    {
                        if (j > 0) x += w;

                        contentsf.Alignment = StringAlignment.Near;
                        switch (j)
                        {
                            case 0:
                                w = 45;
                                content = lvListProduct.Items[i].SubItems[1].Text;
                                break;
                            case 1:
                                w = 140;
                                content = lvListProduct.Items[i].SubItems[2].Text.ToUpper();
                                break;
                            case 2:
                                w = 380;
                                content = lvListProduct.Items[i].SubItems[3].Text;
                                break;
                            case 3:
                                w = 60;
                                content = lvListProduct.Items[i].SubItems[5].Text;
                                break;
                            case 4:
                                w = 116;
                                contentsf.Alignment = StringAlignment.Far;
                                content = lvListProduct.Items[i].SubItems[6].Text;
                                break;

                        }


                        Font titleFont3 = new Font("Tahoma", 9, System.Drawing.GraphicsUnit.Point);
                        Rectangle rectC = new Rectangle(Convert.ToInt32(x + colxpadding), Convert.ToInt32(y + colypadding), Convert.ToInt32(w), Convert.ToInt32(h));
                        g.DrawString(content, titleFont2, Brushes.Black, rectC, contentsf);
                    }
                    y += h;

                }
                #endregion

                PrintCurrentRow++;
                if (y > e.PageBounds.Height - 115)
                    break;
            }
            #endregion


            bool last = false;

            PrintFromPage++;
            if (PrintCurrentRow >= Convert.ToInt32(lblTotalProduct.Text))
            {
                last = true;
            }
            else
            {
                last = false;
            }

            if (last == true)
            {
                sf.Alignment = StringAlignment.Near;
                g.DrawString("Tổng số sản phẩm: " + lblTotalProduct.Text, titleFont2, Brushes.Black, new RectangleF(20, y += h - 20, e.PageBounds.Width - 40, 32), sf);
                //Pen _pen = new Pen(Color.Black, 1.5F);
                //g.DrawLine(_pen, 600, y + h, 200, y + h);
                sf.Alignment = StringAlignment.Near;
                g.DrawString("Người lập", titleFont2, Brushes.Black, new RectangleF(60, y + h + 10, e.PageBounds.Width - 40, 32), sf);
                sf.Alignment = StringAlignment.Center;
                g.DrawString("Thủ kho", titleFont2, Brushes.Black, new RectangleF(0, y + h + 10, e.PageBounds.Width - 40, 32), sf);
                sf.Alignment = StringAlignment.Far;
                g.DrawString("Giám đốc", titleFont2, Brushes.Black, new RectangleF(0, y + h + 10, e.PageBounds.Width - 140, 32), sf);
            }
            g.DrawString("Trang " + (PrintFromPage).ToString(), titleFont2, Brushes.Black, new RectangleF(e.PageBounds.Width - 120, e.PageBounds.Height - 60, 100, 20));

            if (last == false)
            {
                e.HasMorePages = true;
            }
            else
            {
                e.HasMorePages = false;
                PrintFromPage = 0;
                PrintCurrentRow = 0;
            }
        }
        private void cmnDeleteProduct_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Xóa sản phẩm đang chọn?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                for (int i = 0; i < lvListProduct.Items.Count; i++)
                {
                    if (lvListProduct.Items[i].Selected)
                    {
                        string[] prms = lvListProduct.Items[i].Text.ToString().Split('|');
                        if (prms.Length == 2)
                        {
                            this.iid = prms[0];
                            this.ino = prms[1];
                        }
                        mssql_multicates_multidb_items.dicts_cate_items_Delete_ino(this.ino, Common.ConnectionString);
                        mssql_multicates_multidb_items.dicts_cate_items_Delete(this.iid, Common.ConnectionString);
                        mssql_modcategories_data.cate_Update(lvListProduct.Items[i].Text.ToString(), " iitems = iitems-1 ", Common.ConnectionString);

                        try
                        {
                            mssql_multicates_multidb_items.dicts_onlyitems_delete(this.iid, Common.ConnectionString);
                        }
                        catch
                        { }  
                    }
                }
                LoadProducts();
                LoadCategoriesTree();
            }
        }

        private void cmnuproductprintbarcode_Click(object sender, EventArgs e)
        {
            if (lvListProduct.Items.Count > 0)
            {
                if (lvListProduct.SelectedItems.Count > 0)
                {
                    pnprintproductbarcode.Visible = true;
                    pnAddProduct.Visible = false;

                    string[] prms = lvListProduct.SelectedItems[0].Text.ToString().Split('|');
                    if (prms.Length == 2)
                    {
                        this.iid = prms[0];
                        this.ino = prms[1];
                    }
                    DataTable dt = mssql_multicates_multidb_items.dicts_items_GetDetailByID(this.iid, Common.capp_product_code, Common.ConnectionString);

                    if (dt.Rows.Count > 0)
                    {
                        txtprintbcprocode.Text = dt.Rows[0]["vkey"].ToString();
                        txtprintbcproname.Text = dt.Rows[0]["vtitle"].ToString();
                        txtprintbcproprice.Text = dt.Rows[0]["vauthor"].ToString();
                        barcodecontrol bcc = new barcodecontrol();
                        bcc.Width = 144;
                        bcc.Height = 70;
                        bcc.BarWidth = 142;
                        bcc.BarHeight = 32;
                        bcc.PrintCode = txtprintbcprocode.Text;
                        bcc.PrintEnable = true;
                        bcc.PrintTitle = txtprintbcproname.Text;
                        bcc.PrintPrice = txtprintbcproprice.Text;

                        pnprintbcpropreview.Controls.Clear();
                        pnprintbcpropreview.Controls.Add(bcc);
                    }

                }
            }
        }

        private void btnprintbcprintbarcodes_Click(object sender, EventArgs e)
        {
            if (Common.fbarcode == null)
            {
                Common.fbarcode = new frmbarcode();
                frmbarcode.PrintBCodeList.Clear();
                for (int i = 0; i < nuprintbcitems.Value; i++)
                {
                    barcodecontrol bcc = new barcodecontrol();
                    bcc.Index = i;
                    bcc.Width = 142;
                    bcc.Height = 70;
                    bcc.BarWidth = 140;
                    bcc.BarHeight = 22;
                    bcc.PrintCode = txtprintbcprocode.Text;
                    bcc.PrintTitle = txtprintbcproname.Text;
                    bcc.PrintEnable = true;
                    bcc.PrintPrice = txtprintbcproprice.Text;
                    frmbarcode.PrintBCodeList.Add(bcc);
                }
                frmbarcode.PrintBCodeList.FormatList();
            }
            Common.fbarcode.MdiParent = this.MdiParent;
            Common.fbarcode.Show();
            Common.fbarcode.Focus();
        }

        private void btnprintbccancel_Click(object sender, EventArgs e)
        {
            pnprintproductbarcode.Visible = false;
        }

        private void btnHuyCategory_Click(object sender, EventArgs e)
        {
            txtCateName.Text = "";
            pnAddCategory.Visible = false;
        }

        private void btnprintnoall_Click(object sender, EventArgs e)
        {
            printdocument = new PrintDocument();
            printdocument.PrintPage += new PrintPageEventHandler(printorder_PrintPageNoAll);
            PrintDialog pdl = new PrintDialog();
            //if (pdl.ShowDialog() == DialogResult.OK)
            //{
                //printdocument.PrinterSettings = pdl.PrinterSettings;
                printDocument2.Print();
            //}
            //printDocument2.Print();
        }
    }
}
