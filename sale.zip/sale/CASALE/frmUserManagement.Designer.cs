﻿using CASALE.Class;
namespace CASALE
{
    partial class frmUserManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.frmusermanagement = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lnkcreatenew = new System.Windows.Forms.LinkLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.lblsum = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lvlist = new System.Windows.Forms.ListView();
            this.id = new System.Windows.Forms.ColumnHeader();
            this.stt = new System.Windows.Forms.ColumnHeader();
            this.vid = new System.Windows.Forms.ColumnHeader();
            this.fullname = new System.Windows.Forms.ColumnHeader();
            this.age = new System.Windows.Forms.ColumnHeader();
            this.cmtnd = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.adress = new System.Windows.Forms.ColumnHeader();
            this.phone = new System.Windows.Forms.ColumnHeader();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.status = new System.Windows.Forms.ColumnHeader();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmnupdate = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.cmndelete = new System.Windows.Forms.ToolStripMenuItem();
            this.pndetail = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ddatengaycap = new System.Windows.Forms.DateTimePicker();
            this.txtbirthday = new System.Windows.Forms.DateTimePicker();
            this.chksetpassword = new System.Windows.Forms.CheckBox();
            this.txtlname = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.rdofemale = new System.Windows.Forms.RadioButton();
            this.rdomale = new System.Windows.Forms.RadioButton();
            this.label17 = new System.Windows.Forms.Label();
            this.chkStatus = new System.Windows.Forms.CheckBox();
            this.label14 = new System.Windows.Forms.Label();
            this.nhaplai = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btncancel = new System.Windows.Forms.Button();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAdress = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCMT = new System.Windows.Forms.TextBox();
            this.txtfname = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnsave = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.pndetail.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lnkcreatenew);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(910, 23);
            this.panel1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(2, 5);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(291, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "QUẢN LÝ NGƯỜI DÙNG HỆ THỐNG";
            // 
            // lnkcreatenew
            // 
            this.lnkcreatenew.AutoSize = true;
            this.lnkcreatenew.LinkColor = System.Drawing.Color.White;
            this.lnkcreatenew.Location = new System.Drawing.Point(454, 6);
            this.lnkcreatenew.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lnkcreatenew.Name = "lnkcreatenew";
            this.lnkcreatenew.Size = new System.Drawing.Size(115, 15);
            this.lnkcreatenew.TabIndex = 0;
            this.lnkcreatenew.TabStop = true;
            this.lnkcreatenew.Text = "Tạo người dùng mới";
            this.lnkcreatenew.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkcreatenew_LinkClicked);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(99, 485);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 15);
            this.label4.TabIndex = 27;
            this.label4.Text = "người dùng";
            // 
            // lblsum
            // 
            this.lblsum.AutoSize = true;
            this.lblsum.ForeColor = System.Drawing.Color.Black;
            this.lblsum.Location = new System.Drawing.Point(45, 485);
            this.lblsum.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblsum.Name = "lblsum";
            this.lblsum.Size = new System.Drawing.Size(13, 15);
            this.lblsum.TabIndex = 26;
            this.lblsum.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(5, 485);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 15);
            this.label2.TabIndex = 25;
            this.label2.Text = "Tổng:";
            // 
            // lvlist
            // 
            this.lvlist.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.id,
            this.stt,
            this.vid,
            this.fullname,
            this.age,
            this.cmtnd,
            this.columnHeader2,
            this.adress,
            this.phone,
            this.columnHeader1,
            this.status});
            this.lvlist.ContextMenuStrip = this.contextMenuStrip1;
            this.lvlist.Dock = System.Windows.Forms.DockStyle.Top;
            this.lvlist.FullRowSelect = true;
            this.lvlist.GridLines = true;
            this.lvlist.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvlist.Location = new System.Drawing.Point(0, 23);
            this.lvlist.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lvlist.Name = "lvlist";
            this.lvlist.Size = new System.Drawing.Size(910, 460);
            this.lvlist.TabIndex = 24;
            this.lvlist.UseCompatibleStateImageBehavior = false;
            this.lvlist.View = System.Windows.Forms.View.Details;
            this.lvlist.SelectedIndexChanged += new System.EventHandler(this.lvlist_SelectedIndexChanged);
            // 
            // id
            // 
            this.id.Width = 0;
            // 
            // stt
            // 
            this.stt.Text = "STT";
            this.stt.Width = 51;
            // 
            // vid
            // 
            this.vid.Text = "Mã đăng nhập";
            this.vid.Width = 128;
            // 
            // fullname
            // 
            this.fullname.Text = "Họ và Tên";
            this.fullname.Width = 157;
            // 
            // age
            // 
            this.age.Text = "Ngày sinh";
            this.age.Width = 122;
            // 
            // cmtnd
            // 
            this.cmtnd.Text = "CMTND";
            this.cmtnd.Width = 87;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Giới tính";
            this.columnHeader2.Width = 81;
            // 
            // adress
            // 
            this.adress.Text = "Địa chỉ";
            this.adress.Width = 184;
            // 
            // phone
            // 
            this.phone.Text = "Điện thoại";
            this.phone.Width = 107;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Email";
            // 
            // status
            // 
            this.status.Text = "Trạng thái";
            this.status.Width = 95;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmnupdate,
            this.toolStripMenuItem1,
            this.cmndelete});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(222, 54);
            // 
            // cmnupdate
            // 
            this.cmnupdate.Image = global::CASALE.Properties.Resources.edit1;
            this.cmnupdate.Name = "cmnupdate";
            this.cmnupdate.Size = new System.Drawing.Size(221, 22);
            this.cmnupdate.Text = "Cập nhật thông tin";
            this.cmnupdate.Click += new System.EventHandler(this.cmnupdate_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(218, 6);
            // 
            // cmndelete
            // 
            this.cmndelete.Image = global::CASALE.Properties.Resources.trash_can;
            this.cmndelete.Name = "cmndelete";
            this.cmndelete.Size = new System.Drawing.Size(221, 22);
            this.cmndelete.Text = "Xóa người dùng đang chọn";
            this.cmndelete.Click += new System.EventHandler(this.cmndelete_Click);
            // 
            // pndetail
            // 
            this.pndetail.Controls.Add(this.panel2);
            this.pndetail.Controls.Add(this.label3);
            this.pndetail.Controls.Add(this.ddatengaycap);
            this.pndetail.Controls.Add(this.txtbirthday);
            this.pndetail.Controls.Add(this.chksetpassword);
            this.pndetail.Controls.Add(this.txtlname);
            this.pndetail.Controls.Add(this.label16);
            this.pndetail.Controls.Add(this.label12);
            this.pndetail.Controls.Add(this.rdofemale);
            this.pndetail.Controls.Add(this.rdomale);
            this.pndetail.Controls.Add(this.label17);
            this.pndetail.Controls.Add(this.chkStatus);
            this.pndetail.Controls.Add(this.label14);
            this.pndetail.Controls.Add(this.nhaplai);
            this.pndetail.Controls.Add(this.txtPassword);
            this.pndetail.Controls.Add(this.label19);
            this.pndetail.Controls.Add(this.label11);
            this.pndetail.Controls.Add(this.txtEmail);
            this.pndetail.Controls.Add(this.label10);
            this.pndetail.Controls.Add(this.btncancel);
            this.pndetail.Controls.Add(this.txtPhone);
            this.pndetail.Controls.Add(this.label9);
            this.pndetail.Controls.Add(this.txtAdress);
            this.pndetail.Controls.Add(this.label8);
            this.pndetail.Controls.Add(this.txtCMT);
            this.pndetail.Controls.Add(this.txtfname);
            this.pndetail.Controls.Add(this.label18);
            this.pndetail.Controls.Add(this.label15);
            this.pndetail.Controls.Add(this.label13);
            this.pndetail.Controls.Add(this.label7);
            this.pndetail.Controls.Add(this.txtId);
            this.pndetail.Controls.Add(this.label6);
            this.pndetail.Controls.Add(this.btnsave);
            this.pndetail.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pndetail.ForeColor = System.Drawing.Color.Black;
            this.pndetail.Location = new System.Drawing.Point(44, 59);
            this.pndetail.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pndetail.Name = "pndetail";
            this.pndetail.Size = new System.Drawing.Size(701, 373);
            this.pndetail.TabIndex = 29;
            this.pndetail.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel2.Controls.Add(this.label5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(701, 29);
            this.panel2.TabIndex = 32;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(2, 7);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(183, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "THÔNG TIN NGƯỜI DÙNG";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(223, 167);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 17);
            this.label3.TabIndex = 31;
            this.label3.Text = "(dd/MM/yyyy)";
            // 
            // ddatengaycap
            // 
            this.ddatengaycap.CustomFormat = "dd/MM/yyyy";
            this.ddatengaycap.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddatengaycap.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.ddatengaycap.Location = new System.Drawing.Point(303, 191);
            this.ddatengaycap.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ddatengaycap.Name = "ddatengaycap";
            this.ddatengaycap.Size = new System.Drawing.Size(98, 25);
            this.ddatengaycap.TabIndex = 30;
            // 
            // txtbirthday
            // 
            this.txtbirthday.CustomFormat = "dd/MM/yyyy";
            this.txtbirthday.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbirthday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtbirthday.Location = new System.Drawing.Point(110, 162);
            this.txtbirthday.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtbirthday.Name = "txtbirthday";
            this.txtbirthday.Size = new System.Drawing.Size(96, 25);
            this.txtbirthday.TabIndex = 30;
            // 
            // chksetpassword
            // 
            this.chksetpassword.AutoSize = true;
            this.chksetpassword.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chksetpassword.Location = new System.Drawing.Point(526, 80);
            this.chksetpassword.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.chksetpassword.Name = "chksetpassword";
            this.chksetpassword.Size = new System.Drawing.Size(138, 21);
            this.chksetpassword.TabIndex = 29;
            this.chksetpassword.Text = "Cập nhật mật khẩu";
            this.chksetpassword.UseVisualStyleBackColor = true;
            this.chksetpassword.Visible = false;
            this.chksetpassword.CheckedChanged += new System.EventHandler(this.chksetpassword_CheckedChanged);
            // 
            // txtlname
            // 
            this.txtlname.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlname.Location = new System.Drawing.Point(355, 111);
            this.txtlname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtlname.Name = "txtlname";
            this.txtlname.Size = new System.Drawing.Size(168, 25);
            this.txtlname.TabIndex = 4;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(283, 115);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(31, 17);
            this.label16.TabIndex = 28;
            this.label16.Text = "Tên";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label12.ForeColor = System.Drawing.Color.DimGray;
            this.label12.Location = new System.Drawing.Point(18, 31);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(281, 13);
            this.label12.TabIndex = 26;
            this.label12.Text = "Cung cấp những thông tin theo yêu cầu sau đây";
            // 
            // rdofemale
            // 
            this.rdofemale.AutoSize = true;
            this.rdofemale.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdofemale.Location = new System.Drawing.Point(176, 138);
            this.rdofemale.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rdofemale.Name = "rdofemale";
            this.rdofemale.Size = new System.Drawing.Size(45, 21);
            this.rdofemale.TabIndex = 6;
            this.rdofemale.Text = "Nữ";
            this.rdofemale.UseVisualStyleBackColor = true;
            // 
            // rdomale
            // 
            this.rdomale.AutoSize = true;
            this.rdomale.Checked = true;
            this.rdomale.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdomale.Location = new System.Drawing.Point(110, 137);
            this.rdomale.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rdomale.Name = "rdomale";
            this.rdomale.Size = new System.Drawing.Size(55, 21);
            this.rdomale.TabIndex = 5;
            this.rdomale.TabStop = true;
            this.rdomale.Text = "Nam";
            this.rdomale.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(15, 137);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(57, 17);
            this.label17.TabIndex = 24;
            this.label17.Text = "Giới tính";
            // 
            // chkStatus
            // 
            this.chkStatus.AutoSize = true;
            this.chkStatus.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkStatus.Location = new System.Drawing.Point(110, 307);
            this.chkStatus.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.chkStatus.Name = "chkStatus";
            this.chkStatus.Size = new System.Drawing.Size(331, 21);
            this.chkStatus.TabIndex = 12;
            this.chkStatus.Text = "chọn: kích hoạt, người dùng có thể sử dụng hệ thống";
            this.chkStatus.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(15, 306);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(67, 17);
            this.label14.TabIndex = 20;
            this.label14.Text = "Trạng thái";
            // 
            // nhaplai
            // 
            this.nhaplai.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nhaplai.Location = new System.Drawing.Point(350, 79);
            this.nhaplai.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.nhaplai.Name = "nhaplai";
            this.nhaplai.PasswordChar = '*';
            this.nhaplai.Size = new System.Drawing.Size(172, 25);
            this.nhaplai.TabIndex = 2;
            // 
            // txtPassword
            // 
            this.txtPassword.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(109, 80);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(167, 25);
            this.txtPassword.TabIndex = 2;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(280, 82);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(57, 17);
            this.label19.TabIndex = 17;
            this.label19.Text = "Nhập lại";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(16, 81);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(64, 17);
            this.label11.TabIndex = 17;
            this.label11.Text = "Mật khẩu";
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(110, 281);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(216, 25);
            this.txtEmail.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(15, 283);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 17);
            this.label10.TabIndex = 11;
            this.label10.Text = "Thư điện tử";
            // 
            // btncancel
            // 
            this.btncancel.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancel.Image = global::CASALE.Properties.Resources.action_delete;
            this.btncancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btncancel.Location = new System.Drawing.Point(259, 332);
            this.btncancel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(89, 29);
            this.btncancel.TabIndex = 14;
            this.btncancel.Text = "Hủy bỏ";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // txtPhone
            // 
            this.txtPhone.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhone.Location = new System.Drawing.Point(110, 251);
            this.txtPhone.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(112, 25);
            this.txtPhone.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(15, 253);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 17);
            this.label9.TabIndex = 8;
            this.label9.Text = "Điện thoại";
            // 
            // txtAdress
            // 
            this.txtAdress.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAdress.Location = new System.Drawing.Point(110, 221);
            this.txtAdress.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtAdress.Name = "txtAdress";
            this.txtAdress.Size = new System.Drawing.Size(362, 25);
            this.txtAdress.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(15, 219);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 17);
            this.label8.TabIndex = 6;
            this.label8.Text = "Địa chỉ";
            // 
            // txtCMT
            // 
            this.txtCMT.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCMT.Location = new System.Drawing.Point(110, 192);
            this.txtCMT.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtCMT.Name = "txtCMT";
            this.txtCMT.Size = new System.Drawing.Size(112, 25);
            this.txtCMT.TabIndex = 8;
            // 
            // txtfname
            // 
            this.txtfname.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfname.Location = new System.Drawing.Point(110, 111);
            this.txtfname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtfname.Name = "txtfname";
            this.txtfname.Size = new System.Drawing.Size(165, 25);
            this.txtfname.TabIndex = 3;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(222, 194);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(65, 17);
            this.label18.TabIndex = 4;
            this.label18.Text = "Ngày cấp";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(15, 166);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(67, 17);
            this.label15.TabIndex = 4;
            this.label15.Text = "Ngày sinh";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(15, 194);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(85, 17);
            this.label13.TabIndex = 4;
            this.label13.Text = "Số CMTND ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(16, 107);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 17);
            this.label7.TabIndex = 4;
            this.label7.Text = "Họ";
            // 
            // txtId
            // 
            this.txtId.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtId.Location = new System.Drawing.Point(109, 50);
            this.txtId.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(167, 25);
            this.txtId.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(16, 52);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 17);
            this.label6.TabIndex = 2;
            this.label6.Text = "Mã nhân viên";
            // 
            // btnsave
            // 
            this.btnsave.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsave.Image = global::CASALE.Properties.Resources.disk_blue;
            this.btnsave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsave.Location = new System.Drawing.Point(110, 332);
            this.btnsave.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(139, 29);
            this.btnsave.TabIndex = 13;
            this.btnsave.Text = "Lưu thông tin";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // frmUserManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(910, 524);
            this.Controls.Add(this.pndetail);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblsum);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lvlist);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "frmUserManagement";
            this.Text = "Danh sách người dùng";
            this.Load += new System.EventHandler(this.frmUserManagement_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.lvlist, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.lblsum, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.pndetail, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.pndetail.ResumeLayout(false);
            this.pndetail.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel lnkcreatenew;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblsum;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView lvlist;
        private System.Windows.Forms.ColumnHeader id;
        private System.Windows.Forms.ColumnHeader stt;
        private System.Windows.Forms.ColumnHeader vid;
        private System.Windows.Forms.ColumnHeader fullname;
        private System.Windows.Forms.ColumnHeader age;
        private System.Windows.Forms.ColumnHeader cmtnd;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader adress;
        private System.Windows.Forms.ColumnHeader phone;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader status;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cmnupdate;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cmndelete;
        private System.Windows.Forms.Panel pndetail;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker ddatengaycap;
        private System.Windows.Forms.DateTimePicker txtbirthday;
        private System.Windows.Forms.CheckBox chksetpassword;
        private System.Windows.Forms.TextBox txtlname;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RadioButton rdofemale;
        private System.Windows.Forms.RadioButton rdomale;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox chkStatus;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAdress;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCMT;
        private System.Windows.Forms.TextBox txtfname;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.TextBox nhaplai;
        private System.Windows.Forms.Label label19;
    }
}