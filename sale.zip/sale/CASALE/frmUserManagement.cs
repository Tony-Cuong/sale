﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LCMembersUtiliti;
using CASALE.Class;
namespace CASALE
{
    public partial class frmUserManagement : templates
    {
        bool binsertupdate = false; // insert
        int iselectedid = -1;// lưu trữ mã của item đang chọn.
        protected string stroldpwd = "";
        protected int _index = 0;
        public frmUserManagement()
        {
            InitializeComponent();
        }

        private void frmUserManagement_Load(object sender, EventArgs e)
        {
            LoadMembersList();
        }
        protected void LoadMembersList()
        {

            this.lvlist.Items.Clear();
            try
            {


                DataTable table = Members.users_getTopMemberslist("-1", "", -1, Common.ConnectionString);
                if (table.Rows.Count > 0)
                {
                    for (int i = 0; i < table.Rows.Count; i++)
                    {
                        ListViewItem lvi = new ListViewItem(table.Rows[i]["iuser_id"].ToString());

                        lvi.SubItems.Add((i + 1).ToString());
                        lvi.SubItems.Add(table.Rows[i]["vuserun"].ToString());
                        lvi.SubItems.Add(table.Rows[i]["vfname"].ToString() + " " + table.Rows[i]["vlname"].ToString());
                        lvi.SubItems.Add(Common.FormatDate_(table.Rows[i]["dbirthday"]));
                        lvi.SubItems.Add(table.Rows[i]["vidcard"].ToString());
                        lvi.SubItems.Add(Common.GenderName(Convert.ToInt32(table.Rows[i]["igender"])));
                        lvi.SubItems.Add(table.Rows[i]["vaddress"].ToString());
                        lvi.SubItems.Add(table.Rows[i]["vphone"].ToString());
                        lvi.SubItems.Add(table.Rows[i]["vemail"].ToString());
                        lvi.SubItems.Add(Common.UserStatus(Convert.ToInt32(table.Rows[i]["istatus"])));
                        lvlist.Items.Add(lvi);
                        lblsum.Text = (this._index = i + 1).ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ;
            }
        }

        private void lnkcreatenew_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            txtId.Enabled = true;
            txtId.Text = "";
            txtfname.Text = "";
            txtlname.Text = "";
            txtAdress.Text = "";
            txtCMT.Text = "";
            txtEmail.Text = "";
            txtPassword.Text = "";
            txtPhone.Text = "";
            txtPhone.Text = "";
            txtId.Focus();
            pndetail.Visible = true;
            binsertupdate = false;

            txtPassword.Enabled = true;
            chksetpassword.Visible = false;
        }

        private void lvlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvlist.SelectedItems.Count > 0)
            {
                iselectedid = Convert.ToInt32(lvlist.SelectedItems[0].Text.ToString());
            }
        }

        private void cmndelete_Click(object sender, EventArgs e)
        {
            if (lvlist.Items.Count > 0)
            {
                if (MessageBox.Show("Xóa thông tin đang chọn?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Members.users_delete(iselectedid.ToString(), Common.ConnectionString);
                    LoadMembersList();
                }
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtId.Text.Trim().Length < 6)
            {
                MessageBox.Show("Mã đăng nhập không hợp lệ.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtId.Focus();
                return;
            }
            if (!nhaplai.Text.Trim().Equals(txtPassword.Text.Trim()))
            {
                MessageBox.Show("Hai mật khẩu không khớp với nhau.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                nhaplai.Focus();
                return;
            }
            string _gender = "0";
            if (rdomale.Checked == true)
            {
                _gender = "1";
            }
            string _status = "0";
            if (chkStatus.Checked == true)
            {
                _status = "1";
            }

            //
            // xử lý insert/update
            if (binsertupdate == false) // insert
            {
                try
                {
                    Members.users_insert(txtId.Text, txtPassword.Text, txtfname.Text, txtlname.Text, _gender, txtbirthday.Value.ToString("MM/dd/yyyy"), txtCMT.Text, txtAdress.Text, txtPhone.Text, txtEmail.Text, "-1", ddatengaycap.Value.ToString(), "", "-1", _status,
                        Common.ConnectionString);
                    MessageBox.Show("Thêm thành công.");
                    LoadMembersList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
            else // update
            {
                Members.users_update(iselectedid, txtId.Text, txtfname.Text, txtlname.Text, Convert.ToInt32(_gender), txtbirthday.Value, txtCMT.Text, txtAdress.Text, txtPhone.Text, txtEmail.Text, -1, Common.ConnectionString);
                if (chksetpassword.Checked == true)
                {
                    Members.users_update_updatepassword(iselectedid.ToString(), txtId.Text, txtPassword.Text, Common.ConnectionString);
                }

                MessageBox.Show("Thông tin đã được cập nhật");
                LoadMembersList();
            }

            pndetail.Visible = false;
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            pndetail.Visible = false;
        }

        private void cmnupdate_Click(object sender, EventArgs e)
        {
            if (lvlist.Items.Count > 0)
            {
                if (lvlist.SelectedItems.Count > 0)
                {
                    string _gender = "";
                    string _status = "";
                    DataTable dt = new DataTable();
                    dt = Members.users_getdetailbyid(iselectedid.ToString(), Common.ConnectionString);
                    if (dt.Rows.Count > 0)
                    {
                        txtId.Enabled = false;
                        txtId.Text = dt.Rows[0]["vuserun"].ToString();
                        txtfname.Text = dt.Rows[0]["vfname"].ToString();
                        txtlname.Text = dt.Rows[0]["vlname"].ToString();
                        txtbirthday.Value = Convert.ToDateTime(dt.Rows[0]["dbirthday"]);
                        txtCMT.Text = dt.Rows[0]["vidcard"].ToString();
                        txtPhone.Text = dt.Rows[0]["vphone"].ToString();
                        txtAdress.Text = dt.Rows[0]["vaddress"].ToString();
                        txtEmail.Text = dt.Rows[0]["vemail"].ToString();
                        ddatengaycap.Value = Convert.ToDateTime(dt.Rows[0]["vavatar"]);
                        _gender = dt.Rows[0]["igender"].ToString();
                        if (_gender.Equals("1"))
                        {
                            rdomale.Checked = true;
                        }
                        else
                        {
                            rdofemale.Checked = true;
                        }

                        _status = dt.Rows[0]["istatus"].ToString();
                        if (_status.Equals("1"))
                        {
                            chkStatus.Checked = true;
                        }
                        else
                        {
                            chkStatus.Checked = false;
                        }

                        this.stroldpwd = dt.Rows[0]["vuserpwd"].ToString();

                        txtPassword.Enabled = false;
                        nhaplai.Enabled = false;
                        chksetpassword.Visible = true;

                    }
                    pndetail.Visible = true;
                    binsertupdate = true;
                }
            }
        }

        private void chksetpassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chksetpassword.Checked == true)
            {
                txtPassword.Enabled = true;
                nhaplai.Enabled = true;
            }
            else
            {

                txtPassword.Enabled = false;
                nhaplai.Enabled = false;
            }
        }
    }
}
