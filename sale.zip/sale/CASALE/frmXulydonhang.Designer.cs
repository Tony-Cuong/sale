﻿using CASALE.Class;
namespace CASALE
{
    partial class frmXulydonhang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.frmxulydonhang = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.cmborderlistpages = new System.Windows.Forms.ComboBox();
            this.cmborderlistitemsperpage = new System.Windows.Forms.ComboBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtorderlistkeyword = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbordersliststatus = new System.Windows.Forms.ComboBox();
            this.btncheckorderonline = new System.Windows.Forms.Button();
            this.lvordertiems = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader6 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader7 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader9 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader8 = new System.Windows.Forms.ColumnHeader();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmndetail = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.cmndelete = new System.Windows.Forms.ToolStripMenuItem();
            this.lblmoneyunit = new System.Windows.Forms.Label();
            this.lbltatolOrder = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pndetail = new System.Windows.Forms.Panel();
            this.lbldoc = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.lblmoneyunitdetail = new System.Windows.Forms.Label();
            this.cmborderdetailstatus = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.bntorderupdatestatus = new System.Windows.Forms.Button();
            this.btnorderdetailclose = new System.Windows.Forms.Button();
            this.lbltatoldetail = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lvorderdetail = new System.Windows.Forms.ListView();
            this.Id = new System.Windows.Forms.ColumnHeader();
            this.Code = new System.Windows.Forms.ColumnHeader();
            this.Namesale = new System.Windows.Forms.ColumnHeader();
            this.Price = new System.Windows.Forms.ColumnHeader();
            this.dv = new System.Windows.Forms.ColumnHeader();
            this.Quantity = new System.Windows.Forms.ColumnHeader();
            this.Sl = new System.Windows.Forms.ColumnHeader();
            this.Tax = new System.Windows.Forms.ColumnHeader();
            this.Money = new System.Windows.Forms.ColumnHeader();
            this.label12 = new System.Windows.Forms.Label();
            this.txtInformation = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtFullname = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.pndetail.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(926, 32);
            this.panel1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(3, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(176, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "QUẢN LÝ BÁN HÀNG";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.cmborderlistpages);
            this.panel2.Controls.Add(this.cmborderlistitemsperpage);
            this.panel2.Controls.Add(this.btnSearch);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.txtorderlistkeyword);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.cmbordersliststatus);
            this.panel2.Controls.Add(this.btncheckorderonline);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 32);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(926, 45);
            this.panel2.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label9.Location = new System.Drawing.Point(299, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 13);
            this.label9.TabIndex = 77;
            this.label9.Text = "Số mục / trang";
            // 
            // cmborderlistpages
            // 
            this.cmborderlistpages.FormattingEnabled = true;
            this.cmborderlistpages.Location = new System.Drawing.Point(352, 19);
            this.cmborderlistpages.Name = "cmborderlistpages";
            this.cmborderlistpages.Size = new System.Drawing.Size(46, 23);
            this.cmborderlistpages.TabIndex = 76;
            // 
            // cmborderlistitemsperpage
            // 
            this.cmborderlistitemsperpage.FormattingEnabled = true;
            this.cmborderlistitemsperpage.Location = new System.Drawing.Point(302, 19);
            this.cmborderlistitemsperpage.Name = "cmborderlistitemsperpage";
            this.cmborderlistitemsperpage.Size = new System.Drawing.Size(48, 23);
            this.cmborderlistitemsperpage.TabIndex = 75;
            // 
            // btnSearch
            // 
            this.btnSearch.Image = global::CASALE.Properties.Resources.book_blue_view;
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnSearch.Location = new System.Drawing.Point(400, 18);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(78, 24);
            this.btnSearch.TabIndex = 74;
            this.btnSearch.Text = "Hiển thị";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label17.Location = new System.Drawing.Point(7, 3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(97, 13);
            this.label17.TabIndex = 80;
            this.label17.Text = "Trạng thái xử lý";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(484, 17);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 24);
            this.button1.TabIndex = 73;
            this.button1.Text = "Xuất ra Excel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtorderlistkeyword
            // 
            this.txtorderlistkeyword.Location = new System.Drawing.Point(192, 19);
            this.txtorderlistkeyword.Name = "txtorderlistkeyword";
            this.txtorderlistkeyword.Size = new System.Drawing.Size(108, 22);
            this.txtorderlistkeyword.TabIndex = 72;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label11.Location = new System.Drawing.Point(191, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 13);
            this.label11.TabIndex = 78;
            this.label11.Text = "Từ khóa";
            // 
            // cmbordersliststatus
            // 
            this.cmbordersliststatus.FormattingEnabled = true;
            this.cmbordersliststatus.Location = new System.Drawing.Point(12, 19);
            this.cmbordersliststatus.Name = "cmbordersliststatus";
            this.cmbordersliststatus.Size = new System.Drawing.Size(178, 23);
            this.cmbordersliststatus.TabIndex = 79;
            // 
            // btncheckorderonline
            // 
            this.btncheckorderonline.Enabled = false;
            this.btncheckorderonline.Location = new System.Drawing.Point(592, 17);
            this.btncheckorderonline.Name = "btncheckorderonline";
            this.btncheckorderonline.Size = new System.Drawing.Size(189, 24);
            this.btncheckorderonline.TabIndex = 81;
            this.btncheckorderonline.Text = "Nhận đơn hàng trực tuyến";
            this.btncheckorderonline.UseVisualStyleBackColor = true;
            this.btncheckorderonline.Visible = false;
            // 
            // lvordertiems
            // 
            this.lvordertiems.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader9,
            this.columnHeader8});
            this.lvordertiems.ContextMenuStrip = this.contextMenuStrip1;
            this.lvordertiems.Dock = System.Windows.Forms.DockStyle.Top;
            this.lvordertiems.FullRowSelect = true;
            this.lvordertiems.GridLines = true;
            this.lvordertiems.Location = new System.Drawing.Point(0, 77);
            this.lvordertiems.Name = "lvordertiems";
            this.lvordertiems.Size = new System.Drawing.Size(926, 456);
            this.lvordertiems.TabIndex = 9;
            this.lvordertiems.UseCompatibleStateImageBehavior = false;
            this.lvordertiems.View = System.Windows.Forms.View.Details;
            this.lvordertiems.SelectedIndexChanged += new System.EventHandler(this.lvordertiems_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID";
            this.columnHeader1.Width = 0;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "STT";
            this.columnHeader2.Width = 47;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Mã hóa đơn";
            this.columnHeader3.Width = 89;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Tên khách hàng";
            this.columnHeader4.Width = 150;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Thông tin";
            this.columnHeader5.Width = 200;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Ngày tháng";
            this.columnHeader6.Width = 91;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Giá trị";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader7.Width = 103;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "T.Thái";
            this.columnHeader9.Width = 70;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "N.Viên";
            this.columnHeader8.Width = 140;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmndetail,
            this.toolStripMenuItem1,
            this.cmndelete});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(209, 54);
            // 
            // cmndetail
            // 
            this.cmndetail.Image = global::CASALE.Properties.Resources.edit1;
            this.cmndetail.Name = "cmndetail";
            this.cmndetail.Size = new System.Drawing.Size(208, 22);
            this.cmndetail.Text = "Chi tiết đơn hàng";
            this.cmndetail.Click += new System.EventHandler(this.cmndetail_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(205, 6);
            // 
            // cmndelete
            // 
            this.cmndelete.Image = global::CASALE.Properties.Resources.trash_can;
            this.cmndelete.Name = "cmndelete";
            this.cmndelete.Size = new System.Drawing.Size(208, 22);
            this.cmndelete.Text = "Xóa đơn hàng đang chọn";
            this.cmndelete.Click += new System.EventHandler(this.cmndelete_Click);
            // 
            // lblmoneyunit
            // 
            this.lblmoneyunit.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblmoneyunit.Location = new System.Drawing.Point(712, 536);
            this.lblmoneyunit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmoneyunit.Name = "lblmoneyunit";
            this.lblmoneyunit.Size = new System.Drawing.Size(36, 18);
            this.lblmoneyunit.TabIndex = 72;
            this.lblmoneyunit.Text = "VNĐ";
            this.lblmoneyunit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbltatolOrder
            // 
            this.lbltatolOrder.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbltatolOrder.Location = new System.Drawing.Point(589, 537);
            this.lbltatolOrder.Name = "lbltatolOrder";
            this.lbltatolOrder.Size = new System.Drawing.Size(110, 14);
            this.lbltatolOrder.TabIndex = 73;
            this.lbltatolOrder.Text = "0";
            this.lbltatolOrder.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(504, 537);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 15);
            this.label2.TabIndex = 71;
            this.label2.Text = "Tổng cộng :";
            // 
            // pndetail
            // 
            this.pndetail.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.pndetail.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pndetail.Controls.Add(this.lbldoc);
            this.pndetail.Controls.Add(this.panel3);
            this.pndetail.Controls.Add(this.lblmoneyunitdetail);
            this.pndetail.Controls.Add(this.cmborderdetailstatus);
            this.pndetail.Controls.Add(this.label4);
            this.pndetail.Controls.Add(this.bntorderupdatestatus);
            this.pndetail.Controls.Add(this.btnorderdetailclose);
            this.pndetail.Controls.Add(this.lbltatoldetail);
            this.pndetail.Controls.Add(this.groupBox1);
            this.pndetail.Controls.Add(this.label12);
            this.pndetail.Controls.Add(this.txtInformation);
            this.pndetail.Controls.Add(this.label7);
            this.pndetail.Controls.Add(this.txtEmail);
            this.pndetail.Controls.Add(this.label5);
            this.pndetail.Controls.Add(this.txtPhone);
            this.pndetail.Controls.Add(this.label6);
            this.pndetail.Controls.Add(this.txtAddress);
            this.pndetail.Controls.Add(this.label13);
            this.pndetail.Controls.Add(this.txtFullname);
            this.pndetail.Controls.Add(this.label14);
            this.pndetail.Controls.Add(this.txtId);
            this.pndetail.Controls.Add(this.label15);
            this.pndetail.Location = new System.Drawing.Point(67, 99);
            this.pndetail.Name = "pndetail";
            this.pndetail.Size = new System.Drawing.Size(775, 397);
            this.pndetail.TabIndex = 74;
            this.pndetail.Visible = false;
            // 
            // lbldoc
            // 
            this.lbldoc.AutoSize = true;
            this.lbldoc.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldoc.ForeColor = System.Drawing.Color.Blue;
            this.lbldoc.Location = new System.Drawing.Point(457, 44);
            this.lbldoc.Name = "lbldoc";
            this.lbldoc.Size = new System.Drawing.Size(0, 15);
            this.lbldoc.TabIndex = 68;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel3.Controls.Add(this.label8);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(775, 25);
            this.panel3.TabIndex = 67;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(6, 5);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(151, 16);
            this.label8.TabIndex = 62;
            this.label8.Text = "CHI TIẾT ĐƠN HÀNG";
            // 
            // lblmoneyunitdetail
            // 
            this.lblmoneyunitdetail.AutoSize = true;
            this.lblmoneyunitdetail.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmoneyunitdetail.Location = new System.Drawing.Point(573, 29);
            this.lblmoneyunitdetail.Name = "lblmoneyunitdetail";
            this.lblmoneyunitdetail.Size = new System.Drawing.Size(30, 14);
            this.lblmoneyunitdetail.TabIndex = 66;
            this.lblmoneyunitdetail.Text = "VNĐ";
            this.lblmoneyunitdetail.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmborderdetailstatus
            // 
            this.cmborderdetailstatus.FormattingEnabled = true;
            this.cmborderdetailstatus.Location = new System.Drawing.Point(79, 367);
            this.cmborderdetailstatus.Name = "cmborderdetailstatus";
            this.cmborderdetailstatus.Size = new System.Drawing.Size(202, 23);
            this.cmborderdetailstatus.TabIndex = 65;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 371);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 15);
            this.label4.TabIndex = 64;
            this.label4.Text = "Trạng thái";
            // 
            // bntorderupdatestatus
            // 
            this.bntorderupdatestatus.Image = global::CASALE.Properties.Resources.edit_page;
            this.bntorderupdatestatus.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.bntorderupdatestatus.Location = new System.Drawing.Point(284, 366);
            this.bntorderupdatestatus.Name = "bntorderupdatestatus";
            this.bntorderupdatestatus.Size = new System.Drawing.Size(108, 24);
            this.bntorderupdatestatus.TabIndex = 63;
            this.bntorderupdatestatus.Text = "Cập nhật";
            this.bntorderupdatestatus.UseVisualStyleBackColor = true;
            this.bntorderupdatestatus.Click += new System.EventHandler(this.bntorderupdatestatus_Click);
            // 
            // btnorderdetailclose
            // 
            this.btnorderdetailclose.Location = new System.Drawing.Point(693, 367);
            this.btnorderdetailclose.Name = "btnorderdetailclose";
            this.btnorderdetailclose.Size = new System.Drawing.Size(74, 24);
            this.btnorderdetailclose.TabIndex = 54;
            this.btnorderdetailclose.Text = "Đóng lại";
            this.btnorderdetailclose.UseVisualStyleBackColor = true;
            this.btnorderdetailclose.Click += new System.EventHandler(this.btnorderdetailclose_Click);
            // 
            // lbltatoldetail
            // 
            this.lbltatoldetail.AutoSize = true;
            this.lbltatoldetail.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbltatoldetail.Location = new System.Drawing.Point(454, 29);
            this.lbltatoldetail.Name = "lbltatoldetail";
            this.lbltatoldetail.Size = new System.Drawing.Size(16, 14);
            this.lbltatoldetail.TabIndex = 11;
            this.lbltatoldetail.Text = "0";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lvorderdetail);
            this.groupBox1.Location = new System.Drawing.Point(4, 156);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(767, 208);
            this.groupBox1.TabIndex = 61;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chi tiết đơn hàng";
            // 
            // lvorderdetail
            // 
            this.lvorderdetail.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Id,
            this.Code,
            this.Namesale,
            this.Price,
            this.dv,
            this.Quantity,
            this.Sl,
            this.Tax,
            this.Money});
            this.lvorderdetail.FullRowSelect = true;
            this.lvorderdetail.GridLines = true;
            this.lvorderdetail.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvorderdetail.Location = new System.Drawing.Point(3, 19);
            this.lvorderdetail.Name = "lvorderdetail";
            this.lvorderdetail.Size = new System.Drawing.Size(760, 181);
            this.lvorderdetail.TabIndex = 12;
            this.lvorderdetail.UseCompatibleStateImageBehavior = false;
            this.lvorderdetail.View = System.Windows.Forms.View.Details;
            // 
            // Id
            // 
            this.Id.Text = "ID";
            this.Id.Width = 0;
            // 
            // Code
            // 
            this.Code.Text = "STT";
            this.Code.Width = 40;
            // 
            // Namesale
            // 
            this.Namesale.Text = "Mã sản phẩm";
            this.Namesale.Width = 107;
            // 
            // Price
            // 
            this.Price.Text = "Tên";
            this.Price.Width = 198;
            // 
            // dv
            // 
            this.dv.Text = "Đ.Vị";
            // 
            // Quantity
            // 
            this.Quantity.Text = "Đơn giá";
            this.Quantity.Width = 94;
            // 
            // Sl
            // 
            this.Sl.Text = "SL";
            this.Sl.Width = 54;
            // 
            // Tax
            // 
            this.Tax.Text = "Thuế";
            this.Tax.Width = 64;
            // 
            // Money
            // 
            this.Money.Text = "Thành tiền";
            this.Money.Width = 117;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(403, 29);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 15);
            this.label12.TabIndex = 10;
            this.label12.Text = "Giá trị";
            // 
            // txtInformation
            // 
            this.txtInformation.Location = new System.Drawing.Point(79, 122);
            this.txtInformation.Multiline = true;
            this.txtInformation.Name = "txtInformation";
            this.txtInformation.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtInformation.Size = new System.Drawing.Size(684, 32);
            this.txtInformation.TabIndex = 53;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 15);
            this.label7.TabIndex = 60;
            this.label7.Text = "Thông tin";
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtEmail.Location = new System.Drawing.Point(457, 90);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.ReadOnly = true;
            this.txtEmail.Size = new System.Drawing.Size(306, 22);
            this.txtEmail.TabIndex = 52;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(403, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 15);
            this.label5.TabIndex = 59;
            this.label5.Text = "Email";
            // 
            // txtPhone
            // 
            this.txtPhone.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtPhone.Location = new System.Drawing.Point(79, 90);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.ReadOnly = true;
            this.txtPhone.Size = new System.Drawing.Size(208, 22);
            this.txtPhone.TabIndex = 51;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 93);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 15);
            this.label6.TabIndex = 58;
            this.label6.Text = "Điện Thoại";
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtAddress.Location = new System.Drawing.Point(457, 62);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.ReadOnly = true;
            this.txtAddress.Size = new System.Drawing.Size(306, 22);
            this.txtAddress.TabIndex = 50;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(403, 65);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 15);
            this.label13.TabIndex = 57;
            this.label13.Text = "Địa chỉ";
            // 
            // txtFullname
            // 
            this.txtFullname.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtFullname.Location = new System.Drawing.Point(79, 62);
            this.txtFullname.Name = "txtFullname";
            this.txtFullname.ReadOnly = true;
            this.txtFullname.Size = new System.Drawing.Size(294, 22);
            this.txtFullname.TabIndex = 49;
            this.txtFullname.Text = "Khách hàng lẻ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(5, 65);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 15);
            this.label14.TabIndex = 56;
            this.label14.Text = "Họ và tên";
            // 
            // txtId
            // 
            this.txtId.BackColor = System.Drawing.SystemColors.Control;
            this.txtId.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtId.Location = new System.Drawing.Point(79, 29);
            this.txtId.Name = "txtId";
            this.txtId.ReadOnly = true;
            this.txtId.Size = new System.Drawing.Size(294, 27);
            this.txtId.TabIndex = 48;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(5, 35);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(46, 15);
            this.label15.TabIndex = 55;
            this.label15.Text = "Mã HĐ";
            // 
            // frmXulydonhang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(926, 576);
            this.Controls.Add(this.pndetail);
            this.Controls.Add(this.lbltatolOrder);
            this.Controls.Add(this.lblmoneyunit);
            this.Controls.Add(this.lvordertiems);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.MaximizeBox = false;
            this.Name = "frmXulydonhang";
            this.Text = "Quản lý đơn hàng";
            this.Load += new System.EventHandler(this.frmXulydonhang_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.lvordertiems, 0);
            this.Controls.SetChildIndex(this.lblmoneyunit, 0);
            this.Controls.SetChildIndex(this.lbltatolOrder, 0);
            this.Controls.SetChildIndex(this.pndetail, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.pndetail.ResumeLayout(false);
            this.pndetail.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmborderlistpages;
        private System.Windows.Forms.ComboBox cmborderlistitemsperpage;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtorderlistkeyword;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmbordersliststatus;
        private System.Windows.Forms.Button btncheckorderonline;
        private System.Windows.Forms.ListView lvordertiems;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.Label lblmoneyunit;
        private System.Windows.Forms.Label lbltatolOrder;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pndetail;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblmoneyunitdetail;
        private System.Windows.Forms.ComboBox cmborderdetailstatus;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button bntorderupdatestatus;
        private System.Windows.Forms.Button btnorderdetailclose;
        private System.Windows.Forms.Label lbltatoldetail;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListView lvorderdetail;
        private System.Windows.Forms.ColumnHeader Id;
        private System.Windows.Forms.ColumnHeader Code;
        private System.Windows.Forms.ColumnHeader Namesale;
        private System.Windows.Forms.ColumnHeader Price;
        private System.Windows.Forms.ColumnHeader dv;
        private System.Windows.Forms.ColumnHeader Quantity;
        private System.Windows.Forms.ColumnHeader Sl;
        private System.Windows.Forms.ColumnHeader Tax;
        private System.Windows.Forms.ColumnHeader Money;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtInformation;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtFullname;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cmndetail;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cmndelete;
        private System.Windows.Forms.Label lbldoc;
    }
}