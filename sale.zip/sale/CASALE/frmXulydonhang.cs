﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CASALE.Class;
using LCProductCartUtiliti;
using LCMultiUtilities;
using OfficeUtilities;

namespace CASALE
{
    public partial class frmXulydonhang : templates
    {
        int curpage = 1;
        double fsumorderditail = 0;
        protected int icartid = -1;
        int inumofitems = 0;
        bool isloaddata = false;
        public frmXulydonhang()
        {
            InitializeComponent();
        }

        private void frmXulydonhang_Load(object sender, EventArgs e)
        {
            isloaddata = true;
            // load trạng thái xử lý
            DataTable orderliststatus = Common.OrderStatus;
            cmbordersliststatus.DataSource = orderliststatus;
            cmbordersliststatus.DisplayMember = "Status";
            cmbordersliststatus.ValueMember = "ID";

            DataTable orderdetailstatus = Common.OrderStatus;
            cmborderdetailstatus.DataSource = orderdetailstatus;
            cmborderdetailstatus.DisplayMember = "Status";
            cmborderdetailstatus.ValueMember = "ID";

            DataTable dtitemsperpages = Common.ItemsPerPage;
            cmborderlistitemsperpage.DataSource = dtitemsperpages;
            cmborderlistitemsperpage.DisplayMember = "Text";
            cmborderlistitemsperpage.ValueMember = "Value";
            isloaddata = false;
            // lấy danh sách đơn đặt hàng
            //LoadOrdersList();

            if (Common.EnableSaleOnline == true)
                btncheckorderonline.Enabled = true;
            else btncheckorderonline.Enabled = false;
            lblmoneyunit.Text = Common.MoneyUnit;
            lblmoneyunitdetail.Text = Common.MoneyUnit;
            LoadOrdersList();
        }

        string OrderStatus(int istatus)
        {
            return Common.OrderStatusInList(istatus);
        }
        protected void LoadOrdersList()
        {
            double ftaltolorder = 0;
            this.lvordertiems.Items.Clear();
            // đếm số items --> số trang
            if (inumofitems < 1)
            {
                inumofitems = Cart.p_cartlist_count(
                    Convert.ToInt32(cmbordersliststatus.SelectedValue),
                    txtorderlistkeyword.Text,
                    Common.ConnectionString);
                // bind dữ liệu vào combobox pages.
                int pages = 1;
                if (inumofitems % Convert.ToInt32(cmborderlistitemsperpage.SelectedValue) == 0)
                {
                    pages = inumofitems / Convert.ToInt32(cmborderlistitemsperpage.SelectedValue);
                }
                else
                {
                    pages = inumofitems / Convert.ToInt32(cmborderlistitemsperpage.SelectedValue) + 1;
                }
                cmborderlistpages.Items.Clear();

                for (int i = 1; i <= pages; i++)
                {
                    cmborderlistpages.Items.Add(i);
                }
                cmborderlistpages.Text = "1";
            }
            //MessageBox.Show(cmborderlistpages.Items.Count.ToString()); 
            curpage = Convert.ToInt32(cmborderlistpages.Text) - 1;
            // lấy danh sách đơn hàng.
            DataTable table = Cart.p_cartlist(0,
                Convert.ToInt32(cmbordersliststatus.SelectedValue), -1,
                txtorderlistkeyword.Text, curpage,
                Convert.ToInt32(cmborderlistitemsperpage.SelectedValue), "", "", Common.ConnectionString);

            lvordertiems.Items.Clear();
            if (table.Rows.Count > 0)
            {
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    ListViewItem lvi = new ListViewItem(table.Rows[i]["icartid"].ToString());

                    lvi.SubItems.Add((Convert.ToInt32(cmborderlistitemsperpage.Text) * (Convert.ToInt32(cmborderlistpages.Text) - 1) + (i + 1)).ToString());
                    lvi.SubItems.Add(table.Rows[i]["vcode"].ToString());
                    lvi.SubItems.Add(table.Rows[i]["vcname"].ToString());
                    lvi.SubItems.Add(table.Rows[i]["vcaddress"].ToString());
                    lvi.SubItems.Add(Convert.ToDateTime(table.Rows[i]["ddatetime"]).ToString("dd/MM/yyyy"));
                    double total = double.Parse(table.Rows[i]["vmoney"].ToString());
                    lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(total.ToString()));
                    lvi.SubItems.Add(OrderStatus(Convert.ToInt32(table.Rows[i]["istatus"])));
                    lvi.SubItems.Add(table.Rows[i]["vuserun"].ToString());
                    lvordertiems.Items.Add(lvi);
                    ftaltolorder += total;
                }

            }
            lbltatolOrder.Text = LCUtiliti.ConvertNumber.FomatPrice(ftaltolorder.ToString());
            //lbltatolnumber.Text = inumofitems.ToString();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            LoadOrdersList();
        }
        private void cmndetail_Click(object sender, EventArgs e)
        {
            pndetail.Visible = true;
            lvorderdetail.Items.Clear();
            if (lvordertiems.Items.Count > 0)
            {
                if (lvordertiems.SelectedItems.Count > 0)
                {
                    if (this.icartid > 0)
                    {
                        DataTable dtcartdetails = new DataTable();
                        DataTable dtcart = new DataTable();

                        dtcart = Cart.p_carts_getdetailbyid(this.icartid.ToString(), Common.ConnectionString);
                        if (dtcart.Rows.Count > 0)
                        {
                            txtId.Text = dtcart.Rows[0]["vcode"].ToString();
                            txtFullname.Text = dtcart.Rows[0]["vcname"].ToString();
                            txtAddress.Text = dtcart.Rows[0]["vcaddress"].ToString();
                            txtPhone.Text = dtcart.Rows[0]["vcphone"].ToString();
                            txtEmail.Text = dtcart.Rows[0]["vcemail"].ToString();

                            string _sstatus = dtcart.Rows[0]["istatus"].ToString();
                            cmborderdetailstatus.SelectedValue = _sstatus;
                            switch (_sstatus)
                            {
                                case "2":// đã giao hàng
                                case "-3":// đã hủy đơn hàng
                                    bntorderupdatestatus.Enabled = false;
                                    break;
                                default:
                                    bntorderupdatestatus.Enabled = true;
                                    break;
                            }
                        }
                        dtcartdetails = Cart.p_cartdetails_getdetailby_cartid(icartid, Common.ConnectionString);

                        for (int i = 0; i < dtcartdetails.Rows.Count; i++)
                        {
                            ListViewItem lvi = new ListViewItem(dtcartdetails.Rows[i]["icdid"].ToString());
                            lvi.SubItems.Add((i + 1).ToString());
                            lvi.SubItems.Add(dtcartdetails.Rows[i]["vproductkey"].ToString());
                            lvi.SubItems.Add(dtcartdetails.Rows[i]["vproductname"].ToString());
                            lvi.SubItems.Add(dtcartdetails.Rows[i]["vproductunit"].ToString());
                            lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dtcartdetails.Rows[i]["vprice"].ToString()));
                            lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(dtcartdetails.Rows[i]["inumber"].ToString()));
                            lvi.SubItems.Add(dtcartdetails.Rows[i]["ftaxpercent"].ToString());
                            double ftotal = (Convert.ToSingle(dtcartdetails.Rows[i]["vprice"]) *
                                Convert.ToInt32(dtcartdetails.Rows[i]["inumber"]) +
                                (Convert.ToSingle(dtcartdetails.Rows[i]["vprice"]) *
                                Convert.ToInt32(dtcartdetails.Rows[i]["inumber"]) *
                                (Convert.ToSingle(dtcartdetails.Rows[i]["ftaxpercent"]) / 100)));

                            lvi.SubItems.Add(LCUtiliti.ConvertNumber.FomatPrice(ftotal.ToString()));
                            fsumorderditail += Convert.ToDouble(dtcartdetails.Rows[i]["vmoney"].ToString());
                            lvorderdetail.Items.Add(lvi);
                        }
                        lbltatoldetail.Text = LCUtiliti.ConvertNumber.FomatPrice(fsumorderditail.ToString());
                        lbldoc.Text = LCUtiliti.ConvertNumber.ConvertNumberToString(long.Parse(fsumorderditail.ToString()));
                    }
                }
            }
            else
            {
                return;
            }
        }

        private void lvordertiems_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvordertiems.Items.Count > 0)
            {
                if (lvordertiems.SelectedItems.Count > 0)
                {
                    this.icartid = Convert.ToInt32(lvordertiems.SelectedItems[0].SubItems[0].Text.ToString());
                    //if (lvordertiems.SelectedItems.Count > 1)
                    //{
                    //    cmnviewdetail.Enabled = false;

                    //}
                    //else
                    //{
                    //    cmnviewdetail.Enabled = true;
                    //}
                }
            }
        }

        private void cmndelete_Click(object sender, EventArgs e)
        {
            if (lvordertiems.Items.Count > 0)
            {
                if (lvordertiems.SelectedItems.Count > 0)
                {
                    if (this.icartid > 0)
                    {
                        Cart.p_carts_delete(icartid, Common.ConnectionString);
                        LoadOrdersList();
                    }
                }
            }
        }

        private void btnorderdetailclose_Click(object sender, EventArgs e)
        {
            pndetail.Visible = false;
        }

        private void bntorderupdatestatus_Click(object sender, EventArgs e)
        {
            // cap nhat trang thai don hang xu ly
            Cart.p_carts_updatestatus(icartid, Convert.ToInt32(cmborderdetailstatus.SelectedValue), Common.ConnectionString);

            if (Convert.ToInt32(cmborderdetailstatus.SelectedValue) == 2)
            {
                // cập nhật trạng thái đơn hàng xử lý
                DataTable dt = new DataTable();
                dt = Cart.p_cartdetails_getdetailby_cartid(icartid, Common.ConnectionString);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    // cập nhật số lượng vào bảng sản phẩm để tính số lượng trong kho hàng.
                    mssql_multicates_multidb_items.dicts_items_update_custom_update(
                         dt.Rows[i]["irpost_id"].ToString(),
                        " iquantity=iquantity - " + dt.Rows[i]["inumber"].ToString(),
                        Common.ConnectionString);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ExcelUtilities.ExportListViewToExcel(ref lvordertiems);
        }
    }
}
