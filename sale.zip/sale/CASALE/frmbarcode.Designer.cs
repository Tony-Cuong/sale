﻿using CASALE.Class;
namespace CASALE
{
    partial class frmbarcode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.fbarcode = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btninsertbarcodes = new System.Windows.Forms.Button();
            this.lblresult = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.nuprintbcitemsto = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.nuprintbcitemsfrom = new System.Windows.Forms.NumericUpDown();
            this.btnrefresh = new System.Windows.Forms.Button();
            this.btnprintbarcode = new System.Windows.Forms.Button();
            this.pdbarcodes = new System.Drawing.Printing.PrintDocument();
            this.pnbarcodecontainer = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nuprintbcitemsto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nuprintbcitemsfrom)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.btninsertbarcodes);
            this.panel1.Controls.Add(this.lblresult);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.nuprintbcitemsto);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.nuprintbcitemsfrom);
            this.panel1.Controls.Add(this.btnrefresh);
            this.panel1.Controls.Add(this.btnprintbarcode);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(752, 28);
            this.panel1.TabIndex = 4;
            // 
            // btninsertbarcodes
            // 
            this.btninsertbarcodes.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btninsertbarcodes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.btninsertbarcodes.Location = new System.Drawing.Point(170, 2);
            this.btninsertbarcodes.Name = "btninsertbarcodes";
            this.btninsertbarcodes.Size = new System.Drawing.Size(112, 24);
            this.btninsertbarcodes.TabIndex = 42;
            this.btninsertbarcodes.Text = "Chèn mã vạch";
            this.btninsertbarcodes.UseVisualStyleBackColor = true;
            this.btninsertbarcodes.Click += new System.EventHandler(this.btninsertbarcodes_Click);
            // 
            // lblresult
            // 
            this.lblresult.Location = new System.Drawing.Point(575, 7);
            this.lblresult.Name = "lblresult";
            this.lblresult.Size = new System.Drawing.Size(160, 13);
            this.lblresult.TabIndex = 41;
            this.lblresult.Text = "120 phiếu đã in";
            this.lblresult.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(89, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 15);
            this.label2.TabIndex = 40;
            this.label2.Text = "đến";
            // 
            // nuprintbcitemsto
            // 
            this.nuprintbcitemsto.Location = new System.Drawing.Point(117, 4);
            this.nuprintbcitemsto.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.nuprintbcitemsto.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nuprintbcitemsto.Name = "nuprintbcitemsto";
            this.nuprintbcitemsto.Size = new System.Drawing.Size(47, 22);
            this.nuprintbcitemsto.TabIndex = 39;
            this.nuprintbcitemsto.Value = new decimal(new int[] {
            40,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 15);
            this.label1.TabIndex = 38;
            this.label1.Text = "In từ";
            // 
            // nuprintbcitemsfrom
            // 
            this.nuprintbcitemsfrom.Location = new System.Drawing.Point(38, 4);
            this.nuprintbcitemsfrom.Maximum = new decimal(new int[] {
            39,
            0,
            0,
            0});
            this.nuprintbcitemsfrom.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nuprintbcitemsfrom.Name = "nuprintbcitemsfrom";
            this.nuprintbcitemsfrom.Size = new System.Drawing.Size(47, 22);
            this.nuprintbcitemsfrom.TabIndex = 37;
            this.nuprintbcitemsfrom.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnrefresh
            // 
            this.btnrefresh.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnrefresh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.btnrefresh.Location = new System.Drawing.Point(282, 2);
            this.btnrefresh.Name = "btnrefresh";
            this.btnrefresh.Size = new System.Drawing.Size(50, 24);
            this.btnrefresh.TabIndex = 4;
            this.btnrefresh.Text = "Tải lại";
            this.btnrefresh.UseVisualStyleBackColor = true;
            this.btnrefresh.Click += new System.EventHandler(this.btnrefresh_Click);
            // 
            // btnprintbarcode
            // 
            this.btnprintbarcode.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnprintbarcode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.btnprintbarcode.Location = new System.Drawing.Point(444, 2);
            this.btnprintbarcode.Name = "btnprintbarcode";
            this.btnprintbarcode.Size = new System.Drawing.Size(125, 24);
            this.btnprintbarcode.TabIndex = 2;
            this.btnprintbarcode.Text = "In phiếu mã vạch";
            this.btnprintbarcode.UseVisualStyleBackColor = true;
            this.btnprintbarcode.Click += new System.EventHandler(this.btnprintbarcode_Click);
            // 
            // pdbarcodes
            // 
            this.pdbarcodes.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.pdbarcodes_PrintPage);
            // 
            // pnbarcodecontainer
            // 
            this.pnbarcodecontainer.AutoScroll = true;
            this.pnbarcodecontainer.AutoSize = true;
            this.pnbarcodecontainer.BackColor = System.Drawing.Color.White;
            this.pnbarcodecontainer.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnbarcodecontainer.Location = new System.Drawing.Point(0, 28);
            this.pnbarcodecontainer.Name = "pnbarcodecontainer";
            this.pnbarcodecontainer.Size = new System.Drawing.Size(752, 0);
            this.pnbarcodecontainer.TabIndex = 5;
            // 
            // frmbarcode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(752, 488);
            this.Controls.Add(this.pnbarcodecontainer);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmbarcode";
            this.Text = "In mã vạch";
            this.Load += new System.EventHandler(this.frmbarcode_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnbarcodecontainer, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nuprintbcitemsto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nuprintbcitemsfrom)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btninsertbarcodes;
        private System.Windows.Forms.Label lblresult;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nuprintbcitemsto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nuprintbcitemsfrom;
        private System.Windows.Forms.Button btnrefresh;
        private System.Windows.Forms.Button btnprintbarcode;
        private System.Drawing.Printing.PrintDocument pdbarcodes;
        private System.Windows.Forms.FlowLayoutPanel pnbarcodecontainer;
    }
}