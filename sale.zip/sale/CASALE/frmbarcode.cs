﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CASALE.Class;

namespace CASALE
{
    public partial class frmbarcode : templates
    {
        public static PrintBarCodeList PrintBCodeList = new PrintBarCodeList();
        int iprinted = 0;
        public frmbarcode()
        {
            InitializeComponent();
        }

        private void frmbarcode_Load(object sender, EventArgs e)
        {
            Refresh();
            lblresult.Text = "Chưa in phiếu mã vạch nào";

        }
        void Refresh()
        {
            if (PrintBCodeList.Count > 40)
            {
                for (int i = PrintBCodeList.Count - 1; i > 39; i--)
                {
                    PrintBCodeList.RemoveAt(i);
                }
            }
            PrintBCodeList.FormatList();

            nuprintbcitemsto.Maximum = PrintBCodeList.Count;
            nuprintbcitemsto.Value = PrintBCodeList.Count;

            pnbarcodecontainer.Controls.Clear();



            for (int i = 0; i < nuprintbcitemsto.Value; i++)
            {
                if (i < nuprintbcitemsfrom.Value - 1 || i > nuprintbcitemsto.Value - 1)
                {
                    PrintBCodeList[i].PrintEnable = false;
                }
                else
                {
                    PrintBCodeList[i].PrintEnable = true;
                }
                PrintBCodeList.FormatList(Convert.ToInt32(nuprintbcitemsfrom.Value) - 1, Convert.ToInt32(nuprintbcitemsto.Value));
                pnbarcodecontainer.Controls.Add(PrintBCodeList[i]);
            }


        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            Refresh();
        }

        private void pdbarcodes_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;
            Rectangle rFull = new Rectangle(
                e.PageBounds.Left - 17,
                e.PageBounds.Top,
                e.PageBounds.Right,
                e.PageBounds.Bottom);

            Bitmap bmp4 = new Bitmap(pnbarcodecontainer.Width, pnbarcodecontainer.Height);
            pnbarcodecontainer.DrawToBitmap(bmp4, new Rectangle(0, 0, pnbarcodecontainer.Width, pnbarcodecontainer.Height));
            g.DrawImage(bmp4, 0, 0, rFull, GraphicsUnit.Pixel);
            e.HasMorePages = false;
            iprinted += Convert.ToInt32(nuprintbcitemsto.Value - nuprintbcitemsfrom.Value) + 1;
            lblresult.Text = iprinted.ToString() + " phiếu đã được in";
        }

        private void btninsertbarcodes_Click(object sender, EventArgs e)
        {
            if (Common.barcodeinsertdialog == null)
            {
                Common.barcodeinsertdialog = new barcodecontrolinsertitems();
            }
            Common.barcodeinsertdialog.ShowDialog();
            Refresh();
        }

        private void btnprintbarcode_Click(object sender, EventArgs e)
        {
            if (PrintBCodeList.Count > 0)
            {
                if (MessageBox.Show(this, "In những phiếu mã vạch theo bảng phía dưới", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    //PrintDialog pdl = new PrintDialog();
                    //if (pdl.ShowDialog() == DialogResult.OK)
                    //{
                        //pdbarcodes.PrinterSettings = pdl.PrinterSettings;
                        pdbarcodes.Print();
                    //}
                }
            }
        }
    }
}
