﻿using CASALE.Class;
namespace CASALE
{
    partial class frmbarcodeimportexport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.fimexbarcode = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblresult = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.nupages = new System.Windows.Forms.NumericUpDown();
            this.btnrefresh = new System.Windows.Forms.Button();
            this.btnprintbarcode = new System.Windows.Forms.Button();
            this.pnbarcodecontainer = new System.Windows.Forms.FlowLayoutPanel();
            this.pdbarcodes = new System.Drawing.Printing.PrintDocument();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupages)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.lblresult);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.nupages);
            this.panel1.Controls.Add(this.btnrefresh);
            this.panel1.Controls.Add(this.btnprintbarcode);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(752, 28);
            this.panel1.TabIndex = 4;
            // 
            // lblresult
            // 
            this.lblresult.Location = new System.Drawing.Point(575, 7);
            this.lblresult.Name = "lblresult";
            this.lblresult.Size = new System.Drawing.Size(160, 13);
            this.lblresult.TabIndex = 41;
            this.lblresult.Text = "120 phiếu đã in";
            this.lblresult.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 15);
            this.label1.TabIndex = 38;
            this.label1.Text = "Trang";
            // 
            // nupages
            // 
            this.nupages.Location = new System.Drawing.Point(46, 4);
            this.nupages.Maximum = new decimal(new int[] {
            39,
            0,
            0,
            0});
            this.nupages.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nupages.Name = "nupages";
            this.nupages.Size = new System.Drawing.Size(47, 22);
            this.nupages.TabIndex = 37;
            this.nupages.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnrefresh
            // 
            this.btnrefresh.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnrefresh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.btnrefresh.Location = new System.Drawing.Point(99, 2);
            this.btnrefresh.Name = "btnrefresh";
            this.btnrefresh.Size = new System.Drawing.Size(50, 24);
            this.btnrefresh.TabIndex = 4;
            this.btnrefresh.Text = "Tải lại";
            this.btnrefresh.UseVisualStyleBackColor = true;
            this.btnrefresh.Click += new System.EventHandler(this.btnrefresh_Click);
            // 
            // btnprintbarcode
            // 
            this.btnprintbarcode.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnprintbarcode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.btnprintbarcode.Location = new System.Drawing.Point(152, 2);
            this.btnprintbarcode.Name = "btnprintbarcode";
            this.btnprintbarcode.Size = new System.Drawing.Size(125, 24);
            this.btnprintbarcode.TabIndex = 2;
            this.btnprintbarcode.Text = "In phiếu mã vạch";
            this.btnprintbarcode.UseVisualStyleBackColor = true;
            this.btnprintbarcode.Click += new System.EventHandler(this.btnprintbarcode_Click);
            // 
            // pnbarcodecontainer
            // 
            this.pnbarcodecontainer.BackColor = System.Drawing.Color.White;
            this.pnbarcodecontainer.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnbarcodecontainer.Location = new System.Drawing.Point(0, 28);
            this.pnbarcodecontainer.Name = "pnbarcodecontainer";
            this.pnbarcodecontainer.Size = new System.Drawing.Size(752, 418);
            this.pnbarcodecontainer.TabIndex = 5;
            // 
            // pdbarcodes
            // 
            this.pdbarcodes.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.pdbarcodes_PrintPage);
            // 
            // frmbarcodeimportexport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(752, 471);
            this.Controls.Add(this.pnbarcodecontainer);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "frmbarcodeimportexport";
            this.Text = "In mã vạch";
            this.Load += new System.EventHandler(this.frmbarcodeimportexport_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.pnbarcodecontainer, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupages)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblresult;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nupages;
        private System.Windows.Forms.Button btnrefresh;
        private System.Windows.Forms.Button btnprintbarcode;
        private System.Windows.Forms.FlowLayoutPanel pnbarcodecontainer;
        private System.Drawing.Printing.PrintDocument pdbarcodes;
    }
}