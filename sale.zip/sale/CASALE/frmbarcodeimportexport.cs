﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CASALE
{
    public partial class frmbarcodeimportexport : templates
    {
        public static PrintBarCodeList PrintBCodeList = new PrintBarCodeList();
        int iprinted = 0;
        int numpages = 1;
        public frmbarcodeimportexport()
        {
            InitializeComponent();
        }

        private void frmbarcodeimportexport_Load(object sender, EventArgs e)
        {
            // load pages
            numpages = PrintBCodeList.Count / 40;
            if (PrintBCodeList.Count % 40 > 0)
                numpages++;
            nupages.Maximum = numpages;
            nupages.Minimum = 1;
            // load barcodes
            Refresh();
            lblresult.Text = "Chưa in phiếu mã vạch nào";
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            Refresh();
        }

        private void pdbarcodes_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;
            Rectangle rFull = new Rectangle(
                e.PageBounds.Left - 17,
                e.PageBounds.Top,
                e.PageBounds.Right,
                e.PageBounds.Bottom);

            Bitmap bmp4 = new Bitmap(pnbarcodecontainer.Width, pnbarcodecontainer.Height);
            pnbarcodecontainer.DrawToBitmap(bmp4, new Rectangle(0, 0, pnbarcodecontainer.Width, pnbarcodecontainer.Height));
            g.DrawImage(bmp4, 0, 0, rFull, GraphicsUnit.Pixel);
            e.HasMorePages = false;
            //iprinted += Convert.ToInt32(nuprintbcitemsto.Value - nupages.Value) + 1;
            lblresult.Text = iprinted.ToString() + " phiếu đã được in";
        }

        private void btnprintbarcode_Click(object sender, EventArgs e)
        {
            if (PrintBCodeList.Count > 0)
            {

                pdbarcodes.Print();
                if (nupages.Value < numpages)
                {
                    nupages.Value += 1;
                    Refresh();
                }
                if (MessageBox.Show(this, "In những phiếu mã vạch theo bảng phía dưới", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {

                    for (int i = 1; i < Convert.ToInt32(nupages.Value) + 1; i++)
                    {
                        nupages.Value = i;
                        Refresh();
                    }
                }
            }
        }
    }
}
