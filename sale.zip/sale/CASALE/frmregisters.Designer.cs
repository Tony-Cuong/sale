﻿using CASALE.Class;
namespace CASALE
{
    partial class frmregisters
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.frmreg = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblmsg = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtlicensekey = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.lbllcsstatus = new System.Windows.Forms.Label();
            this.lbllicensestatus = new System.Windows.Forms.Label();
            this.btnbycode = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.btnregister = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblmsg
            // 
            this.lblmsg.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblmsg.ForeColor = System.Drawing.Color.Crimson;
            this.lblmsg.Location = new System.Drawing.Point(14, 68);
            this.lblmsg.Name = "lblmsg";
            this.lblmsg.Size = new System.Drawing.Size(424, 28);
            this.lblmsg.TabIndex = 33;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(9, 129);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 12);
            this.label4.TabIndex = 26;
            this.label4.Text = "Mã bản quyền";
            // 
            // txtlicensekey
            // 
            this.txtlicensekey.Location = new System.Drawing.Point(86, 124);
            this.txtlicensekey.Name = "txtlicensekey";
            this.txtlicensekey.Size = new System.Drawing.Size(338, 22);
            this.txtlicensekey.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(9, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 12);
            this.label3.TabIndex = 32;
            this.label3.Text = "Thư điện tử";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(8, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(330, 12);
            this.label2.TabIndex = 31;
            this.label2.Text = "Cung cấp  những thông tin sau đây để đăng ký sử dụng phần mềm";
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(86, 100);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(338, 22);
            this.txtemail.TabIndex = 24;
            this.txtemail.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtemail_KeyUp);
            // 
            // lbllcsstatus
            // 
            this.lbllcsstatus.AutoSize = true;
            this.lbllcsstatus.Location = new System.Drawing.Point(8, 31);
            this.lbllcsstatus.Name = "lbllcsstatus";
            this.lbllcsstatus.Size = new System.Drawing.Size(136, 15);
            this.lbllcsstatus.TabIndex = 30;
            this.lbllcsstatus.Text = "Phần mềm chưa đăng ký";
            // 
            // lbllicensestatus
            // 
            this.lbllicensestatus.AutoSize = true;
            this.lbllicensestatus.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbllicensestatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(177)))), ((int)(((byte)(86)))));
            this.lbllicensestatus.Location = new System.Drawing.Point(8, 4);
            this.lbllicensestatus.Name = "lbllicensestatus";
            this.lbllicensestatus.Size = new System.Drawing.Size(308, 16);
            this.lbllicensestatus.TabIndex = 29;
            this.lbllicensestatus.Text = "ĐĂNG KÝ BẢN QUYỀN SỬ DỤNG PHẦN MỀM";
            this.lbllicensestatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnbycode
            // 
            this.btnbycode.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbycode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(177)))), ((int)(((byte)(86)))));
            this.btnbycode.Image = global::CASALE.Properties.Resources.hs_buy;
            this.btnbycode.Location = new System.Drawing.Point(173, 152);
            this.btnbycode.Name = "btnbycode";
            this.btnbycode.Size = new System.Drawing.Size(75, 35);
            this.btnbycode.TabIndex = 28;
            this.btnbycode.Text = "Liên hệ";
            this.btnbycode.UseVisualStyleBackColor = true;
            // 
            // btncancel
            // 
            this.btncancel.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(177)))), ((int)(((byte)(86)))));
            this.btncancel.Image = global::CASALE.Properties.Resources.hs_exit;
            this.btncancel.Location = new System.Drawing.Point(256, 153);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(57, 35);
            this.btncancel.TabIndex = 28;
            this.btncancel.Text = "Thoát";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // btnregister
            // 
            this.btnregister.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregister.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(177)))), ((int)(((byte)(86)))));
            this.btnregister.Image = global::CASALE.Properties.Resources.hs_reg;
            this.btnregister.Location = new System.Drawing.Point(86, 152);
            this.btnregister.Name = "btnregister";
            this.btnregister.Size = new System.Drawing.Size(81, 36);
            this.btnregister.TabIndex = 27;
            this.btnregister.Text = "Đăng ký";
            this.btnregister.UseVisualStyleBackColor = true;
            this.btnregister.Click += new System.EventHandler(this.btnregister_Click);
            // 
            // frmregisters
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(429, 211);
            this.Controls.Add(this.lblmsg);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtlicensekey);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.btnbycode);
            this.Controls.Add(this.btncancel);
            this.Controls.Add(this.btnregister);
            this.Controls.Add(this.lbllcsstatus);
            this.Controls.Add(this.lbllicensestatus);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "frmregisters";
            this.Text = "Đăng ký";
            this.Load += new System.EventHandler(this.frmregisters_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmregisters_FormClosed);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmregisters_FormClosing);
            this.Controls.SetChildIndex(this.lbllicensestatus, 0);
            this.Controls.SetChildIndex(this.lbllcsstatus, 0);
            this.Controls.SetChildIndex(this.btnregister, 0);
            this.Controls.SetChildIndex(this.btncancel, 0);
            this.Controls.SetChildIndex(this.btnbycode, 0);
            this.Controls.SetChildIndex(this.txtemail, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.txtlicensekey, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.lblmsg, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblmsg;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtlicensekey;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.Button btnregister;
        private System.Windows.Forms.Label lbllcsstatus;
        private System.Windows.Forms.Label lbllicensestatus;
        private System.Windows.Forms.Button btnbycode;
    }
}