﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LCUtiliti;
using LCGenCommon;
using CASALE.Class;

namespace CASALE
{
    public partial class frmregisters : templates
    {
        public frmregisters()
        {
            InitializeComponent();
        }

        private void frmregisters_Load(object sender, EventArgs e)
        {

        }

        private void btnregister_Click(object sender, EventArgs e)
        {
            if (ChekValid.checkemail(txtemail.Text) == false)
            {
                txtemail.Focus();
                return;
            }
            if (!txtlicensekey.Text.Equals(CAGenUtiliti.LicenseKey(CAGenUtiliti.GetProcessorId())))
            {
                lblmsg.Text = "Mã số đăng ký không hợp lệ.!";
                txtlicensekey.Text = "";
                txtlicensekey.Focus();
            }
            else
            {
                system32.systems.system32_139_update(CAGenUtiliti.GetProcessorId(), DateTime.Now, -1, txtemail.Text, "", 0, Common.ConnectionString);
                lblmsg.Text = "Đăng ký thành công!. Cảm ơn bạn đã sử dụng phần mềm có bản quyền\nVui lòng khởi động lại ứng dụng";
                btnregister.Enabled = false;
                btncancel.Enabled = false;
                btnbycode.Enabled = false;
            }
        }

        private void txtemail_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Enter)
            {
                txtlicensekey.Focus();
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void frmregisters_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void frmregisters_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
