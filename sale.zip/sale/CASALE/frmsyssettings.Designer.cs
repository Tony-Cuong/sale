﻿using CASALE.Class;
namespace CASALE
{
    partial class frmsyssettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.frmsettings = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtmasothue = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txttongcongty = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.txtcompanyphone = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtcompanyaddress = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.btnsavesettingcommon = new System.Windows.Forms.Button();
            this.txtcompanyname = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtrate = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.txtimportprefix = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.txtorderprefix = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.cmbordersliststatus = new System.Windows.Forms.ComboBox();
            this.btnsavesettingsale = new System.Windows.Forms.Button();
            this.txtmoneyunit = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtprintimexextitle = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.txtprintimeximtitle = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.txtprinttax2 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.txtprintprinttitle2 = new System.Windows.Forms.TextBox();
            this.txtprintthanks2 = new System.Windows.Forms.TextBox();
            this.rdprintordertypeorigional = new System.Windows.Forms.RadioButton();
            this.rdprintordertypesupermarket = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtprinttax = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtprintprinttitle = new System.Windows.Forms.TextBox();
            this.txtprintthanks = new System.Windows.Forms.TextBox();
            this.btnsavesettingprint = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label27 = new System.Windows.Forms.Label();
            this.chkenablesynonlinedata = new System.Windows.Forms.CheckBox();
            this.label26 = new System.Windows.Forms.Label();
            this.btnsavesettingonline = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtwspassword = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtwsusername = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chkenableonlinesale = new System.Windows.Forms.CheckBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnsavesettingadvance = new System.Windows.Forms.Button();
            this.txtadvancephone = new System.Windows.Forms.TextBox();
            this.chkadvanceenabesms = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(492, 24);
            this.panel1.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "CẤU HÌNH HỆ THỐNG";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControl1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tabControl1.Location = new System.Drawing.Point(0, 24);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(492, 313);
            this.tabControl1.TabIndex = 12;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(484, 287);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Thông tin chung";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtmasothue);
            this.groupBox4.Controls.Add(this.label53);
            this.groupBox4.Controls.Add(this.txttongcongty);
            this.groupBox4.Controls.Add(this.label52);
            this.groupBox4.Controls.Add(this.txtcompanyphone);
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Controls.Add(this.txtcompanyaddress);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.btnsavesettingcommon);
            this.groupBox4.Controls.Add(this.txtcompanyname);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.groupBox4.Location = new System.Drawing.Point(2, 2);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Size = new System.Drawing.Size(480, 281);
            this.groupBox4.TabIndex = 11;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Thông tin chung";
            // 
            // txtmasothue
            // 
            this.txtmasothue.Location = new System.Drawing.Point(97, 68);
            this.txtmasothue.Margin = new System.Windows.Forms.Padding(2);
            this.txtmasothue.Name = "txtmasothue";
            this.txtmasothue.Size = new System.Drawing.Size(126, 21);
            this.txtmasothue.TabIndex = 18;
            this.txtmasothue.Text = "ACB09124657098A";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.ForeColor = System.Drawing.Color.DimGray;
            this.label53.Location = new System.Drawing.Point(4, 68);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(69, 13);
            this.label53.TabIndex = 17;
            this.label53.Text = "Mã số thuế";
            // 
            // txttongcongty
            // 
            this.txttongcongty.Location = new System.Drawing.Point(97, 16);
            this.txttongcongty.Margin = new System.Windows.Forms.Padding(2);
            this.txttongcongty.Name = "txttongcongty";
            this.txttongcongty.Size = new System.Drawing.Size(276, 21);
            this.txttongcongty.TabIndex = 16;
            this.txttongcongty.Text = "Công ty TNHH Xa Lộ Thông Tin - CA Co.,Ltd.";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.ForeColor = System.Drawing.Color.DimGray;
            this.label52.Location = new System.Drawing.Point(4, 16);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(81, 13);
            this.label52.TabIndex = 15;
            this.label52.Text = "Tổng công ty";
            // 
            // txtcompanyphone
            // 
            this.txtcompanyphone.Location = new System.Drawing.Point(97, 121);
            this.txtcompanyphone.Margin = new System.Windows.Forms.Padding(2);
            this.txtcompanyphone.Name = "txtcompanyphone";
            this.txtcompanyphone.Size = new System.Drawing.Size(126, 21);
            this.txtcompanyphone.TabIndex = 14;
            this.txtcompanyphone.Text = "04 2202 1168";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.ForeColor = System.Drawing.Color.DimGray;
            this.label30.Location = new System.Drawing.Point(4, 121);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 13);
            this.label30.TabIndex = 13;
            this.label30.Text = "Điện thoại";
            // 
            // txtcompanyaddress
            // 
            this.txtcompanyaddress.Location = new System.Drawing.Point(97, 95);
            this.txtcompanyaddress.Margin = new System.Windows.Forms.Padding(2);
            this.txtcompanyaddress.Name = "txtcompanyaddress";
            this.txtcompanyaddress.Size = new System.Drawing.Size(276, 21);
            this.txtcompanyaddress.TabIndex = 12;
            this.txtcompanyaddress.Text = "30/18 Nguyễn Du, phường 7, quận Gò Vấp, TP.HCM";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.ForeColor = System.Drawing.Color.DimGray;
            this.label29.Location = new System.Drawing.Point(4, 96);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(46, 13);
            this.label29.TabIndex = 11;
            this.label29.Text = "Địa chỉ";
            // 
            // btnsavesettingcommon
            // 
            this.btnsavesettingcommon.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnsavesettingcommon.Location = new System.Drawing.Point(97, 154);
            this.btnsavesettingcommon.Margin = new System.Windows.Forms.Padding(2);
            this.btnsavesettingcommon.Name = "btnsavesettingcommon";
            this.btnsavesettingcommon.Size = new System.Drawing.Size(101, 22);
            this.btnsavesettingcommon.TabIndex = 10;
            this.btnsavesettingcommon.Text = "Lưu && áp dụng cài đặt";
            this.btnsavesettingcommon.UseVisualStyleBackColor = true;
            this.btnsavesettingcommon.Click += new System.EventHandler(this.btnsavesettingcommon_Click);
            // 
            // txtcompanyname
            // 
            this.txtcompanyname.Location = new System.Drawing.Point(97, 42);
            this.txtcompanyname.Margin = new System.Windows.Forms.Padding(2);
            this.txtcompanyname.Name = "txtcompanyname";
            this.txtcompanyname.Size = new System.Drawing.Size(276, 21);
            this.txtcompanyname.TabIndex = 2;
            this.txtcompanyname.Text = "Công ty TNHH Xa Lộ Thông Tin - CA Co.,Ltd.";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(4, 42);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Tên công ty";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(484, 287);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Kinh doanh";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtrate);
            this.groupBox1.Controls.Add(this.label54);
            this.groupBox1.Controls.Add(this.txtimportprefix);
            this.groupBox1.Controls.Add(this.label51);
            this.groupBox1.Controls.Add(this.label50);
            this.groupBox1.Controls.Add(this.txtorderprefix);
            this.groupBox1.Controls.Add(this.label49);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.cmbordersliststatus);
            this.groupBox1.Controls.Add(this.btnsavesettingsale);
            this.groupBox1.Controls.Add(this.txtmoneyunit);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.groupBox1.Location = new System.Drawing.Point(2, 2);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(480, 281);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin kinh doanh";
            // 
            // txtrate
            // 
            this.txtrate.Location = new System.Drawing.Point(7, 43);
            this.txtrate.Margin = new System.Windows.Forms.Padding(2);
            this.txtrate.Name = "txtrate";
            this.txtrate.Size = new System.Drawing.Size(40, 21);
            this.txtrate.TabIndex = 76;
            this.txtrate.Text = "1909";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.ForeColor = System.Drawing.Color.DimGray;
            this.label54.Location = new System.Drawing.Point(51, 45);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(108, 13);
            this.label54.TabIndex = 75;
            this.label54.Text = "Tỷ giá chuyển đổi";
            // 
            // txtimportprefix
            // 
            this.txtimportprefix.Location = new System.Drawing.Point(8, 140);
            this.txtimportprefix.Margin = new System.Windows.Forms.Padding(2);
            this.txtimportprefix.Name = "txtimportprefix";
            this.txtimportprefix.Size = new System.Drawing.Size(40, 21);
            this.txtimportprefix.TabIndex = 74;
            this.txtimportprefix.Text = "IM";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.ForeColor = System.Drawing.Color.DimGray;
            this.label51.Location = new System.Drawing.Point(52, 144);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(211, 13);
            this.label51.TabIndex = 73;
            this.label51.Text = "là ký tự bắt đầu hóa đơn nhập hàng";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.label50.Location = new System.Drawing.Point(6, 97);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(84, 13);
            this.label50.TabIndex = 72;
            this.label50.Text = "Ký tự bắt đầu";
            // 
            // txtorderprefix
            // 
            this.txtorderprefix.Location = new System.Drawing.Point(8, 115);
            this.txtorderprefix.Margin = new System.Windows.Forms.Padding(2);
            this.txtorderprefix.Name = "txtorderprefix";
            this.txtorderprefix.Size = new System.Drawing.Size(40, 21);
            this.txtorderprefix.TabIndex = 71;
            this.txtorderprefix.Text = "OD";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.ForeColor = System.Drawing.Color.DimGray;
            this.label49.Location = new System.Drawing.Point(52, 117);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(204, 13);
            this.label49.TabIndex = 70;
            this.label49.Text = "là ký tự bắt đầu hóa đơn bán hàng";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.ForeColor = System.Drawing.Color.DimGray;
            this.label28.Location = new System.Drawing.Point(134, 73);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(242, 13);
            this.label28.TabIndex = 69;
            this.label28.Text = "là trạng thái mặc định xử lý khi bán hàng";
            // 
            // cmbordersliststatus
            // 
            this.cmbordersliststatus.FormattingEnabled = true;
            this.cmbordersliststatus.Location = new System.Drawing.Point(7, 71);
            this.cmbordersliststatus.Margin = new System.Windows.Forms.Padding(2);
            this.cmbordersliststatus.Name = "cmbordersliststatus";
            this.cmbordersliststatus.Size = new System.Drawing.Size(126, 21);
            this.cmbordersliststatus.TabIndex = 68;
            // 
            // btnsavesettingsale
            // 
            this.btnsavesettingsale.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnsavesettingsale.Location = new System.Drawing.Point(8, 177);
            this.btnsavesettingsale.Margin = new System.Windows.Forms.Padding(2);
            this.btnsavesettingsale.Name = "btnsavesettingsale";
            this.btnsavesettingsale.Size = new System.Drawing.Size(159, 23);
            this.btnsavesettingsale.TabIndex = 11;
            this.btnsavesettingsale.Text = "Lưu && áp dụng cài đặt";
            this.btnsavesettingsale.UseVisualStyleBackColor = true;
            this.btnsavesettingsale.Click += new System.EventHandler(this.btnsavesettingsale_Click);
            // 
            // txtmoneyunit
            // 
            this.txtmoneyunit.Location = new System.Drawing.Point(7, 17);
            this.txtmoneyunit.Margin = new System.Windows.Forms.Padding(2);
            this.txtmoneyunit.Name = "txtmoneyunit";
            this.txtmoneyunit.Size = new System.Drawing.Size(40, 21);
            this.txtmoneyunit.TabIndex = 1;
            this.txtmoneyunit.Text = "USD";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(51, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(233, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "là đơn vị tiền tệ sử dụng trong hệ thống";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Controls.Add(this.btnsavesettingprint);
            this.tabPage3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(484, 287);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "In ấn";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtprintimexextitle);
            this.groupBox7.Controls.Add(this.label32);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.txtprintimeximtitle);
            this.groupBox7.Controls.Add(this.label9);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox7.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.groupBox7.Location = new System.Drawing.Point(0, 180);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox7.Size = new System.Drawing.Size(484, 79);
            this.groupBox7.TabIndex = 13;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Hóa đơn nhập xuất";
            // 
            // txtprintimexextitle
            // 
            this.txtprintimexextitle.Location = new System.Drawing.Point(102, 55);
            this.txtprintimexextitle.Margin = new System.Windows.Forms.Padding(2);
            this.txtprintimexextitle.Name = "txtprintimexextitle";
            this.txtprintimexextitle.Size = new System.Drawing.Size(276, 21);
            this.txtprintimexextitle.TabIndex = 7;
            this.txtprintimexextitle.Text = "HÓA ĐƠN XUẤT HÀNG";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.ForeColor = System.Drawing.Color.DimGray;
            this.label32.Location = new System.Drawing.Point(6, 57);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(83, 13);
            this.label32.TabIndex = 6;
            this.label32.Text = "Hóa đơn xuất";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label31.ForeColor = System.Drawing.Color.DimGray;
            this.label31.Location = new System.Drawing.Point(8, 16);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(183, 12);
            this.label31.TabIndex = 5;
            this.label31.Text = "Tiêu đề hóa đơn nhập-xuất khi in ấn";
            // 
            // txtprintimeximtitle
            // 
            this.txtprintimeximtitle.Location = new System.Drawing.Point(102, 30);
            this.txtprintimeximtitle.Margin = new System.Windows.Forms.Padding(2);
            this.txtprintimeximtitle.Name = "txtprintimeximtitle";
            this.txtprintimeximtitle.Size = new System.Drawing.Size(276, 21);
            this.txtprintimeximtitle.TabIndex = 4;
            this.txtprintimeximtitle.Text = "HÓA ĐƠN NHẬP HÀNG";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.DimGray;
            this.label9.Location = new System.Drawing.Point(6, 33);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Hóa đơn nhập";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.panel3);
            this.groupBox6.Controls.Add(this.rdprintordertypeorigional);
            this.groupBox6.Controls.Add(this.rdprintordertypesupermarket);
            this.groupBox6.Controls.Add(this.panel2);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.groupBox6.Location = new System.Drawing.Point(0, 0);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox6.Size = new System.Drawing.Size(484, 180);
            this.groupBox6.TabIndex = 12;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Hóa đơn bán hàng";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label33);
            this.panel3.Controls.Add(this.label34);
            this.panel3.Controls.Add(this.txtprinttax2);
            this.panel3.Controls.Add(this.label35);
            this.panel3.Controls.Add(this.label36);
            this.panel3.Controls.Add(this.label37);
            this.panel3.Controls.Add(this.label38);
            this.panel3.Controls.Add(this.label39);
            this.panel3.Controls.Add(this.label40);
            this.panel3.Controls.Add(this.label41);
            this.panel3.Controls.Add(this.label42);
            this.panel3.Controls.Add(this.label43);
            this.panel3.Controls.Add(this.label44);
            this.panel3.Controls.Add(this.label45);
            this.panel3.Controls.Add(this.label46);
            this.panel3.Controls.Add(this.label47);
            this.panel3.Controls.Add(this.label48);
            this.panel3.Controls.Add(this.txtprintprinttitle2);
            this.panel3.Controls.Add(this.txtprintthanks2);
            this.panel3.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel3.Location = new System.Drawing.Point(236, 31);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(215, 134);
            this.panel3.TabIndex = 6;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label33.ForeColor = System.Drawing.Color.DimGray;
            this.label33.Location = new System.Drawing.Point(144, 94);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(46, 10);
            this.label33.TabIndex = 21;
            this.label33.Text = "2.000.000";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label34.ForeColor = System.Drawing.Color.DimGray;
            this.label34.Location = new System.Drawing.Point(3, 94);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(30, 10);
            this.label34.TabIndex = 20;
            this.label34.Text = "Cộng:";
            // 
            // txtprinttax2
            // 
            this.txtprinttax2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtprinttax2.Enabled = false;
            this.txtprinttax2.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtprinttax2.Location = new System.Drawing.Point(5, 81);
            this.txtprinttax2.Margin = new System.Windows.Forms.Padding(2);
            this.txtprinttax2.Name = "txtprinttax2";
            this.txtprinttax2.Size = new System.Drawing.Size(108, 10);
            this.txtprinttax2.TabIndex = 19;
            this.txtprinttax2.Text = "Thuế GTGT (VAT=10%)";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label35.ForeColor = System.Drawing.Color.DimGray;
            this.label35.Location = new System.Drawing.Point(3, 106);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(119, 10);
            this.label35.TabIndex = 18;
            this.label35.Text = "N.V bán hàng: DEMO SALER";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label36.ForeColor = System.Drawing.Color.DimGray;
            this.label36.Location = new System.Drawing.Point(144, 81);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(38, 10);
            this.label36.TabIndex = 17;
            this.label36.Text = "200.000";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label37.ForeColor = System.Drawing.Color.DimGray;
            this.label37.Location = new System.Drawing.Point(144, 69);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(46, 10);
            this.label37.TabIndex = 15;
            this.label37.Text = "2.000.000";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label38.ForeColor = System.Drawing.Color.DimGray;
            this.label38.Location = new System.Drawing.Point(3, 69);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(30, 10);
            this.label38.TabIndex = 14;
            this.label38.Text = "Cộng:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label39.ForeColor = System.Drawing.Color.DimGray;
            this.label39.Location = new System.Drawing.Point(144, 54);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(46, 10);
            this.label39.TabIndex = 13;
            this.label39.Text = "1.000.000";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label40.ForeColor = System.Drawing.Color.DimGray;
            this.label40.Location = new System.Drawing.Point(126, 54);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(10, 10);
            this.label40.TabIndex = 12;
            this.label40.Text = "1";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label41.ForeColor = System.Drawing.Color.DimGray;
            this.label41.Location = new System.Drawing.Point(2, 54);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(80, 10);
            this.label41.TabIndex = 11;
            this.label41.Text = "Sản phẩm demo 2";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label42.ForeColor = System.Drawing.Color.DimGray;
            this.label42.Location = new System.Drawing.Point(144, 42);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(46, 10);
            this.label42.TabIndex = 10;
            this.label42.Text = "1.000.000";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label43.ForeColor = System.Drawing.Color.DimGray;
            this.label43.Location = new System.Drawing.Point(126, 42);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(10, 10);
            this.label43.TabIndex = 9;
            this.label43.Text = "1";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label44.ForeColor = System.Drawing.Color.DimGray;
            this.label44.Location = new System.Drawing.Point(2, 42);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(80, 10);
            this.label44.TabIndex = 8;
            this.label44.Text = "Sản phẩm demo 1";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label45.ForeColor = System.Drawing.Color.DimGray;
            this.label45.Location = new System.Drawing.Point(144, 30);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(32, 10);
            this.label45.TabIndex = 7;
            this.label45.Text = "T.TIỀN";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label46.ForeColor = System.Drawing.Color.DimGray;
            this.label46.Location = new System.Drawing.Point(126, 30);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(14, 10);
            this.label46.TabIndex = 6;
            this.label46.Text = "SL";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label47.ForeColor = System.Drawing.Color.DimGray;
            this.label47.Location = new System.Drawing.Point(2, 30);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(47, 10);
            this.label47.TabIndex = 5;
            this.label47.Text = "SẢN PHẨM";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label48.ForeColor = System.Drawing.Color.DimGray;
            this.label48.Location = new System.Drawing.Point(2, 2);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(203, 10);
            this.label48.TabIndex = 4;
            this.label48.Text = "CÔNG TY TNHH XA LỘ THÔNG TIN - CA CO.,LTD.";
            // 
            // txtprintprinttitle2
            // 
            this.txtprintprinttitle2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtprintprinttitle2.Enabled = false;
            this.txtprintprinttitle2.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtprintprinttitle2.Location = new System.Drawing.Point(3, 18);
            this.txtprintprinttitle2.Margin = new System.Windows.Forms.Padding(2);
            this.txtprintprinttitle2.Name = "txtprintprinttitle2";
            this.txtprintprinttitle2.Size = new System.Drawing.Size(174, 10);
            this.txtprintprinttitle2.TabIndex = 4;
            this.txtprintprinttitle2.Text = "HÓA ĐƠN MUA HÀNG";
            this.txtprintprinttitle2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtprintthanks2
            // 
            this.txtprintthanks2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtprintthanks2.Enabled = false;
            this.txtprintthanks2.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtprintthanks2.Location = new System.Drawing.Point(4, 119);
            this.txtprintthanks2.Margin = new System.Windows.Forms.Padding(2);
            this.txtprintthanks2.Name = "txtprintthanks2";
            this.txtprintthanks2.Size = new System.Drawing.Size(173, 10);
            this.txtprintthanks2.TabIndex = 3;
            this.txtprintthanks2.Text = "Chúng tôi xin cảm ơn Quý khách đã mua hàng";
            // 
            // rdprintordertypeorigional
            // 
            this.rdprintordertypeorigional.AutoSize = true;
            this.rdprintordertypeorigional.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdprintordertypeorigional.Location = new System.Drawing.Point(246, 14);
            this.rdprintordertypeorigional.Margin = new System.Windows.Forms.Padding(2);
            this.rdprintordertypeorigional.Name = "rdprintordertypeorigional";
            this.rdprintordertypeorigional.Size = new System.Drawing.Size(156, 16);
            this.rdprintordertypeorigional.TabIndex = 5;
            this.rdprintordertypeorigional.Text = "Hóa đơn truyền thống (A4)";
            this.rdprintordertypeorigional.UseVisualStyleBackColor = true;
            // 
            // rdprintordertypesupermarket
            // 
            this.rdprintordertypesupermarket.AutoSize = true;
            this.rdprintordertypesupermarket.Checked = true;
            this.rdprintordertypesupermarket.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.rdprintordertypesupermarket.Location = new System.Drawing.Point(6, 14);
            this.rdprintordertypesupermarket.Margin = new System.Windows.Forms.Padding(2);
            this.rdprintordertypesupermarket.Name = "rdprintordertypesupermarket";
            this.rdprintordertypesupermarket.Size = new System.Drawing.Size(104, 16);
            this.rdprintordertypesupermarket.TabIndex = 4;
            this.rdprintordertypesupermarket.TabStop = true;
            this.rdprintordertypesupermarket.Text = "Hóa đơn siêu thị";
            this.rdprintordertypesupermarket.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.txtprinttax);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.txtprintprinttitle);
            this.panel2.Controls.Add(this.txtprintthanks);
            this.panel2.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel2.Location = new System.Drawing.Point(8, 31);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(224, 134);
            this.panel2.TabIndex = 3;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label22.ForeColor = System.Drawing.Color.DimGray;
            this.label22.Location = new System.Drawing.Point(144, 94);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(46, 10);
            this.label22.TabIndex = 21;
            this.label22.Text = "2.000.000";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label24.ForeColor = System.Drawing.Color.DimGray;
            this.label24.Location = new System.Drawing.Point(3, 94);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(30, 10);
            this.label24.TabIndex = 20;
            this.label24.Text = "Cộng:";
            // 
            // txtprinttax
            // 
            this.txtprinttax.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtprinttax.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtprinttax.Location = new System.Drawing.Point(5, 81);
            this.txtprinttax.Margin = new System.Windows.Forms.Padding(2);
            this.txtprinttax.Name = "txtprinttax";
            this.txtprinttax.Size = new System.Drawing.Size(108, 10);
            this.txtprinttax.TabIndex = 19;
            this.txtprinttax.Text = "Thuế GTGT (VAT=10%)";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label25.ForeColor = System.Drawing.Color.DimGray;
            this.label25.Location = new System.Drawing.Point(3, 106);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(119, 10);
            this.label25.TabIndex = 18;
            this.label25.Text = "N.V bán hàng: DEMO SALER";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label23.ForeColor = System.Drawing.Color.DimGray;
            this.label23.Location = new System.Drawing.Point(144, 81);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(38, 10);
            this.label23.TabIndex = 17;
            this.label23.Text = "200.000";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label21.ForeColor = System.Drawing.Color.DimGray;
            this.label21.Location = new System.Drawing.Point(144, 69);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(46, 10);
            this.label21.TabIndex = 15;
            this.label21.Text = "2.000.000";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label20.ForeColor = System.Drawing.Color.DimGray;
            this.label20.Location = new System.Drawing.Point(3, 69);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(30, 10);
            this.label20.TabIndex = 14;
            this.label20.Text = "Cộng:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label17.ForeColor = System.Drawing.Color.DimGray;
            this.label17.Location = new System.Drawing.Point(144, 54);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(46, 10);
            this.label17.TabIndex = 13;
            this.label17.Text = "1.000.000";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label18.ForeColor = System.Drawing.Color.DimGray;
            this.label18.Location = new System.Drawing.Point(126, 54);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(10, 10);
            this.label18.TabIndex = 12;
            this.label18.Text = "1";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label19.ForeColor = System.Drawing.Color.DimGray;
            this.label19.Location = new System.Drawing.Point(2, 54);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(80, 10);
            this.label19.TabIndex = 11;
            this.label19.Text = "Sản phẩm demo 2";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label14.ForeColor = System.Drawing.Color.DimGray;
            this.label14.Location = new System.Drawing.Point(144, 42);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 10);
            this.label14.TabIndex = 10;
            this.label14.Text = "1.000.000";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label15.ForeColor = System.Drawing.Color.DimGray;
            this.label15.Location = new System.Drawing.Point(126, 42);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(10, 10);
            this.label15.TabIndex = 9;
            this.label15.Text = "1";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label16.ForeColor = System.Drawing.Color.DimGray;
            this.label16.Location = new System.Drawing.Point(2, 42);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(80, 10);
            this.label16.TabIndex = 8;
            this.label16.Text = "Sản phẩm demo 1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label13.ForeColor = System.Drawing.Color.DimGray;
            this.label13.Location = new System.Drawing.Point(144, 30);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(32, 10);
            this.label13.TabIndex = 7;
            this.label13.Text = "T.TIỀN";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label12.ForeColor = System.Drawing.Color.DimGray;
            this.label12.Location = new System.Drawing.Point(126, 30);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(14, 10);
            this.label12.TabIndex = 6;
            this.label12.Text = "SL";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label11.ForeColor = System.Drawing.Color.DimGray;
            this.label11.Location = new System.Drawing.Point(2, 30);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 10);
            this.label11.TabIndex = 5;
            this.label11.Text = "SẢN PHẨM";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label10.ForeColor = System.Drawing.Color.DimGray;
            this.label10.Location = new System.Drawing.Point(2, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(203, 10);
            this.label10.TabIndex = 4;
            this.label10.Text = "CÔNG TY TNHH XA LỘ THÔNG TIN - CA CO.,LTD.";
            // 
            // txtprintprinttitle
            // 
            this.txtprintprinttitle.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtprintprinttitle.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtprintprinttitle.Location = new System.Drawing.Point(2, 18);
            this.txtprintprinttitle.Margin = new System.Windows.Forms.Padding(2);
            this.txtprintprinttitle.Name = "txtprintprinttitle";
            this.txtprintprinttitle.Size = new System.Drawing.Size(174, 10);
            this.txtprintprinttitle.TabIndex = 4;
            this.txtprintprinttitle.Text = "HÓA ĐƠN MUA HÀNG";
            // 
            // txtprintthanks
            // 
            this.txtprintthanks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtprintthanks.Font = new System.Drawing.Font("Verdana", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtprintthanks.Location = new System.Drawing.Point(4, 119);
            this.txtprintthanks.Margin = new System.Windows.Forms.Padding(2);
            this.txtprintthanks.Name = "txtprintthanks";
            this.txtprintthanks.Size = new System.Drawing.Size(173, 10);
            this.txtprintthanks.TabIndex = 3;
            this.txtprintthanks.Text = "Chúng tôi xin cảm ơn Quý khách đã mua hàng";
            // 
            // btnsavesettingprint
            // 
            this.btnsavesettingprint.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnsavesettingprint.Location = new System.Drawing.Point(6, 263);
            this.btnsavesettingprint.Margin = new System.Windows.Forms.Padding(2);
            this.btnsavesettingprint.Name = "btnsavesettingprint";
            this.btnsavesettingprint.Size = new System.Drawing.Size(163, 21);
            this.btnsavesettingprint.TabIndex = 9;
            this.btnsavesettingprint.Text = "Lưu && áp dụng cài đặt";
            this.btnsavesettingprint.UseVisualStyleBackColor = true;
            this.btnsavesettingprint.Click += new System.EventHandler(this.btnsavesettingprint_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox2);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(484, 287);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Trực tuyến";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.chkenablesynonlinedata);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.btnsavesettingonline);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtwspassword);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtwsusername);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.chkenableonlinesale);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(484, 257);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Bán hàng trực tuyến";
            // 
            // label27
            // 
            this.label27.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label27.ForeColor = System.Drawing.Color.DimGray;
            this.label27.Location = new System.Drawing.Point(6, 120);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(333, 20);
            this.label27.TabIndex = 14;
            this.label27.Text = "Khi sử dụng tính năng trực tuyến, hệ thống sẽ sử dụng thông tin tài khoản bảo mật" +
                " để giao tiếp với hệ thống website.";
            // 
            // chkenablesynonlinedata
            // 
            this.chkenablesynonlinedata.AutoSize = true;
            this.chkenablesynonlinedata.ForeColor = System.Drawing.Color.DimGray;
            this.chkenablesynonlinedata.Location = new System.Drawing.Point(7, 87);
            this.chkenablesynonlinedata.Margin = new System.Windows.Forms.Padding(2);
            this.chkenablesynonlinedata.Name = "chkenablesynonlinedata";
            this.chkenablesynonlinedata.Size = new System.Drawing.Size(439, 17);
            this.chkenablesynonlinedata.TabIndex = 13;
            this.chkenablesynonlinedata.Text = "Kích hoạt đồng bộ hóa dữ liệu danh mục sản phẩm bán hàng trực tuyến.";
            this.chkenablesynonlinedata.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.label26.Location = new System.Drawing.Point(5, 71);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(333, 13);
            this.label26.TabIndex = 12;
            this.label26.Text = "Đồng bộ hóa dữ liệu bán hàng (Danh mục sản phẩm) trực tuyến";
            // 
            // btnsavesettingonline
            // 
            this.btnsavesettingonline.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnsavesettingonline.Location = new System.Drawing.Point(8, 192);
            this.btnsavesettingonline.Margin = new System.Windows.Forms.Padding(2);
            this.btnsavesettingonline.Name = "btnsavesettingonline";
            this.btnsavesettingonline.Size = new System.Drawing.Size(161, 23);
            this.btnsavesettingonline.TabIndex = 11;
            this.btnsavesettingonline.Text = "Lưu && áp dụng cài đặt";
            this.btnsavesettingonline.UseVisualStyleBackColor = true;
            this.btnsavesettingonline.Click += new System.EventHandler(this.btnsavesettingonline_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.label6.Location = new System.Drawing.Point(5, 107);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(357, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Tài khoản giao tiếp với hệ thống website bán hàng trực tuyến";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.Location = new System.Drawing.Point(110, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 12);
            this.label5.TabIndex = 5;
            this.label5.Text = "Mật khẩu";
            // 
            // txtwspassword
            // 
            this.txtwspassword.Location = new System.Drawing.Point(112, 163);
            this.txtwspassword.Margin = new System.Windows.Forms.Padding(2);
            this.txtwspassword.Name = "txtwspassword";
            this.txtwspassword.PasswordChar = '*';
            this.txtwspassword.Size = new System.Drawing.Size(101, 21);
            this.txtwspassword.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(6, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tên đăng nhập";
            // 
            // txtwsusername
            // 
            this.txtwsusername.Location = new System.Drawing.Point(8, 163);
            this.txtwsusername.Margin = new System.Windows.Forms.Padding(2);
            this.txtwsusername.Name = "txtwsusername";
            this.txtwsusername.Size = new System.Drawing.Size(101, 21);
            this.txtwsusername.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(5, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(333, 30);
            this.label3.TabIndex = 1;
            this.label3.Text = "Hệ thống cho phép quản lý các đơn hàng được đặt qua hệ thống website (OpenWeb Fra" +
                "mework)";
            // 
            // chkenableonlinesale
            // 
            this.chkenableonlinesale.AutoSize = true;
            this.chkenableonlinesale.ForeColor = System.Drawing.Color.DimGray;
            this.chkenableonlinesale.Location = new System.Drawing.Point(7, 45);
            this.chkenableonlinesale.Margin = new System.Windows.Forms.Padding(2);
            this.chkenableonlinesale.Name = "chkenableonlinesale";
            this.chkenableonlinesale.Size = new System.Drawing.Size(247, 17);
            this.chkenableonlinesale.TabIndex = 0;
            this.chkenableonlinesale.Text = "Kích hoạt kiểm tra đặt hàng trực tuyến";
            this.chkenableonlinesale.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox3);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(484, 287);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Nâng cao";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnsavesettingadvance);
            this.groupBox3.Controls.Add(this.txtadvancephone);
            this.groupBox3.Controls.Add(this.chkadvanceenabesms);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Enabled = false;
            this.groupBox3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(125)))));
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(484, 171);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Nhắn tin qua điện thoại";
            // 
            // btnsavesettingadvance
            // 
            this.btnsavesettingadvance.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnsavesettingadvance.Location = new System.Drawing.Point(9, 90);
            this.btnsavesettingadvance.Margin = new System.Windows.Forms.Padding(2);
            this.btnsavesettingadvance.Name = "btnsavesettingadvance";
            this.btnsavesettingadvance.Size = new System.Drawing.Size(157, 21);
            this.btnsavesettingadvance.TabIndex = 10;
            this.btnsavesettingadvance.Text = "Lưu && áp dụng cài đặt";
            this.btnsavesettingadvance.UseVisualStyleBackColor = true;
            // 
            // txtadvancephone
            // 
            this.txtadvancephone.Location = new System.Drawing.Point(9, 59);
            this.txtadvancephone.Margin = new System.Windows.Forms.Padding(2);
            this.txtadvancephone.Name = "txtadvancephone";
            this.txtadvancephone.Size = new System.Drawing.Size(101, 21);
            this.txtadvancephone.TabIndex = 4;
            // 
            // chkadvanceenabesms
            // 
            this.chkadvanceenabesms.AutoSize = true;
            this.chkadvanceenabesms.ForeColor = System.Drawing.Color.DimGray;
            this.chkadvanceenabesms.Location = new System.Drawing.Point(9, 22);
            this.chkadvanceenabesms.Margin = new System.Windows.Forms.Padding(2);
            this.chkadvanceenabesms.Name = "chkadvanceenabesms";
            this.chkadvanceenabesms.Size = new System.Drawing.Size(157, 17);
            this.chkadvanceenabesms.TabIndex = 6;
            this.chkadvanceenabesms.Text = "Kích hoạt báo cáo SMS";
            this.chkadvanceenabesms.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(7, 39);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(152, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Số điện thoại gửi báo cáo";
            // 
            // frmsyssettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 361);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmsyssettings";
            this.Text = "Cấu hình chung";
            this.Load += new System.EventHandler(this.frmsyssettings_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.tabControl1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtmasothue;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txttongcongty;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtcompanyphone;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtcompanyaddress;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button btnsavesettingcommon;
        private System.Windows.Forms.TextBox txtcompanyname;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtrate;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtimportprefix;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox txtorderprefix;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox cmbordersliststatus;
        private System.Windows.Forms.Button btnsavesettingsale;
        private System.Windows.Forms.TextBox txtmoneyunit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtprintimexextitle;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtprintimeximtitle;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtprinttax2;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtprintprinttitle2;
        private System.Windows.Forms.TextBox txtprintthanks2;
        private System.Windows.Forms.RadioButton rdprintordertypeorigional;
        private System.Windows.Forms.RadioButton rdprintordertypesupermarket;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtprinttax;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtprintprinttitle;
        private System.Windows.Forms.TextBox txtprintthanks;
        private System.Windows.Forms.Button btnsavesettingprint;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.CheckBox chkenablesynonlinedata;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button btnsavesettingonline;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtwspassword;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtwsusername;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chkenableonlinesale;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnsavesettingadvance;
        private System.Windows.Forms.TextBox txtadvancephone;
        private System.Windows.Forms.CheckBox chkadvanceenabesms;
        private System.Windows.Forms.Label label7;
    }
}