﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CASALE.Class;

namespace CASALE
{
    public partial class frmsyssettings : templates
    {
        public frmsyssettings()
        {
            InitializeComponent();
        }

        private void frmsyssettings_Load(object sender, EventArgs e)
        {

            if (Common.EnableSaleOnline == true)
                chkenableonlinesale.Checked = true;
            else chkenableonlinesale.Checked = false;

            if (Common.EnableSynOnlineData == true)
            {
                chkenablesynonlinedata.Checked = true;
            }
            else
            {
                chkenablesynonlinedata.Checked = false;
            }

            txtwsusername.Text = Common.SaleOnlineWSUserName;
            txtwspassword.Text = Common.SaleOnlineWSPassword;

            txtmasothue.Text = Common.Taxcode;
            txttongcongty.Text = Common.CorporationName;
            txtcompanyname.Text = Common.CompanyName;
            txtcompanyaddress.Text = Common.CompanyAddress;
            txtcompanyphone.Text = Common.CompanyPhone;
            // kinh doanh
            txtmoneyunit.Text = Common.MoneyUnit;
            DataTable orderdetailstatus = Common.OrderStatusNotIncludeAll;
            cmbordersliststatus.DataSource = orderdetailstatus;
            cmbordersliststatus.DisplayMember = "Status";
            cmbordersliststatus.ValueMember = "ID";
            cmbordersliststatus.SelectedValue = Common.DefaultOrderStatus;
            txtrate.Text = Common.Rete;
            txtorderprefix.Text = Common.OrderPrefix;
            txtimportprefix.Text = Common.ImportPrefix;


            if (Common.PrintOrderType.Equals("0"))
            {
                rdprintordertypesupermarket.Checked = true;
                rdprintordertypeorigional.Checked = false;
            }
            else
            {
                rdprintordertypesupermarket.Checked = false;
                rdprintordertypeorigional.Checked = true;
            }
            txtprintprinttitle.Text = Common.PrintTitle;
            txtprintthanks.Text = Common.PrintThanks;
            txtprinttax.Text = Common.PrintTax;
            txtprintprinttitle2.Text = Common.PrintTitle;
            txtprintthanks2.Text = Common.PrintThanks;
            txtprinttax2.Text = Common.PrintTax;

            txtprintimeximtitle.Text = Common.ImExPrintImTitle;
            txtprintimexextitle.Text = Common.ImExPrintExTitle;
        }

        private void btnsavesettingcommon_Click(object sender, EventArgs e)
        {
            Common.CorporationName = txttongcongty.Text;
            Common.CompanyName = txtcompanyname.Text;
            Common.CompanyAddress = txtcompanyaddress.Text;
            Common.CompanyPhone = txtcompanyphone.Text;
            Common.Taxcode = txtmasothue.Text;
            MessageBox.Show(this, "Đã lưu thông tin cấu hình chung", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnsavesettingsale_Click(object sender, EventArgs e)
        {
            Common.Rete = txtrate.Text;
            Common.MoneyUnit = txtmoneyunit.Text;
            Common.DefaultOrderStatus = cmbordersliststatus.SelectedValue.ToString();
            Common.OrderPrefix = txtorderprefix.Text;
            Common.ImportPrefix = txtimportprefix.Text;

            MessageBox.Show(this, "Đã lưu thông tin kinh doanh", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            frmsyssettings_Load(sender, e);
        }

        private void btnsavesettingprint_Click(object sender, EventArgs e)
        {
            string printordertype = "0";
            if (rdprintordertypeorigional.Checked == true)
                printordertype = "1";
            Common.PrintOrderType = printordertype;
            Common.PrintTitle = txtprintprinttitle.Text;
            Common.PrintThanks = txtprintthanks.Text;
            Common.PrintTax = txtprinttax.Text;
            Common.ImExPrintImTitle = txtprintimeximtitle.Text;
            Common.ImExPrintExTitle = txtprintimexextitle.Text;
            MessageBox.Show(this, "Đã lưu cấu hình in ấn thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            frmsyssettings_Load(sender, e);
        }

        private void btnsavesettingonline_Click(object sender, EventArgs e)
        {
            if (chkenableonlinesale.Checked == true)
                Common.EnableSaleOnline = true;
            else Common.EnableSaleOnline = false;

            if (chkenablesynonlinedata.Checked == true)
                Common.EnableSynOnlineData = true;
            else Common.EnableSynOnlineData = false;

            Common.SaleOnlineWSUserName = txtwsusername.Text;
            Common.SaleOnlineWSPassword = txtwspassword.Text;

            MessageBox.Show(this, "Đã lưu cấu hình trực tuyến thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            frmsyssettings_Load(sender, e);
        }
    }
}
