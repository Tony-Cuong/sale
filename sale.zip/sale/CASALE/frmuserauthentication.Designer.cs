﻿using CASALE.Class;
namespace CASALE
{
    partial class frmuserauthentication
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            Common.frmuserauthentication = null;
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Cấu hình hệ thống");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Danh sách người dùng");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Quản lý phân quyền");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Cài dặt", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3});
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Bán hàng");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Xử lý hóa đơn (đơn hàng)");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Bán hàng", new System.Windows.Forms.TreeNode[] {
            treeNode5,
            treeNode6});
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Danh sách đơn vị");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Danh mục sản phẩm");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Danh mục khách hàng");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("QL.Thông tin", new System.Windows.Forms.TreeNode[] {
            treeNode8,
            treeNode9,
            treeNode10});
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Nhập hàng hóa");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Xuất hàng hóa");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Quản lý hóa đơn nhập xuất");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Quản lý nhập xuất", new System.Windows.Forms.TreeNode[] {
            treeNode12,
            treeNode13,
            treeNode14});
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Báo cáo bán hàng");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Thống kê nhập-xuất-tồn");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("Thống kê kinh doanh");
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Biểu đồ kinh doanh");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Thống kê", new System.Windows.Forms.TreeNode[] {
            treeNode16,
            treeNode17,
            treeNode18,
            treeNode19});
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.gbroles = new System.Windows.Forms.GroupBox();
            this.chkenable = new System.Windows.Forms.CheckBox();
            this.btnclose = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.trvroles = new System.Windows.Forms.TreeView();
            this.btnsave = new System.Windows.Forms.Button();
            this.gbusers = new System.Windows.Forms.GroupBox();
            this.txtkeyword = new System.Windows.Forms.TextBox();
            this.btnsearch = new System.Windows.Forms.Button();
            this.lvusers = new System.Windows.Forms.ListView();
            this.clmiid = new System.Windows.Forms.ColumnHeader();
            this.clmname = new System.Windows.Forms.ColumnHeader();
            this.fullname = new System.Windows.Forms.ColumnHeader();
            this.panel1.SuspendLayout();
            this.gbroles.SuspendLayout();
            this.gbusers.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(87)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(608, 23);
            this.panel1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(4, 5);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(218, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "PHÂN QUYỀN NGƯỜI DÙNG";
            // 
            // gbroles
            // 
            this.gbroles.BackColor = System.Drawing.Color.Transparent;
            this.gbroles.Controls.Add(this.chkenable);
            this.gbroles.Controls.Add(this.btnclose);
            this.gbroles.Controls.Add(this.btncancel);
            this.gbroles.Controls.Add(this.trvroles);
            this.gbroles.Controls.Add(this.btnsave);
            this.gbroles.Location = new System.Drawing.Point(291, 24);
            this.gbroles.Margin = new System.Windows.Forms.Padding(2);
            this.gbroles.Name = "gbroles";
            this.gbroles.Padding = new System.Windows.Forms.Padding(2);
            this.gbroles.Size = new System.Drawing.Size(314, 373);
            this.gbroles.TabIndex = 7;
            this.gbroles.TabStop = false;
            this.gbroles.Text = "Danh sách quyền";
            // 
            // chkenable
            // 
            this.chkenable.AutoSize = true;
            this.chkenable.ForeColor = System.Drawing.Color.Black;
            this.chkenable.Location = new System.Drawing.Point(4, 352);
            this.chkenable.Margin = new System.Windows.Forms.Padding(2);
            this.chkenable.Name = "chkenable";
            this.chkenable.Size = new System.Drawing.Size(78, 19);
            this.chkenable.TabIndex = 6;
            this.chkenable.Text = "Kích hoạt";
            this.chkenable.UseVisualStyleBackColor = true;
            this.chkenable.CheckedChanged += new System.EventHandler(this.chkenable_CheckedChanged);
            // 
            // btnclose
            // 
            this.btnclose.ForeColor = System.Drawing.Color.Black;
            this.btnclose.Image = global::CASALE.Properties.Resources.forbidden;
            this.btnclose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnclose.Location = new System.Drawing.Point(251, 349);
            this.btnclose.Margin = new System.Windows.Forms.Padding(2);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(63, 22);
            this.btnclose.TabIndex = 7;
            this.btnclose.Text = "Đóng";
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // btncancel
            // 
            this.btncancel.ForeColor = System.Drawing.Color.Black;
            this.btncancel.Image = global::CASALE.Properties.Resources.action_delete;
            this.btncancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btncancel.Location = new System.Drawing.Point(173, 349);
            this.btncancel.Margin = new System.Windows.Forms.Padding(2);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(73, 22);
            this.btncancel.TabIndex = 4;
            this.btncancel.Text = "Bỏ qua";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // trvroles
            // 
            this.trvroles.CheckBoxes = true;
            this.trvroles.Dock = System.Windows.Forms.DockStyle.Top;
            this.trvroles.Location = new System.Drawing.Point(2, 17);
            this.trvroles.Margin = new System.Windows.Forms.Padding(2);
            this.trvroles.Name = "trvroles";
            treeNode1.Name = "Node0";
            treeNode1.Tag = "010";
            treeNode1.Text = "Cấu hình hệ thống";
            treeNode2.Name = "Node1";
            treeNode2.Tag = "011";
            treeNode2.Text = "Danh sách người dùng";
            treeNode3.Name = "Node0";
            treeNode3.Tag = "012";
            treeNode3.Text = "Quản lý phân quyền";
            treeNode4.Name = "2";
            treeNode4.Tag = "01";
            treeNode4.Text = "Cài dặt";
            treeNode5.Name = "Node5";
            treeNode5.Tag = "020";
            treeNode5.Text = "Bán hàng";
            treeNode6.Name = "12";
            treeNode6.Tag = "021";
            treeNode6.Text = "Xử lý hóa đơn (đơn hàng)";
            treeNode7.Name = "Node4";
            treeNode7.Tag = "02";
            treeNode7.Text = "Bán hàng";
            treeNode8.Name = "Node1";
            treeNode8.Tag = "030";
            treeNode8.Text = "Danh sách đơn vị";
            treeNode9.Name = "Node2";
            treeNode9.Tag = "031";
            treeNode9.Text = "Danh mục sản phẩm";
            treeNode10.Name = "Node3";
            treeNode10.Tag = "032";
            treeNode10.Text = "Danh mục khách hàng";
            treeNode11.Name = "Node0";
            treeNode11.Tag = "03";
            treeNode11.Text = "QL.Thông tin";
            treeNode12.Name = "Node3";
            treeNode12.Tag = "040";
            treeNode12.Text = "Nhập hàng hóa";
            treeNode13.Name = "Node0";
            treeNode13.Tag = "041";
            treeNode13.Text = "Xuất hàng hóa";
            treeNode14.Name = "61";
            treeNode14.Tag = "042";
            treeNode14.Text = "Quản lý hóa đơn nhập xuất";
            treeNode15.Name = "Node0";
            treeNode15.Tag = "04";
            treeNode15.Text = "Quản lý nhập xuất";
            treeNode16.Name = "Node4";
            treeNode16.Tag = "050";
            treeNode16.Text = "Báo cáo bán hàng";
            treeNode17.Name = "Node0";
            treeNode17.Tag = "052";
            treeNode17.Text = "Thống kê nhập-xuất-tồn";
            treeNode18.Name = "Node1";
            treeNode18.Tag = "052";
            treeNode18.Text = "Thống kê kinh doanh";
            treeNode19.Name = "Node0";
            treeNode19.Tag = "053";
            treeNode19.Text = "Biểu đồ kinh doanh";
            treeNode20.Name = "6";
            treeNode20.Tag = "04";
            treeNode20.Text = "Thống kê";
            this.trvroles.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode4,
            treeNode7,
            treeNode11,
            treeNode15,
            treeNode20});
            this.trvroles.Size = new System.Drawing.Size(310, 328);
            this.trvroles.TabIndex = 0;
            this.trvroles.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.trvroles_AfterSelect);
            // 
            // btnsave
            // 
            this.btnsave.ForeColor = System.Drawing.Color.Black;
            this.btnsave.Image = global::CASALE.Properties.Resources.disk_blue;
            this.btnsave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsave.Location = new System.Drawing.Point(88, 349);
            this.btnsave.Margin = new System.Windows.Forms.Padding(2);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(81, 22);
            this.btnsave.TabIndex = 3;
            this.btnsave.Text = "Lưu lại";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // gbusers
            // 
            this.gbusers.BackColor = System.Drawing.Color.Transparent;
            this.gbusers.Controls.Add(this.txtkeyword);
            this.gbusers.Controls.Add(this.btnsearch);
            this.gbusers.Controls.Add(this.lvusers);
            this.gbusers.Location = new System.Drawing.Point(2, 24);
            this.gbusers.Margin = new System.Windows.Forms.Padding(2);
            this.gbusers.Name = "gbusers";
            this.gbusers.Padding = new System.Windows.Forms.Padding(2);
            this.gbusers.Size = new System.Drawing.Size(285, 377);
            this.gbusers.TabIndex = 6;
            this.gbusers.TabStop = false;
            this.gbusers.Text = "Danh sách người dùng";
            // 
            // txtkeyword
            // 
            this.txtkeyword.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtkeyword.Location = new System.Drawing.Point(9, 351);
            this.txtkeyword.Margin = new System.Windows.Forms.Padding(2);
            this.txtkeyword.Name = "txtkeyword";
            this.txtkeyword.Size = new System.Drawing.Size(191, 22);
            this.txtkeyword.TabIndex = 2;
            this.txtkeyword.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtkeyword_KeyUp);
            // 
            // btnsearch
            // 
            this.btnsearch.ForeColor = System.Drawing.Color.Black;
            this.btnsearch.Image = global::CASALE.Properties.Resources.book_blue_view;
            this.btnsearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsearch.Location = new System.Drawing.Point(204, 351);
            this.btnsearch.Margin = new System.Windows.Forms.Padding(2);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(81, 23);
            this.btnsearch.TabIndex = 1;
            this.btnsearch.Text = "Tìm kiếm";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // lvusers
            // 
            this.lvusers.AllowColumnReorder = true;
            this.lvusers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvusers.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clmiid,
            this.clmname,
            this.fullname});
            this.lvusers.Dock = System.Windows.Forms.DockStyle.Top;
            this.lvusers.FullRowSelect = true;
            this.lvusers.GridLines = true;
            this.lvusers.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvusers.Location = new System.Drawing.Point(2, 17);
            this.lvusers.Margin = new System.Windows.Forms.Padding(2);
            this.lvusers.Name = "lvusers";
            this.lvusers.Size = new System.Drawing.Size(281, 330);
            this.lvusers.TabIndex = 18;
            this.lvusers.UseCompatibleStateImageBehavior = false;
            this.lvusers.View = System.Windows.Forms.View.Details;
            this.lvusers.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lvusers_MouseDoubleClick);
            // 
            // clmiid
            // 
            this.clmiid.Text = "";
            this.clmiid.Width = 0;
            // 
            // clmname
            // 
            this.clmname.Text = "Tài khoản";
            this.clmname.Width = 128;
            // 
            // fullname
            // 
            this.fullname.Text = "Họ và tên";
            this.fullname.Width = 170;
            // 
            // frmuserauthentication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 425);
            this.Controls.Add(this.gbroles);
            this.Controls.Add(this.gbusers);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmuserauthentication";
            this.Text = "Phân quyền";
            this.Load += new System.EventHandler(this.frmuserauthentication_Load);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.gbusers, 0);
            this.Controls.SetChildIndex(this.gbroles, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gbroles.ResumeLayout(false);
            this.gbroles.PerformLayout();
            this.gbusers.ResumeLayout(false);
            this.gbusers.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbroles;
        private System.Windows.Forms.CheckBox chkenable;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.TreeView trvroles;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.GroupBox gbusers;
        private System.Windows.Forms.TextBox txtkeyword;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.ListView lvusers;
        private System.Windows.Forms.ColumnHeader clmiid;
        private System.Windows.Forms.ColumnHeader clmname;
        private System.Windows.Forms.ColumnHeader fullname;
    }
}