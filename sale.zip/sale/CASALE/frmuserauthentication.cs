﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LCMembersUtiliti;
using System.Collections;
using CASALE.Class;

namespace CASALE
{
    public partial class frmuserauthentication : templates
    {
        string selectedid = "";
        string insertupdate = "Insert";
        public frmuserauthentication()
        {
            InitializeComponent();
        }

        private void frmuserauthentication_Load(object sender, EventArgs e)
        {
            this.loadUsersList();
            this.trvroles.ExpandAll();
        }
        void loadUsersList()
        {
            lvusers.Items.Clear();
            DataTable dt = new DataTable();
            dt = Members.users_getmemberslist("1", this.txtkeyword.Text, "", 0, 1000, Common.ConnectionString);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ListViewItem lvi = new ListViewItem(dt.Rows[i]["iuser_id"].ToString());
                lvi.SubItems.Add(dt.Rows[i]["vuserun"].ToString());
                lvi.SubItems.Add(dt.Rows[i]["vfname"].ToString() + " " + dt.Rows[i]["vlname"].ToString());

                lvusers.Items.Add(lvi);
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            this.loadUsersList();
        }
        void loadRolesMember()
        {
            if (lvusers.Items.Count > 0 && lvusers.SelectedItems.Count > 0)
            {
                DataTable dt = new DataTable();
                selectedid = lvusers.SelectedItems[0].SubItems[0].Text;
                dt = WindowsAuthentication.winapp_userpermissions_getdetail_byid(selectedid, Common.ConnectionString);
                if (dt.Rows.Count > 0)
                {
                    insertupdate = "Update";
                    ArrayList arroptions = new ArrayList();
                    arroptions.AddRange(dt.Rows[0]["vroles"].ToString().Split(';'));
                    for (int i = 0; i < trvroles.Nodes.Count; i++)
                    {
                        TreeNode node = trvroles.Nodes[i];
                        SetCheckTreeNode(ref node, ref arroptions);
                    }
                    if (dt.Rows[0]["istatus"].ToString().Equals("1"))
                        chkenable.Checked = true;
                    else
                        chkenable.Checked = false;

                }
                else
                {
                    insertupdate = "Insert";
                    for (int i = 0; i < trvroles.Nodes.Count; i++)
                    {
                        TreeNode node = trvroles.Nodes[i];
                        emptyChecked(ref node);
                        chkenable.Checked = false;
                    }
                }
            }
        }

        void emptyChecked(ref TreeNode node)
        {
            node.Checked = false;
            for (int i = 0; i < node.Nodes.Count; i++)
            {
                TreeNode childnode = node.Nodes[i];
                emptyChecked(ref childnode);
            }
        }

        void SetCheckTreeNode(ref TreeNode node, ref ArrayList arroptions)
        {
            if (arroptions.Contains(node.Tag))
            {
                node.Checked = true;
            }
            else
            {
                node.Checked = false;
            }
            for (int i = 0; i < node.Nodes.Count; i++)
            {
                TreeNode childnode = node.Nodes[i];
                SetCheckTreeNode(ref childnode, ref arroptions);
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (selectedid.Equals(""))
            {
                MessageBox.Show("Bạn phải chọn một người dùng !", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                return;
            }
            string Nodetag = "";
            for (int i = 0; i < trvroles.Nodes.Count; i++)
            {
                TreeNode node = trvroles.Nodes[i];
                if (node.Checked == true)
                {
                    if (Nodetag.Equals(""))
                        Nodetag += node.Tag;
                    else
                        Nodetag += ";" + node.Tag;
                }
                for (int j = 0; j < node.Nodes.Count; j++)
                {
                    TreeNode childnode = node.Nodes[j];
                    if (childnode.Checked == true)
                    {
                        if (Nodetag.Equals(""))
                            Nodetag += childnode.Tag;
                        else
                            Nodetag += ";" + childnode.Tag;
                    }
                }
            }
            string enabled = "0";
            if (chkenable.Checked == true)
                enabled = "1";
            switch (this.insertupdate.ToString().Trim())
            {
                case "Update":
                    WindowsAuthentication.winapp_userpermissions_update(this.selectedid, "SH", Nodetag, enabled, Common.ConnectionString);
                    break;
                case "Insert":
                    WindowsAuthentication.winapp_userpermissions_insert(this.selectedid, "SH", Nodetag, enabled, Common.ConnectionString);
                    break;
            }
            this.loadRolesMember();
            this.btnsave.Enabled = false;
            this.btncancel.Enabled = true;
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            this.btnsave.Enabled = true;
            this.btncancel.Enabled = false;
            this.loadRolesMember();
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn đóng lại !", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void chkenable_CheckedChanged(object sender, EventArgs e)
        {
            this.btnsave.Enabled = true;
            this.btncancel.Enabled = true;
        }

        private void txtkeyword_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.loadUsersList();
            }
        }

        private void trvroles_AfterSelect(object sender, TreeViewEventArgs e)
        {
            try
            {
                if (trvroles.Nodes.Count > 0)
                {
                    if (trvroles.SelectedNode != null)
                    {
                        if (trvroles.SelectedNode.Checked == true)
                        {
                            for (int i = 0; i < trvroles.SelectedNode.Nodes.Count; i++)
                            {
                                trvroles.SelectedNode.Nodes[i].Checked = true;
                            }
                        }
                        else
                        {
                            for (int i = 0; i < trvroles.SelectedNode.Nodes.Count; i++)
                            {
                                trvroles.SelectedNode.Nodes[i].Checked = false;
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { }
        }

        private void lvusers_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.btnsave.Enabled = true;
                this.btncancel.Enabled = true;
                selectedid = lvusers.SelectedItems[0].SubItems[0].Text;
                gbroles.Text = "Danh sách quyền của: " + lvusers.SelectedItems[0].SubItems[1].Text;
                loadRolesMember();
            }
        }
    }
}
