﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CASALE.Class;

namespace CASALE
{
    public partial class templates : Form
    {
        DateTime da;
        TimeSpan now = new TimeSpan();
        public templates()
        {
            InitializeComponent();
            da = DateTime.Now;
            timer1.Start();
            lblclock.Text = DateTime.Now.ToString();
            lblwelcome.Text = "Xin chào " + Common.UserFullName + " [" + Common.UserName + "]";
        }

        private void templates_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                lblclock.Text = LCUtiliti.LCFormatdatetime.formatdate("VIE");
                now = DateTime.Now - da;
                lbltime.Text = now.ToString().Remove(now.ToString().IndexOf('.')) + "  - ";
            }
            catch (Exception)
            {
            }
        }
    }
}
